import AVFoundation
import CoreImage
import CoreImage.CIFilterBuiltins
import CoreText
import ImageIO
import UniformTypeIdentifiers

// usage: editor_long <edit.json> [--nocaps] [--frames t1 t2 ...]
// v2: A/B-roll dissolves between shots, animated callouts, music ducking in voiceover gaps.
// Renders a 1920x1080 long-form video from an edit list: shots pulled from several source videos
// (crop / callout, animated zoom, freeze), multiple voiceover chunks, subtitle-style captions,
// numbered detail cards with a source tag, channel logo and the same Hook + loop music bed as the Shorts.

struct R: Codable { var x: Double; var y: Double; var w: Double; var h: Double }
struct Shot: Codable {
    var s: String                  // source key
    var src: [Double]; var out: [Double]
    var mode: String?              // crop (default) | callout
    var from: R?; var to: R?       // crop rect animation (top-left coords in 1920x1080)
    var region: R?                 // callout region
    var capY: Double?              // caption centre (top-left px); default sits near the bottom
    var join: Bool?                // true = hard cut into this shot (continuation of the same frame), no dissolve
    // v4: real-life photos. mode "photo" = full-screen still (from/to rects are in the photo's 1920x1080 space);
    // mode "split" = frozen game frame wipes to one half, the photo slides into the other half
    var img: String?               // path of a 16:9 photo
    var imgRegion: R?              // split: part of the photo shown in its panel (photo 1920x1080 space)
    var dir: String?               // split: "h" side by side (default) | "v" stacked
    var label: String?             // split: game panel label (default "GTA 6")
    var imgLabel: String?          // photo label (default "REAL LIFE")
    var credit: String?            // small photo credit
    var mark: Mark?                // v8: circle / arrow graphic
    var tag: String?               // v9: small corner label on a normal shot (e.g. "GTA 5" on comparison footage), top right
}
// v8: red circle (+ optional arrow) that pops onto a detail and follows the zoom. x, y, r in 1920x1080 source coords
struct Mark: Codable { var x: Double; var y: Double; var r: Double; var arrow: Double?; var at: Double? }   // arrow = angle in degrees the arrow comes from (0 = right, 90 = up)
struct Cap: Codable { var t: [Double]; var chunks: [String] }
struct Card: Codable { var t: [Double]; var num: String?; var title: String; var tag: String? }
struct VO: Codable { var file: String; var at: Double }
struct KW: Codable { var t: [Double]; var text: String }
struct CH: Codable { var t: [Double]; var num: String?; var title: String; var kicker: String? }
struct SFX: Codable { var file: String; var at: Double; var vol: Double? }
struct Edit: Codable {
    var out: String; var sources: [String: String]; var vo: [VO]
    var shots: [Shot]; var captions: [Cap]; var cards: [Card]?; var badges: [Double]?
    var hook: String?; var music: String?; var hookVol: Double?; var musicVol: Double?
    var duckHigh: Double?          // music level in the gaps between voiceover chunks
    var xfade: Double?             // dissolve length between shots (s)
    var timedCaptions: Bool?       // captions[].t is exact on-screen time for chunks[0] (no alignment)
    var keywords: [KW]?            // v3: keyword callouts only (no full subtitles)
    var chapters: [CH]?            // v3: chapter title cards
    var sfx: [SFX]?
    var grade: Bool?               // v3: colour grade + vignette
    var letterbox: [[Double]]?     // v3: animated 2.39:1 bars over these ranges
    var flashes: [Double]?         // v3: white flash transitions
    var snaps: [Double]?           // v4: soft camera-shutter flash at a freeze
    var voVol: Double?             // v4: voiceover gain (default 1.0)
    var bitrate: Int?              // optional video bitrate in bits/s (default 20 Mbps)
    var fastStart: Bool?           // false = skip the network-optimise pass (no temp copy; default true)
    var kwPlate: Bool?             // v8: true = keywords on the yellow plate; default (rank style) is text only
    var accent: [Double]?          // v10: accent colour [r, g, b] of the rank style (default gold)
    var font: String?              // v10: PostScript name of the title / keyword font (default DINCondensed-Bold)
    var logo: Bool?                // v10: false = no channel logo
    var logoPath: String?; var logoSize: Double?; var logoAlpha: Double?   // v11: another channel's logo (PNG with alpha), its width in px and opacity
    var look: String?              // v10: "bar" = square number plate without "#", accent bar beside keywords
    var textStyle: String?         // v6: "rank" = condensed yellow/black look (keyword plates, big rank-number cards); default classic
}
let LOGO_PATH = "/Users/hemanthkumaro11/Youtube/shorts-pipeline/assets/channel_logo.png"
let GTA_LOGO_PATH = "/Users/hemanthkumaro11/Youtube/shorts-pipeline/assets/gta6_logo.png"
let HOOK_DEFAULT = "/Users/hemanthkumaro11/Youtube/Hook.mp3"
let MUSIC_DEFAULT = "/Users/hemanthkumaro11/Youtube/BG Music (Loop).mp3"

let W: CGFloat = 1920, H: CGFloat = 1080
let FULL = R(x: 0, y: 0, w: 1920, h: 1080)
let GREEN = CGColor(red: 0.45, green: 0.93, blue: 0.12, alpha: 1)
let WHITE = CGColor(red: 1, green: 1, blue: 1, alpha: 1)
let BLACK = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
let YELLOW = CGColor(red: 1, green: 0.87, blue: 0.1, alpha: 1)

func ciRect(_ r: R) -> CGRect { CGRect(x: r.x, y: H - r.y - r.h, width: r.w, height: r.h) }
func lerp(_ a: CGRect, _ b: CGRect, _ p: CGFloat) -> CGRect {
    CGRect(x: a.minX + (b.minX - a.minX) * p, y: a.minY + (b.minY - a.minY) * p,
           width: a.width + (b.width - a.width) * p, height: a.height + (b.height - a.height) * p)
}
func ease(_ p: CGFloat) -> CGFloat { p < 0.5 ? 2 * p * p : 1 - pow(-2 * p + 2, 2) / 2 }
func wait<T>(_ op: @escaping () async throws -> T) -> T {
    var r: T!; let s = DispatchSemaphore(value: 0)
    Task { r = try! await op(); s.signal() }; s.wait(); return r
}
func ctx(_ w: Int, _ h: Int) -> CGContext {
    let c = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                      space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
    c.setAllowsAntialiasing(true); c.setShouldSmoothFonts(true); return c
}

// MARK: text
struct Run { var s: String; var color: CGColor }
// one line of stroked, shadowed Arial Black text; words wrapped in *...* go green
func runs(_ text: String, base: CGColor) -> [Run] {
    text.split(separator: " ").map { w in
        Run(s: w.filter { !"*\"“”".contains($0) }.uppercased(), color: w.contains("*") ? GREEN : base)
    }
}
func attr(_ rs: [Run], font: CTFont, stroke: CGFloat?) -> NSAttributedString {
    let m = NSMutableAttributedString()
    for (i, r) in rs.enumerated() {
        var a: [NSAttributedString.Key: Any] = [.init(kCTFontAttributeName as String): font]
        if let st = stroke {
            a[.init(kCTStrokeWidthAttributeName as String)] = st
            a[.init(kCTStrokeColorAttributeName as String)] = BLACK
            a[.init(kCTForegroundColorAttributeName as String)] = BLACK
        } else { a[.init(kCTForegroundColorAttributeName as String)] = r.color }
        m.append(NSAttributedString(string: (i > 0 ? " " : "") + r.s, attributes: a))
    }
    return m
}
// renders up to 2 lines centered in a box maxW wide; returns an image whose extent is the tight box
func renderText(_ text: String, size: CGFloat, maxW: CGFloat, base: CGColor = WHITE, stroke: CGFloat = 12) -> CIImage {
    let font = CTFontCreateWithName("Arial-Black" as CFString, size, nil)
    let all = runs(text, base: base)
    func width(_ rs: [Run]) -> CGFloat { CGFloat(CTLineGetTypographicBounds(CTLineCreateWithAttributedString(attr(rs, font: font, stroke: nil)), nil, nil, nil)) }
    var lines: [[Run]] = [all]
    if width(all) > maxW, all.count > 1 {     // split into two balanced lines
        var best = 1, bestD = CGFloat.greatestFiniteMagnitude
        for k in 1..<all.count { let d = abs(width(Array(all[..<k])) - width(Array(all[k...]))); if d < bestD { bestD = d; best = k } }
        lines = [Array(all[..<best]), Array(all[best...])]
    }
    let lineH = size * 1.18, pad: CGFloat = 30
    let imgW = Int(min(W, maxW + pad * 2)), imgH = Int(lineH * CGFloat(lines.count) + pad * 2)
    let c = ctx(imgW, imgH)
    for pass in 0..<2 {
        for (i, rs) in lines.enumerated() {
            let line = CTLineCreateWithAttributedString(attr(rs, font: font, stroke: pass == 0 ? stroke : nil))
            let w = CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))
            let fit = min(1, maxW / max(w, 1))
            let y = CGFloat(imgH) - pad - lineH * CGFloat(i + 1) + size * 0.25
            c.saveGState()
            if pass == 1 { c.setShadow(offset: CGSize(width: 0, height: -5), blur: 12, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.85)) }
            c.setLineJoin(.round)
            c.translateBy(x: (CGFloat(imgW) - w * fit) / 2, y: y); c.scaleBy(x: fit, y: 1)
            c.textPosition = .zero; CTLineDraw(line, c); c.restoreGState()
        }
    }
    return CIImage(cgImage: c.makeImage()!)
}
// small rounded tag: "#07  TRAILER 2 · 0:37"
func renderTag(_ num: String?, _ tag: String?) -> CIImage {
    let big = CTFontCreateWithName("Arial-Black" as CFString, 40, nil), small = CTFontCreateWithName("Arial-BoldMT" as CFString, 26, nil)
    let m = NSMutableAttributedString()
    if let n = num { m.append(NSAttributedString(string: n, attributes: [.init(kCTFontAttributeName as String): big, .init(kCTForegroundColorAttributeName as String): GREEN])) }
    if let t = tag { m.append(NSAttributedString(string: (num != nil ? "   " : "") + t.uppercased(), attributes: [.init(kCTFontAttributeName as String): small, .init(kCTForegroundColorAttributeName as String): WHITE])) }
    let line = CTLineCreateWithAttributedString(m)
    let w = CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))
    let bw = Int(w + 44), bh = 66
    let c = ctx(bw, bh)
    c.setFillColor(CGColor(red: 0, green: 0, blue: 0, alpha: 0.62))
    c.addPath(CGPath(roundedRect: CGRect(x: 0, y: 0, width: bw, height: bh), cornerWidth: 14, cornerHeight: 14, transform: nil)); c.fillPath()
    c.setFillColor(GREEN); c.fill(CGRect(x: 0, y: 0, width: 6, height: bh))
    c.textPosition = CGPoint(x: 24, y: 19); CTLineDraw(line, c)
    return CIImage(cgImage: c.makeImage()!)
}

// MARK: overlays
let BADGE: CIImage? = {
    guard let src = CIImage(contentsOf: URL(fileURLWithPath: GTA_LOGO_PATH)) else { return nil }
    let s = 440 / src.extent.width
    return src.transformed(by: CGAffineTransform(scaleX: s, y: s))
}()
// v11: the logo file, width (px) and opacity can be set per edit ("logoPath", "logoSize", "logoAlpha"); defaults = Wanted Level logo, 150 px, 65 %
func makeLogo(_ path: String, _ size: CGFloat, _ op: CGFloat) -> CIImage? {
    guard let src = CIImage(contentsOf: URL(fileURLWithPath: path)) else { return nil }
    let s = size / src.extent.width
    let img = src.transformed(by: CGAffineTransform(scaleX: s, y: s))
    let f = CIFilter.colorMatrix(); f.inputImage = img; f.aVector = CIVector(x: 0, y: 0, z: 0, w: op)
    return f.outputImage!.transformed(by: CGAffineTransform(translationX: 36 - img.extent.minX, y: H - 36 - img.extent.height - img.extent.minY))
}
var LOGO: CIImage? = makeLogo(LOGO_PATH, 150, 0.65)

// MARK: word alignment against the voiceover envelope (same method as the Shorts editor)
func envelope(_ url: URL) -> [Float] {
    let f = try! AVAudioFile(forReading: url)
    let buf = AVAudioPCMBuffer(pcmFormat: f.processingFormat, frameCapacity: AVAudioFrameCount(f.length))!
    try! f.read(into: buf)
    let n = Int(buf.frameLength), d = buf.floatChannelData![0], win = Int(f.processingFormat.sampleRate * 0.01)
    var env: [Float] = []; var i = 0
    while i < n { var s: Float = 0; let e = min(n, i + win); for j in i..<e { s += d[j] * d[j] }; env.append(sqrt(s / Float(e - i))); i += win }
    var sm = env
    for k in 2..<max(2, env.count - 2) { sm[k] = (env[k-2] + env[k-1] + env[k] + env[k+1] + env[k+2]) / 5 }
    return sm
}
func syllables(_ w: String) -> Double {
    let s = w.lowercased().filter { $0.isLetter || $0.isNumber }
    if s.isEmpty { return 1 }
    if s.allSatisfy({ $0.isNumber }) { return Double(max(1, s.count)) }
    var c = 0; var prevV = false
    for ch in s { let v = "aeiouy".contains(ch); if v && !prevV { c += 1 }; prevV = v }
    if s.hasSuffix("e") && c > 1 { c -= 1 }
    return Double(max(1, c))
}
func alignWords(_ words: [String], _ t0: Double, _ t1: Double, env: [Float], dt: Double) -> [(Double, Double)] {
    let n = words.count
    guard n > 1, !env.isEmpty else { return Array(repeating: (t0, t1), count: max(n, 1)) }
    let thr = (env.max() ?? 1) * 0.06
    var a = max(0, Int(t0 / dt)), b = min(env.count - 1, Int(t1 / dt))
    while a < b && env[a] < thr { a += 1 }
    while b > a && env[b] < thr { b -= 1 }
    let start = Double(a) * dt, end = Double(b + 1) * dt
    let syl = words.map(syllables), total = syl.reduce(0, +)
    var bounds: [Double] = [start]; var acc = 0.0
    for i in 0..<(n - 1) {
        acc += syl[i]
        let expected = start + (end - start) * acc / total
        let slack = (end - start) / total * min(syl[i], syl[i + 1]) * 0.45
        var lo = Int((expected - slack) / dt), hi = Int((expected + slack) / dt)
        lo = max(lo, Int(bounds.last! / dt) + 3); hi = min(hi, b - 3)
        var best = Int(expected / dt), bestV = Float.greatestFiniteMagnitude
        if lo <= hi { for k in lo...hi { let v = env[k] * (1 + 0.6 * Float(abs(Double(k) * dt - expected) / max(slack, 0.01))); if v < bestV { bestV = v; best = k } } }
        let minLen = max(0.12, (end - start) / total * syl[i] * 0.5)
        var bnd = Double(best) * dt
        if bnd - bounds.last! < minLen { bnd = min(expected, bounds.last! + minLen) }
        bounds.append(bnd)
    }
    bounds.append(end)
    return (0..<n).map { (bounds[$0], bounds[$0 + 1]) }
}

// MARK: timed overlay items (rendered lazily, cached)
struct Item { var start: Double; var end: Double; var make: () -> CIImage }
final class Lazy {
    let lock = NSLock(); var cache: [Int: CIImage] = [:]
    func get(_ i: Int, _ items: [Item]) -> CIImage {
        lock.lock(); defer { lock.unlock() }
        if let c = cache[i] { return c }
        if cache.count > 8 { cache.removeAll() }
        let img = items[i].make(); cache[i] = img; return img
    }
}
var CAPS: [Item] = [], POPS: [Item] = [], TAGS: [Item] = []
let capCache = Lazy(), popCache = Lazy(), tagCache = Lazy()
var BADGE_TIMES: [Double] = []
var KWS: [Item] = [], CHS: [Item] = []
let kwCache = Lazy(), chCache = Lazy()
var GRADE = false, LETTERBOX: [[Double]] = [], FLASHES: [Double] = [], SNAPS: [Double] = []
// v4: photos (loaded once) and panel labels
var PHOTOS: [String: CIImage] = [:]; let photoLock = NSLock()
func photo(_ path: String) -> CIImage {
    photoLock.lock(); defer { photoLock.unlock() }
    if let p = PHOTOS[path] { return p }
    guard let src = CGImageSourceCreateWithURL(URL(fileURLWithPath: path) as CFURL, nil), let cg = CGImageSourceCreateImageAtIndex(src, 0, nil) else { fatalError("cannot load photo \(path)") }
    let img = CIImage(cgImage: cg); PHOTOS[path] = img; return img
}
var LABELS: [String: CIImage] = [:]
func panelLabel(_ text: String, accent: CGColor) -> CIImage {
    photoLock.lock(); defer { photoLock.unlock() }
    if let l = LABELS[text] { return l }
    let font = CTFontCreateWithName("Arial-Black" as CFString, 40, nil)
    let (line, w) = spacedLine(text.uppercased(), font: font, color: WHITE, kern: 3)
    let bw = Int(w + 62), bh = 74
    let c = ctx(bw, bh)
    c.setFillColor(CGColor(red: 0, green: 0, blue: 0, alpha: 0.72))
    c.addPath(CGPath(roundedRect: CGRect(x: 0, y: 0, width: bw, height: bh), cornerWidth: 12, cornerHeight: 12, transform: nil)); c.fillPath()
    c.setFillColor(accent); c.fill(CGRect(x: 0, y: 0, width: 8, height: bh))
    c.textPosition = CGPoint(x: 32, y: 23); CTLineDraw(line, c)
    let img = CIImage(cgImage: c.makeImage()!); LABELS[text] = img; return img
}
func creditLine(_ text: String) -> CIImage {
    photoLock.lock(); defer { photoLock.unlock() }
    if let l = LABELS["©" + text] { return l }
    let font = CTFontCreateWithName("Arial-BoldMT" as CFString, 22, nil)
    let (line, w) = spacedLine(text, font: font, color: CGColor(red: 1, green: 1, blue: 1, alpha: 0.85), kern: 0.5)
    let c = ctx(Int(w + 24), 40)
    c.setShadow(offset: CGSize(width: 0, height: -2), blur: 6, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.95))
    c.textPosition = CGPoint(x: 12, y: 12); CTLineDraw(line, c)
    let img = CIImage(cgImage: c.makeImage()!); LABELS["©" + text] = img; return img
}

func spacedLine(_ text: String, font: CTFont, color: CGColor, kern: CGFloat) -> (CTLine, CGFloat) {
    let a: [NSAttributedString.Key: Any] = [.init(kCTFontAttributeName as String): font, .init(kCTForegroundColorAttributeName as String): color,
                                            .init(kCTKernAttributeName as String): kern]
    let l = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: a))
    return (l, CGFloat(CTLineGetTypographicBounds(l, nil, nil, nil)))
}
// keyword callout: bold white word(s), green accent bar, soft shadow. Left-aligned image; x/y placed by the compositor.
func renderKeyword(_ text: String) -> CIImage {
    let font = CTFontCreateWithName("Arial-Black" as CFString, 92, nil)
    let (line, w) = spacedLine(text.uppercased(), font: font, color: WHITE, kern: 2)
    let W2 = Int(w + 120), H2 = 170
    let c = ctx(W2, H2)
    c.setShadow(offset: CGSize(width: 0, height: -6), blur: 22, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.9))
    c.setFillColor(GREEN); c.fill(CGRect(x: 20, y: 38, width: 12, height: 96))
    c.textPosition = CGPoint(x: 58, y: 50); CTLineDraw(line, c)
    return CIImage(cgImage: c.makeImage()!)
}
func renderChapter(_ num: String?, _ title: String, _ kicker: String?) -> CIImage {
    let c = ctx(Int(W), Int(H))
    let big = CTFontCreateWithName("Arial-Black" as CFString, 128, nil)
    let small = CTFontCreateWithName("Arial-BoldMT" as CFString, 34, nil)
    let (tl, tw) = spacedLine(title.uppercased(), font: big, color: WHITE, kern: 4)
    c.setShadow(offset: CGSize(width: 0, height: -6), blur: 26, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.85))
    c.textPosition = CGPoint(x: (W - tw) / 2, y: H / 2 - 50); CTLineDraw(tl, c)
    let k = kicker ?? (num.map { "CHAPTER \($0)" } ?? "")
    if !k.isEmpty {
        let (kl, kw) = spacedLine(k, font: small, color: GREEN, kern: 12)
        c.textPosition = CGPoint(x: (W - kw) / 2, y: H / 2 + 110); CTLineDraw(kl, c)
    }
    return CIImage(cgImage: c.makeImage()!)
}

// v6 "rank" text style: DIN Condensed, yellow plate keywords, giant rank number on chapter cards
var TEXT_STYLE = "classic"
var GOLD = CGColor(red: 1, green: 0.82, blue: 0.04, alpha: 1)
var FONT_NAME = "DINCondensed-Bold", LOOK = "", SHOW_LOGO = true
let INK = CGColor(red: 0.04, green: 0.04, blue: 0.05, alpha: 1)
var KW_PLATE = false
// text only: white condensed caps, soft shadow, no box
func renderKeywordClean(_ text: String) -> CIImage {
    let font = CTFontCreateWithName(FONT_NAME as CFString, 124, nil)
    let (line, w) = spacedLine(text.uppercased(), font: font, color: WHITE, kern: 4)
    let m: CGFloat = 50
    let c = ctx(Int(w + m * 2), Int(150 + m * 2))
    c.setShadow(offset: CGSize(width: 0, height: -5), blur: 26, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.95))
    c.textPosition = CGPoint(x: m, y: m + 26); CTLineDraw(line, c)
    c.setShadow(offset: CGSize(width: 0, height: -2), blur: 5, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.9))
    c.textPosition = CGPoint(x: m, y: m + 26); CTLineDraw(line, c)
    if LOOK == "bar" { c.setShadow(offset: .zero, blur: 0, color: nil); c.setFillColor(GOLD); c.fill(CGRect(x: m - 36, y: m + 14, width: 12, height: 106)) }
    return CIImage(cgImage: c.makeImage()!)
}
let MARK_RED = CGColor(red: 0.93, green: 0.11, blue: 0.14, alpha: 1)
// circle of radius r (screen px) centred in a square canvas, optional arrow arriving from `deg`
func renderMark(_ r: CGFloat, _ deg: Double?) -> CIImage {
    let L: CGFloat = 150, half = r + L + 70
    let c = ctx(Int(half * 2), Int(half * 2))
    c.setShadow(offset: CGSize(width: 0, height: -4), blur: 14, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.6))
    c.setLineCap(.round); c.setLineJoin(.round)
    let ring = CGRect(x: half - r, y: half - r, width: r * 2, height: r * 2)
    c.setStrokeColor(WHITE); c.setLineWidth(15); c.strokeEllipse(in: ring)
    c.setShadow(offset: .zero, blur: 0, color: nil)
    c.setStrokeColor(MARK_RED); c.setLineWidth(9); c.strokeEllipse(in: ring)
    if let d = deg {
        let a = CGFloat(d * .pi / 180), ux = cos(a), uy = sin(a)
        let tip = CGPoint(x: half + ux * (r + 20), y: half + uy * (r + 20))
        let tail = CGPoint(x: half + ux * (r + 20 + L), y: half + uy * (r + 20 + L))
        let hl: CGFloat = 50, hw: CGFloat = 30
        let bx = tip.x + ux * hl, by = tip.y + uy * hl
        let head = CGMutablePath()
        head.move(to: tip); head.addLine(to: CGPoint(x: bx - uy * hw, y: by + ux * hw)); head.addLine(to: CGPoint(x: bx + uy * hw, y: by - ux * hw)); head.closeSubpath()
        for (col, grow) in [(WHITE, CGFloat(10)), (MARK_RED, CGFloat(0))] {
            c.setStrokeColor(col); c.setFillColor(col); c.setLineWidth(16 + grow)
            c.move(to: CGPoint(x: bx, y: by)); c.addLine(to: tail); c.strokePath()
            c.addPath(head); c.setLineWidth(grow); c.drawPath(using: grow > 0 ? .fillStroke : .fill)
        }
    }
    return CIImage(cgImage: c.makeImage()!)
}
func renderKeywordRank(_ text: String) -> CIImage {
    let font = CTFontCreateWithName(FONT_NAME as CFString, 104, nil)
    let (line, w) = spacedLine(text.uppercased(), font: font, color: INK, kern: 3)
    let padX: CGFloat = 40, ph: CGFloat = 122, sk: CGFloat = 26, m: CGFloat = 40
    let pw = w + padX * 2
    let c = ctx(Int(pw + sk + m * 2 + 16), Int(ph + m * 2))
    func plate(_ dx: CGFloat, _ dy: CGFloat) -> CGPath {
        let p = CGMutablePath()
        p.move(to: CGPoint(x: m + dx, y: m + dy)); p.addLine(to: CGPoint(x: m + pw + dx, y: m + dy))
        p.addLine(to: CGPoint(x: m + pw + sk + dx, y: m + ph + dy)); p.addLine(to: CGPoint(x: m + sk + dx, y: m + ph + dy)); p.closeSubpath()
        return p
    }
    c.saveGState()
    c.setShadow(offset: CGSize(width: 0, height: -8), blur: 24, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.75))
    c.setFillColor(WHITE); c.addPath(plate(12, -10)); c.fillPath()
    c.restoreGState()
    c.setFillColor(GOLD); c.addPath(plate(0, 0)); c.fillPath()
    c.textPosition = CGPoint(x: m + padX + sk / 2, y: m + 22); CTLineDraw(line, c)
    return CIImage(cgImage: c.makeImage()!)
}
// lower third drawn over live footage: slanted yellow plate with the rank number, kicker + title beside it
var CH_WIDTH: [Int: CGFloat] = [:]
func renderChapterRank(_ num: String?, _ title: String, _ kicker: String?, _ idx: Int) -> CIImage {
    let c = ctx(Int(W), Int(H))
    let n = (num ?? "").isEmpty ? nil : num
    let x0: CGFloat = 96, base: CGFloat = 112, ph: CGFloat = 184, sk: CGFloat = LOOK == "bar" ? 0 : 40
    var tx = x0
    if let nn = n {
        let nf = CTFontCreateWithName(FONT_NAME as CFString, 176, nil)
        let (nl, nw) = spacedLine((LOOK == "bar" ? "" : "#") + nn, font: nf, color: INK, kern: 2)
        let pw = nw + 84
        func plate(_ dx: CGFloat, _ dy: CGFloat) -> CGPath {
            let p = CGMutablePath()
            p.move(to: CGPoint(x: x0 + dx, y: base + dy)); p.addLine(to: CGPoint(x: x0 + pw + dx, y: base + dy))
            p.addLine(to: CGPoint(x: x0 + pw + sk + dx, y: base + ph + dy)); p.addLine(to: CGPoint(x: x0 + sk + dx, y: base + ph + dy)); p.closeSubpath()
            return p
        }
        c.saveGState()
        c.setShadow(offset: CGSize(width: 0, height: -10), blur: 30, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.7))
        c.setFillColor(WHITE); c.addPath(plate(14, -12)); c.fillPath()
        c.restoreGState()
        c.setFillColor(GOLD); c.addPath(plate(0, 0)); c.fillPath()
        c.textPosition = CGPoint(x: x0 + 42 + sk / 2, y: base + 34); CTLineDraw(nl, c)
        tx = x0 + pw + sk + 44
    }
    let tf = CTFontCreateWithName(FONT_NAME as CFString, 128, nil)
    let kf = CTFontCreateWithName("AvenirNext-Heavy" as CFString, 30, nil)
    let (tl, tw0) = spacedLine(title.uppercased(), font: tf, color: WHITE, kern: 3)
    let k = kicker ?? (n != nil ? "NEW MECHANIC" : "")
    let (kl, kw) = spacedLine(k.uppercased(), font: kf, color: GOLD, kern: 9)
    let fit = min(1, (W - tx - 160) / tw0), tw = tw0 * fit
    c.setShadow(offset: CGSize(width: 0, height: -5), blur: 18, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.9))
    if !k.isEmpty { c.textPosition = CGPoint(x: tx + 4, y: base + 146); CTLineDraw(kl, c) }
    c.saveGState(); c.translateBy(x: tx, y: base + 22); c.scaleBy(x: fit, y: fit); c.textPosition = .zero; CTLineDraw(tl, c); c.restoreGState()
    photoLock.lock(); CH_WIDTH[idx] = tx + max(tw, kw) + 60; photoLock.unlock()
    return CIImage(cgImage: c.makeImage()!)
}

// MARK: compositor
struct Item2 { let shot: Shot; let index: Int; let track: CMPersistentTrackID; let s: Double; let e: Double }
final class SegInst: NSObject, AVVideoCompositionInstructionProtocol {
    let timeRange: CMTimeRange
    let enablePostProcessing = false
    let containsTweening = true
    let requiredSourceTrackIDs: [NSValue]?
    let passthroughTrackID: CMPersistentTrackID = kCMPersistentTrackID_Invalid
    let items: [Item2]                 // 1 item = plain shot, 2 items = dissolve from items[0] to items[1]
    init(range: CMTimeRange, items: [Item2]) {
        timeRange = range; self.items = items
        requiredSourceTrackIDs = Array(Set(items.map { $0.track })).map { NSNumber(value: $0) }
    }
}

final class Comp: NSObject, AVVideoCompositing {
    let ci = CIContext(options: [.cacheIntermediates: false])
    var overlays: [Int: CIImage] = [:]; let olock = NSLock()
    var sourcePixelBufferAttributes: [String: Any]? { [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA] }
    var requiredPixelBufferAttributesForRenderContext: [String: Any] { [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA] }
    func renderContextChanged(_ c: AVVideoCompositionRenderContext) {}
    func cancelAllPendingVideoCompositionRequests() {}

    func startRequest(_ req: AVAsynchronousVideoCompositionRequest) {
        guard let inst = req.videoCompositionInstruction as? SegInst, let outPB = req.renderContext.newPixelBuffer() else {
            req.finish(with: NSError(domain: "comp", code: 1)); return
        }
        let t = req.compositionTime.seconds
        var layers: [CIImage] = []
        for it in inst.items {
            guard let pb = req.sourceFrame(byTrackID: it.track) else { continue }
            var src = CIImage(cvPixelBuffer: pb)
            // keep the native-resolution frame (e.g. 4K) for crops and insets; `src` is the 1920-wide version for full-frame use
            let hi = src, k = src.extent.width / W
            if k != 1 { src = src.transformed(by: CGAffineTransform(scaleX: 1 / k, y: 1 / k)) }
            layers.append(renderShot(src, hi, k, it, t).cropped(to: CGRect(x: 0, y: 0, width: W, height: H)))
        }
        if layers.count < inst.items.count { print(String(format: "MISSING frame at %.3f (%d of %d layers)", t, layers.count, inst.items.count)) }
        var out = layers.first ?? CIImage(color: CIColor(red: 0, green: 0, blue: 0)).cropped(to: CGRect(x: 0, y: 0, width: W, height: H))
        if layers.count == 2 {
            let a = CGFloat(ease(CGFloat(max(0, min(1, (t - inst.timeRange.start.seconds) / inst.timeRange.duration.seconds)))))
            let f = CIFilter.colorMatrix(); f.inputImage = layers[1]; f.aVector = CIVector(x: 0, y: 0, z: 0, w: a)
            out = f.outputImage!.composited(over: layers[0])
        }
        // the shot that owns this moment decides the caption height
        let owner = inst.items.count == 2 && t >= (inst.items[1].s) ? inst.items[1] : inst.items[0]
        out = overlaysFor(out, t, capY: owner.shot.capY)
        ci.render(out, to: outPB, bounds: CGRect(x: 0, y: 0, width: W, height: H), colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
        req.finish(withComposedVideoFrame: outPB)
    }

    func dim(_ img: CIImage, _ amount: CGFloat) -> CIImage {
        let f = CIFilter.colorControls(); f.inputImage = img; f.brightness = Float(-amount); f.saturation = Float(1 - 0.5 * amount)
        return f.outputImage!
    }
    func alpha(_ img: CIImage, _ a: CGFloat) -> CIImage {
        let f = CIFilter.colorMatrix(); f.inputImage = img; f.aVector = CIVector(x: 0, y: 0, z: 0, w: a); return f.outputImage!
    }
    // callout: frame dims in, region lit + boxed, magnified inset pops in and slowly pushes into the detail
    func up(_ r: CGRect, _ k: CGFloat) -> CGRect { CGRect(x: r.minX * k, y: r.minY * k, width: r.width * k, height: r.height * k) }
    func callout(_ src: CIImage, _ hi: CIImage, _ k: CGFloat, _ it: Item2, region r: R, _ t: Double) -> CIImage {
        let u = t - it.s, len = max(0.5, it.e - it.s)
        let inP = ease(CGFloat(max(0, min(1, u / 0.4))))
        let push = CGFloat(max(0, min(1, u / len)))
        let reg = ciRect(r)
        let base = dim(src, 0.34 * inP)
        let lit = src.cropped(to: reg)
        var s = min(3.2, min(1000 / reg.width, 520 / reg.height))
        let wide = reg.width * s > 880
        let below = wide && r.y + r.h / 2 <= 540
        if below { s = min(s, 400 / reg.height) }
        let iw = reg.width * s, ih = reg.height * s
        let cx: CGFloat = wide ? W / 2 : (reg.midX < W / 2 ? W * 0.72 : W * 0.28)
        let cyTL: CGFloat = wide ? (below ? 660 : 330) : 440
        let dest = CGRect(x: cx - iw / 2, y: H - cyTL - ih / 2, width: iw, height: ih)
        // content inside the inset slowly zooms in (8%) so a held freeze never looks dead
        let z = 1 + 0.08 * push
        let inner = CGRect(x: reg.midX - reg.width / z / 2, y: reg.midY - reg.height / z / 2, width: reg.width / z, height: reg.height / z)
        let sc = iw / inner.width
        var inset = hi.cropped(to: up(inner, k)).transformed(by: CGAffineTransform(scaleX: sc / k, y: sc / k))
        inset = inset.transformed(by: CGAffineTransform(translationX: dest.minX - inset.extent.minX, y: dest.minY - inset.extent.minY))
        // pop: scale from 0.88 about the inset centre
        let pop = 0.88 + 0.12 * inP
        let popT = CGAffineTransform(translationX: dest.midX, y: dest.midY).scaledBy(x: pop, y: pop).translatedBy(x: -dest.midX, y: -dest.midY)
        let shadow = CIImage(color: CIColor(red: 0, green: 0, blue: 0, alpha: 0.7)).cropped(to: dest.insetBy(dx: -18, dy: -18))
            .applyingGaussianBlur(sigma: 14).cropped(to: dest.insetBy(dx: -50, dy: -50))
        var out = alpha(lit, 1).composited(over: base)
        out = alpha(inset.composited(over: shadow).transformed(by: popT), inP).composited(over: out)
        olock.lock()
        let o: CIImage
        if let c = overlays[it.index] { o = c } else {
            let c = ctx(Int(W), Int(H))
            c.setStrokeColor(YELLOW); c.setLineWidth(6); c.stroke(dest.insetBy(dx: -3, dy: -3))
            c.setLineWidth(5); c.stroke(reg.insetBy(dx: -6, dy: -6))
            c.setLineWidth(4); c.setLineDash(phase: 0, lengths: [14, 10])
            let from = CGPoint(x: reg.midX, y: dest.midY > reg.midY ? reg.maxY + 6 : reg.minY - 6)
            let to = CGPoint(x: dest.midX, y: dest.midY > reg.midY ? dest.minY - 4 : dest.maxY + 4)
            if !dest.intersects(reg.insetBy(dx: -10, dy: -10)) { c.move(to: from); c.addLine(to: to); c.strokePath() }
            o = CIImage(cgImage: c.makeImage()!); overlays[it.index] = o
        }
        olock.unlock()
        return alpha(o, inP).composited(over: out)
    }

    func place(_ img: CIImage, _ x: CGFloat, _ y: CGFloat) -> CIImage {
        img.transformed(by: CGAffineTransform(translationX: x - img.extent.minX, y: y - img.extent.minY))
    }
    // crop `r` (CI coords, 1920x1080 space) from an image that is k times larger, scaled to w x h
    func panel(_ hi: CIImage, _ k: CGFloat, _ r: CGRect, _ w: CGFloat, _ h: CGFloat) -> CIImage {
        let s = max(w / r.width, h / r.height)
        return hi.cropped(to: up(r, k)).transformed(by: CGAffineTransform(scaleX: s / k, y: s / k))
    }
    func fitRect(cx: CGFloat, cy: CGFloat, w: CGFloat, h: CGFloat) -> CGRect {
        let ww = min(w, W), hh = min(h, H)
        return CGRect(x: min(max(cx - ww / 2, 0), W - ww), y: min(max(cy - hh / 2, 0), H - hh), width: ww, height: hh)
    }
    // split: the frozen game frame shrinks into one half while the real photo slides into the other
    func split(_ hi: CIImage, _ k: CGFloat, _ it: Item2, _ t: Double) -> CIImage {
        let shot = it.shot, vert = shot.dir == "v"
        let u = t - it.s, len = max(0.6, it.e - it.s)
        let p = ease(CGFloat(max(0, min(1, (u - 0.3) / 0.55))))
        let drift = 1 + 0.04 * CGFloat(max(0, min(1, u / len)))
        let pw = vert ? W : W / 2, ph = vert ? H / 2 : H
        let full = ciRect(shot.from ?? FULL), reg = ciRect(shot.region ?? FULL)
        let gw = vert ? W : W - (W - pw) * p, gh = vert ? H - (H - ph) * p : H      // game panel size now
        let cx = full.midX + (reg.midX - full.midX) * p, cy = full.midY + (reg.midY - full.midY) * p
        var rw: CGFloat, rh: CGFloat
        if vert { rw = full.width + (reg.width - full.width) * p; rh = rw * gh / gw }
        else { rh = full.height + (reg.height - full.height) * p; rw = rh * gw / gh }
        let sc = min(1, W / rw, H / rh); rw *= sc / drift; rh *= sc / drift
        let game = place(panel(hi, k, fitRect(cx: cx, cy: cy, w: rw, h: rh), gw, gh), 0, H - gh).cropped(to: CGRect(x: 0, y: H - gh, width: gw, height: gh))
        var out = game.composited(over: CIImage(color: CIColor(red: 0, green: 0, blue: 0)).cropped(to: CGRect(x: 0, y: 0, width: W, height: H)))
        guard let path = shot.img else { return out }
        let ph0 = photo(path), pk = ph0.extent.width / W
        var ir = ciRect(shot.imgRegion ?? R(x: vert ? 0 : 480, y: vert ? 270 : 0, w: Double(pw), h: Double(ph)))
        ir = CGRect(x: ir.midX - ir.width / drift / 2, y: ir.midY - ir.height / drift / 2, width: ir.width / drift, height: ir.height / drift)
        let px = vert ? 0 : W - pw * p, py = vert ? -ph * (1 - p) : 0
        let pic = place(panel(ph0, pk, ir, pw, ph), px, py).cropped(to: CGRect(x: px, y: py, width: pw, height: ph))
        out = pic.composited(over: out)
        let white = CIImage(color: CIColor(red: 1, green: 1, blue: 1))
        out = (vert ? white.cropped(to: CGRect(x: 0, y: py + ph - 3, width: W, height: 6)) : white.cropped(to: CGRect(x: px - 3, y: 0, width: 6, height: H))).composited(over: out)
        let la = ease(CGFloat(max(0, min(1, (u - 0.75) / 0.3))))
        if la > 0 {
            let gl = panelLabel(shot.label ?? "GTA 6", accent: GREEN), rl = panelLabel(shot.imgLabel ?? "REAL LIFE", accent: YELLOW)
            // game label: bottom-left of its panel; photo label: bottom-left of its panel
            out = alpha(place(gl, 44, (vert ? H - gh : 0) + 44), la).composited(over: out)
            out = alpha(place(rl, px + 44, py + 44), la).composited(over: out)
            if let cr = shot.credit { let c = creditLine(cr); out = alpha(place(c, px + pw - c.extent.width - 16, py + 10), la).composited(over: out) }
        }
        return out
    }

    func renderShot(_ src: CIImage, _ hi0: CIImage, _ k0: CGFloat, _ it: Item2, _ t: Double) -> CIImage {
        let shot = it.shot
        var hi = hi0, k = k0
        if shot.mode == "split" { return split(hi, k, it, t) }
        if shot.mode == "photo", let path = shot.img { hi = photo(path); k = hi.extent.width / W }
        if shot.mode == "callout", let r = shot.region { return callout(src, hi, k, it, region: r, t) }
        let p = ease(CGFloat(max(0, min(1, (t - it.s) / max(0.001, it.e - it.s)))))
        let a = ciRect(shot.from ?? shot.to ?? FULL), b = ciRect(shot.to ?? shot.from ?? FULL)
        let r = lerp(a, b, p)
        let s = max(W / r.width, H / r.height)
        let img = hi.cropped(to: up(r, k)).transformed(by: CGAffineTransform(scaleX: s / k, y: s / k))
        let dx = (W - r.width * s) / 2, dy = (H - r.height * s) / 2
        var out = img.transformed(by: CGAffineTransform(translationX: dx - img.extent.minX, y: dy - img.extent.minY))
        if let m = shot.mark {
            let u = t - it.s - (m.at ?? 0)
            if u >= 0 {
                let cx = (CGFloat(m.x) - r.minX) * s + dx, cy = (H - CGFloat(m.y) - r.minY) * s + dy
                let eR = ciRect(shot.to ?? shot.from ?? FULL), sEnd = max(W / eR.width, H / eR.height)
                olock.lock()
                let img: CIImage
                if let c = overlays[it.index] { img = c } else { img = renderMark(CGFloat(m.r) * sEnd, m.arrow); overlays[it.index] = img }
                olock.unlock()
                let p = CGFloat(min(1, u / 0.26))
                let pop = (0.55 + 0.45 * ease(p) + 0.1 * sin(.pi * p)) * (s / sEnd)
                let e = img.extent
                let tr = CGAffineTransform(translationX: cx, y: cy).scaledBy(x: pop, y: pop).translatedBy(x: -e.midX, y: -e.midY)
                out = alpha(img.transformed(by: tr), min(1, CGFloat(u / 0.1))).composited(over: out.cropped(to: CGRect(x: 0, y: 0, width: W, height: H)))
            }
        }
        if let tg = shot.tag {
            let l = panelLabel(tg, accent: YELLOW)
            out = place(l, W - l.extent.width - 44, H - l.extent.height - 44).composited(over: out.cropped(to: CGRect(x: 0, y: 0, width: W, height: H)))
        }
        if shot.mode == "photo" {
            let la = ease(CGFloat(max(0, min(1, (t - it.s - 0.2) / 0.3))))
            out = alpha(place(panelLabel(shot.imgLabel ?? "REAL LIFE", accent: YELLOW), 44, 44), la).composited(over: out.cropped(to: CGRect(x: 0, y: 0, width: W, height: H)))
            if let cr = shot.credit { let c = creditLine(cr); out = alpha(place(c, W - c.extent.width - 16, 10), la).composited(over: out) }
        }
        return out
    }

    func overlaysFor(_ base: CIImage, _ t: Double, capY: Double?) -> CIImage {
        var out = base
        let FR = CGRect(x: 0, y: 0, width: W, height: H)
        if GRADE {
            let cc = CIFilter.colorControls(); cc.inputImage = out; cc.saturation = 1.12; cc.contrast = 1.07; cc.brightness = -0.01
            let g = CIFilter.gammaAdjust(); g.inputImage = cc.outputImage!; g.power = 0.86     // lift shadows so night scenes read
            let v = CIFilter.vignette(); v.inputImage = g.outputImage!; v.intensity = 0.35; v.radius = 2.0
            out = v.outputImage!.cropped(to: FR)
        }
        // chapter card: frame dims, bars close in, title + kicker + growing rule
        var lbAmount: CGFloat = 0
        var lower: CIImage? = nil
        if TEXT_STYLE == "rank", let i = CHS.firstIndex(where: { t >= $0.start && t < $0.end }) {
            // footage keeps playing at full brightness; only a soft scrim under the title
            let it = CHS[i], u = t - it.start, len = it.end - it.start
            let inP = ease(CGFloat(min(1, u / 0.5))), outP = u > len - 0.45 ? ease(CGFloat((u - (len - 0.45)) / 0.45)) : 0
            let a = inP * (1 - outP)
            let g = CIFilter.linearGradient()
            g.point0 = CGPoint(x: 0, y: 0); g.point1 = CGPoint(x: 0, y: 470)
            g.color0 = CIColor(red: 0, green: 0, blue: 0, alpha: 0.78); g.color1 = CIColor(red: 0, green: 0, blue: 0, alpha: 0)
            out = alpha(g.outputImage!.cropped(to: FR), a).composited(over: out)
            let img = chCache.get(i, CHS)
            photoLock.lock(); let cw = CH_WIDTH[i] ?? W; photoLock.unlock()
            let wipe = ease(CGFloat(min(1, max(0, (u - 0.08) / 0.55))))
            let shift = -(1 - inP) * 36 + outP * 24
            let vis = img.cropped(to: CGRect(x: 0, y: 0, width: 80 + (cw - 80) * wipe, height: 420)).transformed(by: CGAffineTransform(translationX: shift, y: 0))
            var l = alpha(vis, 1 - outP)
            let rw = (cw - 96 - 60) * ease(CGFloat(min(1, max(0, (u - 0.35) / 0.7))))
            let rule = CIImage(color: CIColor(cgColor: GOLD)).cropped(to: CGRect(x: 96 + 14, y: 78, width: max(0, rw), height: 5))
            l = alpha(rule, a).composited(over: l)
            lower = l
        } else if let i = CHS.firstIndex(where: { t >= $0.start && t < $0.end }) {
            let it = CHS[i], u = t - it.start, len = it.end - it.start
            let inP = ease(CGFloat(min(1, u / 0.45))), outP = u > len - 0.45 ? ease(CGFloat((u - (len - 0.45)) / 0.45)) : 0
            let a = inP * (1 - outP)
            lbAmount = max(lbAmount, a)
            out = dim(out, 0.5 * a).cropped(to: FR)
            let blur = out.clampedToExtent().applyingGaussianBlur(sigma: Double(10 * a)).cropped(to: FR)
            out = blur
            let img = chCache.get(i, CHS)
            let rise = (1 - inP) * 30
            out = alpha(img.transformed(by: CGAffineTransform(translationX: 0, y: -rise)), a).composited(over: out)
            let rw = 560 * ease(CGFloat(min(1, max(0, (u - 0.2) / 0.6))))
            let rule = CIImage(color: CIColor(red: 0.45, green: 0.93, blue: 0.12)).cropped(to: CGRect(x: W / 2 - rw / 2, y: H / 2 - 92, width: rw, height: 6))
            out = alpha(rule, a).composited(over: out)
        }
        for r in LETTERBOX where t >= r[0] - 0.5 && t < r[1] + 0.5 {
            let a = min(1, (t - (r[0] - 0.5)) / 0.5, ((r[1] + 0.5) - t) / 0.5)
            lbAmount = max(lbAmount, CGFloat(ease(CGFloat(max(0, a)))))
        }
        if lbAmount > 0 {
            let bh = 138 * lbAmount
            let bar = CIImage(color: CIColor(red: 0, green: 0, blue: 0))
            out = bar.cropped(to: CGRect(x: 0, y: 0, width: W, height: bh)).composited(over: out)
            out = bar.cropped(to: CGRect(x: 0, y: H - bh, width: W, height: bh)).composited(over: out)
        }
        // keyword callouts: slide in from the left, hold, fade
        if let i = KWS.firstIndex(where: { t >= $0.start && t < $0.end }) {
            let it = KWS[i], u = t - it.start, len = it.end - it.start
            let inP = ease(CGFloat(min(1, u / 0.3))), outP = u > len - 0.3 ? ease(CGFloat((u - (len - 0.3)) / 0.3)) : 0
            let img = kwCache.get(i, KWS), e = img.extent
            let x = 110 - (1 - inP) * 60 + outP * 20
            let yTL: CGFloat = 690
            if TEXT_STYLE == "rank" && !KW_PLATE {
                // text only: fades in while rising a few pixels
                let xr: CGFloat = 96 - 50, y = H - 720 - e.height / 2 - (1 - inP) * 22
                out = alpha(img.transformed(by: CGAffineTransform(translationX: xr - e.minX, y: y - e.minY)), inP * (1 - outP)).composited(over: out)
            } else if TEXT_STYLE == "rank" {
                // plate wipes in from the left, then fades
                let xr: CGFloat = 70, y = H - 720 - e.height / 2
                let wipe = ease(CGFloat(min(1, u / 0.26)))
                let placed = img.transformed(by: CGAffineTransform(translationX: xr - e.minX, y: y - e.minY))
                out = alpha(placed.cropped(to: CGRect(x: xr, y: y, width: e.width * wipe, height: e.height)), 1 - outP).composited(over: out)
            } else {
            out = alpha(img.transformed(by: CGAffineTransform(translationX: x - e.minX, y: H - yTL - e.height / 2 - e.minY)), inP * (1 - outP)).composited(over: out)
            }
        }
        if let i = POPS.firstIndex(where: { t >= $0.start && t < $0.end }) {
            let it = POPS[i], u = t - it.start, len = it.end - it.start
            let inP = ease(CGFloat(min(1, u / 0.22))), outP = u > len - 0.3 ? ease(CGFloat((u - (len - 0.3)) / 0.3)) : 0
            let a = inP * (1 - outP)
            out = dim(out, 0.42 * a).cropped(to: CGRect(x: 0, y: 0, width: W, height: H))
            let img = popCache.get(i, POPS), e = img.extent
            let sc = 0.8 + 0.2 * inP
            var c = img.transformed(by: CGAffineTransform(translationX: -e.midX, y: -e.midY)).transformed(by: CGAffineTransform(scaleX: sc, y: sc))
            c = c.transformed(by: CGAffineTransform(translationX: W / 2, y: H / 2 + 40))
            out = alpha(c, a).composited(over: out)
        }
        if let i = TAGS.firstIndex(where: { t >= $0.start && t < $0.end }) {
            let it = TAGS[i], a = CGFloat(ease(CGFloat(min(1, (t - it.start) / 0.3))))
            let img = tagCache.get(i, TAGS), e = img.extent
            out = alpha(img.transformed(by: CGAffineTransform(translationX: W - 36 - e.width - e.minX, y: H - 36 - e.height - e.minY)), a).composited(over: out)
        }
        if let i = CAPS.firstIndex(where: { t >= $0.start && t < $0.end }) {
            let it = CAPS[i]
            let a = CGFloat(min(1, (t - it.start) / 0.08, (it.end - t) / 0.08))
            let img = capCache.get(i, CAPS), e = img.extent
            out = alpha(img.transformed(by: CGAffineTransform(translationX: W / 2 - e.midX, y: H - CGFloat(capY ?? 930) - e.midY)), max(0, a)).composited(over: out)
        }
        if let bt = BADGE_TIMES.first(where: { t >= $0 && t < $0 + 1.6 }), let badge = BADGE {
            let u = t - bt
            let inP = ease(CGFloat(min(1, u / 0.28))), outP = u > 1.3 ? ease(CGFloat((u - 1.3) / 0.3)) : 0
            let y = H - 300 + (1 - inP) * -120 + outP * 50
            let e = badge.extent
            out = alpha(badge, inP * (1 - outP)).transformed(by: CGAffineTransform(translationX: W / 2 - e.midX, y: y - e.midY)).composited(over: out)
        }
        if let l = lower { out = l.composited(over: out) }
        if SHOW_LOGO, let logo = LOGO { out = logo.composited(over: out) }
        if let st = SNAPS.first(where: { t >= $0 - 0.03 && t < $0 + 0.3 }) {
            let u = t - st
            let a = u < 0 ? CGFloat((u + 0.03) / 0.03) * 0.2 : CGFloat(0.2 * exp(-u * 16))
            out = alpha(CIImage(color: CIColor(red: 1, green: 1, blue: 1)).cropped(to: CGRect(x: 0, y: 0, width: W, height: H)), a).composited(over: out)
        }
        if let ft = FLASHES.first(where: { t >= $0 - 0.06 && t < $0 + 0.35 }) {
            let u = t - ft
            let a = u < 0 ? CGFloat((u + 0.06) / 0.06) * 0.8 : CGFloat(0.8 * exp(-u * 9))
            out = alpha(CIImage(color: CIColor(red: 1, green: 1, blue: 1)).cropped(to: CGRect(x: 0, y: 0, width: W, height: H)), a).composited(over: out)
        }
        return out
    }
}

// MARK: build
setvbuf(stdout, nil, _IONBF, 0)
let args = CommandLine.arguments
let editURL = URL(fileURLWithPath: args[1])
let edit = try JSONDecoder().decode(Edit.self, from: Data(contentsOf: editURL))
let NOCAPS = args.contains("--nocaps")
var outURL = URL(fileURLWithPath: edit.out)
if NOCAPS {
    let dir = outURL.deletingLastPathComponent().appendingPathComponent("no-subtitles")
    try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    outURL = dir.appendingPathComponent(outURL.lastPathComponent)
}
func T(_ s: Double) -> CMTime { CMTime(value: CMTimeValue((s * 600).rounded()), timescale: 600) }

var srcTracks: [String: AVAssetTrack] = [:], srcDur: [String: Double] = [:]
var keepAlive: [AVURLAsset] = []
for (k, p) in edit.sources {
    let a = AVURLAsset(url: URL(fileURLWithPath: p)); keepAlive.append(a)
    let (tr, d) = wait { (try await a.loadTracks(withMediaType: .video).first!, try await a.load(.duration).seconds) }
    srcTracks[k] = tr; srcDur[k] = d
}
let comp = AVMutableComposition()
let vTracks = [comp.addMutableTrack(withMediaType: .video, preferredTrackID: 1)!, comp.addMutableTrack(withMediaType: .video, preferredTrackID: 2)!]
let voTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 3)!
let hookTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 4)!
let musicTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 5)!

var speech: [(Double, Double)] = []
let DT = 0.01
var ENV: [Float] = []
for v in edit.vo {
    let url = URL(fileURLWithPath: v.file)
    let a = AVURLAsset(url: url); keepAlive.append(a)
    let (tr, dur) = wait { (try await a.loadTracks(withMediaType: .audio).first!, try await a.load(.duration).seconds) }
    try voTrack.insertTimeRange(CMTimeRange(start: .zero, duration: T(dur)), of: tr, at: T(v.at))
    speech.append((v.at, v.at + dur))
    if edit.timedCaptions != true {
        let e = envelope(url), startIdx = Int(v.at / DT)
        if ENV.count < startIdx { ENV += Array(repeating: 0, count: startIdx - ENV.count) }
        for (k, x) in e.enumerated() { let j = startIdx + k; if j < ENV.count { ENV[j] = max(ENV[j], x) } else { ENV.append(x) } }
    }
}
let voEnd = speech.map { $0.1 }.max() ?? 0

var shots = edit.shots
if let last = shots.last, last.out[1] < voEnd + 0.5 {
    let d = voEnd + 0.5 - last.out[1]; let speed = (last.src[1] - last.src[0]) / (last.out[1] - last.out[0])
    shots[shots.count - 1].out[1] += d; shots[shots.count - 1].src[1] += d * speed
}
let XF = edit.xfade ?? 0.3
let total = shots.last!.out[1]
// half-dissolve length on each boundary (0 = hard cut)
var hB: [Double] = [0]
for i in 1..<shots.count {
    let lenPrev = shots[i - 1].out[1] - shots[i - 1].out[0], lenCur = shots[i].out[1] - shots[i].out[0]
    hB.append(shots[i].join == true ? 0 : min(XF / 2, lenPrev / 3, lenCur / 3))
}
hB.append(0)
var trackEnd = [0.0, 0.0]
var items: [Item2] = []
for (i, sh) in shots.enumerated() {
    guard let st = srcTracks[sh.s] else { fatalError("unknown source \(sh.s)") }
    let k = i % 2
    let s = sh.out[0], e = sh.out[1], hp = hB[i], hn = hB[i + 1]
    let speed = (sh.src[1] - sh.src[0]) / (e - s)
    var a0 = sh.src[0] - hp * speed, a1 = sh.src[1] + hn * speed
    a0 = max(0, a0); a1 = min(srcDur[sh.s]! - 0.05, a1)
    let o0 = s - hp, o1 = e + hn
    if o0 > trackEnd[k] + 0.0005 { vTracks[k].insertEmptyTimeRange(CMTimeRange(start: T(trackEnd[k]), end: T(o0))) }
    let srcRange = CMTimeRange(start: T(a0), end: T(a1))
    do { try vTracks[k].insertTimeRange(srcRange, of: st, at: T(o0)) } catch { print("shot insert failed", i, sh.s, sh.src, error); throw error }
    let outDur = T(o1) - T(o0)
    if srcRange.duration != outDur { vTracks[k].scaleTimeRange(CMTimeRange(start: T(o0), duration: srcRange.duration), toDuration: outDur) }
    trackEnd[k] = o1
    items.append(Item2(shot: sh, index: i, track: vTracks[k].trackID, s: s, e: e))
}
// instructions: plain segment per shot, dissolve segment on each soft boundary
var insts: [SegInst] = []
var cur = 0.0
for i in 0..<items.count {
    let segEnd = i + 1 < items.count ? items[i].e - hB[i + 1] : total
    if T(segEnd) > T(cur) { insts.append(SegInst(range: CMTimeRange(start: T(cur), end: T(segEnd)), items: [items[i]])); cur = segEnd }
    if i + 1 < items.count && hB[i + 1] > 0 {
        let bEnd = items[i].e + hB[i + 1]
        insts.append(SegInst(range: CMTimeRange(start: T(cur), end: T(bEnd)), items: [items[i], items[i + 1]]))
        cur = bEnd
    }
}

// sanity: instructions must tile [0, total] exactly
var expect = CMTime.zero
for (k, ins) in insts.enumerated() {
    if ins.timeRange.start != expect || ins.timeRange.duration <= .zero { print("BAD instruction", k, ins.timeRange.start.seconds, ins.timeRange.end.seconds, "expected", expect.seconds) }
    expect = ins.timeRange.end
}
if expect != T(total) { print("BAD end", expect.seconds, total) }
for (k, tr) in vTracks.enumerated() { print("track", k, tr.timeRange.end.seconds) }
// music bed: hook at the start, loop underneath; loop sits low under speech and lifts in the gaps
let hookAsset = AVURLAsset(url: URL(fileURLWithPath: edit.hook ?? HOOK_DEFAULT)), musicAsset = AVURLAsset(url: URL(fileURLWithPath: edit.music ?? MUSIC_DEFAULT))
let (hookA, hookDur, musicA, musicDur) = wait { () -> (AVAssetTrack, Double, AVAssetTrack, Double) in
    (try await hookAsset.loadTracks(withMediaType: .audio).first!, try await hookAsset.load(.duration).seconds,
     try await musicAsset.loadTracks(withMediaType: .audio).first!, try await musicAsset.load(.duration).seconds)
}
let hookLen = min(hookDur, total)
try hookTrack.insertTimeRange(CMTimeRange(start: .zero, duration: T(hookLen)), of: hookA, at: .zero)
let musicStart = max(0, hookLen - 1.0)
var mCursor = musicStart
while mCursor < total {
    let len = min(musicDur, total - mCursor)
    try musicTrack.insertTimeRange(CMTimeRange(start: .zero, duration: T(len)), of: musicA, at: T(mCursor))
    mCursor += len
}

// captions
for (ci, c) in edit.captions.enumerated() where !NOCAPS {
    if edit.timedCaptions == true {
        let text = c.chunks.joined(separator: " ")
        CAPS.append(Item(start: c.t[0], end: c.t[1], make: { renderText(text, size: 64, maxW: 1500) }))
        if args.contains("--frames") { print(String(format: "cap %6.2f-%6.2f  %@", c.t[0], c.t[1], text)) }
        continue
    }
    var words: [String] = [], chunkOf: [Int] = []
    for (k, ch) in c.chunks.enumerated() { for w in ch.split(separator: " ") { words.append(String(w)); chunkOf.append(k) } }
    guard !words.isEmpty else { continue }
    let spans = alignWords(words, c.t[0], c.t[1], env: ENV, dt: DT)
    let nextStart = ci + 1 < edit.captions.count ? edit.captions[ci + 1].t[0] : c.t[1] + 0.6
    for k in 0..<c.chunks.count {
        guard let first = chunkOf.firstIndex(of: k) else { continue }
        let s = spans[first].0
        let e: Double = k + 1 < c.chunks.count ? spans[chunkOf.firstIndex(of: k + 1)!].0 : min(c.t[1] + 0.5, nextStart)
        let text = c.chunks[k]
        CAPS.append(Item(start: s, end: max(e, s + 0.3), make: { renderText(text, size: 64, maxW: 1500) }))
    }
}
for c in edit.cards ?? [] {
    let num = c.num, title = c.title, tag = c.tag
    POPS.append(Item(start: c.t[0], end: c.t[0] + 1.3, make: {
        let n = num.map { renderText($0, size: 190, maxW: 1200, base: GREEN, stroke: 14) }
        let tt = renderText(title, size: 78, maxW: 1500)
        guard let nn = n else { return tt }
        let gap: CGFloat = -30
        let w = max(nn.extent.width, tt.extent.width), h = nn.extent.height + tt.extent.height + gap
        let top = nn.transformed(by: CGAffineTransform(translationX: (w - nn.extent.width) / 2, y: tt.extent.height + gap))
        let bot = tt.transformed(by: CGAffineTransform(translationX: (w - tt.extent.width) / 2, y: 0))
        return top.composited(over: bot).cropped(to: CGRect(x: 0, y: 0, width: w, height: h))
    }))
    TAGS.append(Item(start: c.t[0] + 1.2, end: c.t[1], make: { renderTag(num, tag) }))
}
BADGE_TIMES = edit.badges ?? []
TEXT_STYLE = edit.textStyle ?? "classic"
let RANK = TEXT_STYLE == "rank"
if let a = edit.accent, a.count == 3 { GOLD = CGColor(red: a[0], green: a[1], blue: a[2], alpha: 1) }
FONT_NAME = edit.font ?? FONT_NAME; LOOK = edit.look ?? ""; SHOW_LOGO = edit.logo ?? true
if edit.logoPath != nil || edit.logoSize != nil || edit.logoAlpha != nil { LOGO = makeLogo(edit.logoPath ?? LOGO_PATH, CGFloat(edit.logoSize ?? 150), CGFloat(edit.logoAlpha ?? 0.65)) }
KW_PLATE = edit.kwPlate ?? false
for k in edit.keywords ?? [] where !NOCAPS { let tx = k.text; KWS.append(Item(start: k.t[0], end: k.t[1], make: { RANK ? (KW_PLATE ? renderKeywordRank(tx) : renderKeywordClean(tx)) : renderKeyword(tx) })) }
for (ci, c) in (edit.chapters ?? []).enumerated() { let n = c.num, ti = c.title, ki = c.kicker; CHS.append(Item(start: c.t[0], end: c.t[1], make: { RANK ? renderChapterRank(n, ti, ki, ci) : renderChapter(n, ti, ki) })) }
GRADE = edit.grade ?? false; LETTERBOX = edit.letterbox ?? []; FLASHES = edit.flashes ?? []; SNAPS = edit.snaps ?? []
var sfxTracks: [AVMutableCompositionTrack] = []
var sfxParams: [AVMutableAudioMixInputParameters] = []
var sfxEnd: [Double] = []
for fx in (edit.sfx ?? []).sorted(by: { $0.at < $1.at }) {
    let a = AVURLAsset(url: URL(fileURLWithPath: fx.file)); keepAlive.append(a)
    let (tr, d) = wait { (try await a.loadTracks(withMediaType: .audio).first!, try await a.load(.duration).seconds) }
    var k = sfxEnd.firstIndex(where: { $0 <= fx.at }) ?? -1
    if k < 0 { sfxTracks.append(comp.addMutableTrack(withMediaType: .audio, preferredTrackID: Int32(10 + sfxTracks.count))!)
               sfxParams.append(AVMutableAudioMixInputParameters(track: sfxTracks.last!)); sfxEnd.append(0); k = sfxTracks.count - 1 }
    let at = max(0, fx.at), len = min(d, total - at)
    if len <= 0 { continue }
    try sfxTracks[k].insertTimeRange(CMTimeRange(start: .zero, duration: T(len)), of: tr, at: T(at))
    sfxParams[k].setVolume(Float(fx.vol ?? 0.5), at: T(at))
    sfxEnd[k] = at + len
}

// audio can end a few ms after the last video frame: stretch the final instruction to the full composition
if let lastI = insts.last, comp.duration > lastI.timeRange.end {
    insts[insts.count - 1] = SegInst(range: CMTimeRange(start: lastI.timeRange.start, end: comp.duration), items: lastI.items)
}
let vc = AVMutableVideoComposition()
vc.customVideoCompositorClass = Comp.self
vc.frameDuration = CMTime(value: 1, timescale: 30)
vc.renderSize = CGSize(width: W, height: H)
vc.instructions = insts

let mix = AVMutableAudioMix()
let hookVol = Float(edit.hookVol ?? 0.28), musicVol = Float(edit.musicVol ?? 0.09)
let highVol: Float = edit.duckHigh.map { Float($0) } ?? musicVol
let vp = AVMutableAudioMixInputParameters(track: voTrack); vp.setVolume(Float(edit.voVol ?? 1.0), at: .zero)
let hp = AVMutableAudioMixInputParameters(track: hookTrack)
hp.setVolume(hookVol, at: .zero)
hp.setVolumeRamp(fromStartVolume: hookVol, toEndVolume: 0, timeRange: CMTimeRange(start: T(max(0, hookLen - 1.0)), end: T(hookLen)))
let mp = AVMutableAudioMixInputParameters(track: musicTrack)
var keys: [(Double, Float)] = [(musicStart, 0), (musicStart + 1.0, musicVol)]
let sp = speech.sorted { $0.0 < $1.0 }
for (i, s) in sp.enumerated() {
    let gapStart = s.1, gapEnd = i + 1 < sp.count ? sp[i + 1].0 : total - 2.0
    if gapEnd - gapStart >= 0.8 && gapStart + 0.05 > keys.last!.0 {
        keys.append((gapStart + 0.05, musicVol)); keys.append((gapStart + 0.4, highVol))
        keys.append((gapEnd - 0.35, highVol)); keys.append((gapEnd - 0.05, i + 1 < sp.count ? musicVol : highVol))
    }
}
keys.append((max(keys.last!.0 + 0.1, total - 2.0), keys.last!.1)); keys.append((total, 0))
mp.setVolume(0, at: .zero)
for (a, b) in zip(keys, keys.dropFirst()) where b.0 > a.0 {
    mp.setVolumeRamp(fromStartVolume: a.1, toEndVolume: b.1, timeRange: CMTimeRange(start: T(a.0), end: T(b.0)))
}
mix.inputParameters = [vp, hp, mp] + sfxParams
print("comp", String(format: "%.2f", comp.duration.seconds), "shots", shots.count, "segments", insts.count)
final class VDel: NSObject, AVVideoCompositionValidationHandling {
    func videoComposition(_ c: AVVideoComposition, shouldContinueValidatingAfterFindingInvalidValueForKey key: String) -> Bool { print("INVALID key", key); return true }
    func videoComposition(_ c: AVVideoComposition, shouldContinueValidatingAfterFindingEmptyTimeRange r: CMTimeRange) -> Bool { print("EMPTY range", r.start.seconds, r.end.seconds); return true }
    func videoComposition(_ c: AVVideoComposition, shouldContinueValidatingAfterFindingInvalidTimeRangeIn i: AVVideoCompositionInstructionProtocol) -> Bool { print("INVALID range", i.timeRange.start.seconds, i.timeRange.end.seconds); return true }
    func videoComposition(_ c: AVVideoComposition, shouldContinueValidatingAfterFindingInvalidTrackIDIn i: AVVideoCompositionInstructionProtocol, layerInstruction l: AVVideoCompositionLayerInstruction, asset: AVAsset) -> Bool { print("INVALID track in", i.timeRange.start.seconds); return true }
}
if args.contains("--validate") {
    let ok = vc.isValid(for: comp, timeRange: CMTimeRange(start: .zero, duration: comp.duration), validationDelegate: VDel())
    print("valid:", ok, "comp dur", comp.duration.seconds, "insts end", insts.last!.timeRange.end.seconds); exit(0)
}

if let fi = args.firstIndex(of: "--frames") {
    let gen = AVAssetImageGenerator(asset: comp); gen.videoComposition = vc
    gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero
    for ts in args[(fi + 1)...] {
        let img = try gen.copyCGImage(at: T(Double(ts)!), actualTime: nil)
        let u = outURL.deletingPathExtension().appendingPathExtension("f\(ts).jpg")
        let d = CGImageDestinationCreateWithURL(u as CFURL, UTType.jpeg.identifier as CFString, 1, nil)!
        CGImageDestinationAddImage(d, img, [kCGImageDestinationLossyCompressionQuality: 0.8] as CFDictionary); CGImageDestinationFinalize(d)
    }
    print("frames dumped"); exit(0)
}

try? FileManager.default.removeItem(at: outURL)
let reader = try AVAssetReader(asset: comp)
let vOut = AVAssetReaderVideoCompositionOutput(videoTracks: comp.tracks(withMediaType: .video),
                                               videoSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
vOut.videoComposition = vc; vOut.alwaysCopiesSampleData = false; reader.add(vOut)
let aOut = AVAssetReaderAudioMixOutput(audioTracks: comp.tracks(withMediaType: .audio), audioSettings: [
    AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: 48000, AVNumberOfChannelsKey: 2,
    AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsNonInterleaved: false])
aOut.audioMix = mix; reader.add(aOut)
let writer = try AVAssetWriter(outputURL: outURL, fileType: .mp4)
writer.shouldOptimizeForNetworkUse = edit.fastStart ?? true
let vIn = AVAssetWriterInput(mediaType: .video, outputSettings: [
    AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: Int(W), AVVideoHeightKey: Int(H),
    AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: edit.bitrate ?? 20_000_000, AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
                                      AVVideoMaxKeyFrameIntervalKey: 60, AVVideoExpectedSourceFrameRateKey: 30]])
let aIn = AVAssetWriterInput(mediaType: .audio, outputSettings: [
    AVFormatIDKey: kAudioFormatMPEG4AAC, AVSampleRateKey: 48000, AVNumberOfChannelsKey: 2, AVEncoderBitRateKey: 192_000])
vIn.expectsMediaDataInRealTime = false; aIn.expectsMediaDataInRealTime = false
writer.add(vIn); writer.add(aIn)
reader.startReading(); writer.startWriting(); writer.startSession(atSourceTime: .zero)
let group = DispatchGroup()
func pump(_ input: AVAssetWriterInput, _ output: AVAssetReaderOutput, _ label: String) {
    group.enter()
    input.requestMediaDataWhenReady(on: DispatchQueue(label: label)) {
        while input.isReadyForMoreMediaData {
            guard let buf = output.copyNextSampleBuffer() else { input.markAsFinished(); group.leave(); return }
            input.append(buf)
        }
    }
}
pump(vIn, vOut, "v"); pump(aIn, aOut, "a"); group.wait()
let done = DispatchSemaphore(value: 0); writer.finishWriting { done.signal() }; done.wait()
print(outURL.lastPathComponent, "status", writer.status.rawValue, writer.error?.localizedDescription ?? "ok", "reader", reader.status.rawValue, reader.error?.localizedDescription ?? "", String(format: "%.1fs", total))
