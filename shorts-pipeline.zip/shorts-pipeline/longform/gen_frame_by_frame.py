#!/usr/bin/env python3
"""v2 edit list for 'GTA 6 Frame by Frame — 25 details'.

Timing is taken from the voiceover itself:
  * each voiceover chunk is split at every pause >= 0.12 s (tools/pauses), words are mapped onto those
    speech phrases with a DP (syllable length + punctuation), so every word has a measured time;
  * captions are shown phrase by phrase at those measured times;
  * every shot starts on the sentence it illustrates (anchors in PLAN), 0.12 s before the words.
Footage rules:
  * live footage plays at real speed (never slower than 0.8x) and never crosses a hard cut in the source
    (cut lists from tools/cuts); if a clip runs out, its last frame is held with the push continuing;
  * freezes are either callouts (animated inset) or slow zooms / pans across the frozen frame.
"""
import json, os, re, subprocess, bisect

HOME = os.path.expanduser("~")
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = f"{HOME}/Downloads/GTA6 Long-form - Frame by Frame"
TOOLS = f"{HOME}/Youtube/shorts-pipeline/tools"
SRC = {
    "t1": f"{HOME}/Downloads/Grand Theft Auto VI Trailer 1 - (1080p).mp4",
    "t2": f"{HOME}/Downloads/Grand Theft Auto VI Trailer 2.mp4",
    "el": f"{HOME}/Downloads/GTAVI_An_Extended_Look.mp4",
}
CUTS = {k: [float(x) for x in open(f"{HERE}/cuts_{k}.txt")] for k in SRC}
SRCLEN = {"t1": 90.0, "t2": 166.7, "el": 1608.0}
LEAD, TAIL = 0.45, 0.55

def R(x, y, w, h): return {"x": round(x), "y": round(y), "w": round(w), "h": round(h)}
def box169(cx, cy, w, src="t1"):
    h = w * 9 / 16
    y0, y1 = (108, 972) if src == "t2" else (0, 1080)
    x = min(max(cx - w / 2, 0), 1920 - w); y = min(max(cy - h / 2, y0), y1 - h)
    return R(x, y, w, h)
FULL = {"t1": R(0, 0, 1920, 1080), "el": R(0, 0, 1920, 1080), "t2": R(192, 108, 1536, 864)}   # t2 is letterboxed

# beats: (anchor, kind, src, time, param)
#   anchor = sentence index (fraction = part-way through that sentence); the first beat always starts with the card
#   m = live footage from `time`, param = push-in focus (x, y) ; c = freeze + callout, param = region
#   z = freeze, zoom from full frame into rect ; p = freeze, pan from the previous zoom rect to rect (same frame)
PLAN = {
 "00": ("", [
   (0, "m", "el", 554.4, (1150, 620)), (1, "z", "t1", 58.5, box169(940, 450, 900)), (2, "m", "el", 556.8, (1160, 600)),
   (3, "m", "t1", 11.0, (960, 540)), (3.55, "m", "t2", 34.7, (1040, 500)), (4, "m", "el", 1104.1, (960, 540), {"cut": True}),
   (5, "m", "t2", 36.4, (1040, 560), {"cut": True}), (6, "m", "t1", 63.6, (1000, 500), {"cut": True}), (7, "m", "t1", 41.4, (960, 540), {"cut": True}),
   (8, "m", "t1", [43.95, 49.95, 51.17, 52.2], (960, 540), {"cut": True}), (9, "m", "t1", [46.6, 49.95, 55.05, 36.0], (960, 540)), (10, "z", "t1", 58.5, box169(940, 420, 700)),
   (11, "m", "el", 559.0, (1160, 560))]),
 "25": ("TRAILER 1 · TRAILER 2 · EXTENDED LOOK", [
   (0, "m", "t1", 84.0, (960, 470)), (3, "c", "t1", 86.8, R(560, 900, 800, 90)), (4, "c", "t2", 162.0, R(620, 860, 680, 100)),
   (5, "z", "el", 1594.0, R(440, 250, 1040, 585)), (5.55, "p", "el", 1594.0, R(240, 140, 1440, 810)), (6, "m", "t1", 35.8, (960, 540)), (7, "m", "t2", 8.2, (960, 540))]),
 "24": ("TRAILER 1 · 1:04", [
   (0, "m", "t1", 63.62, (1000, 500)), (1, "m", "t1", 66.7, (1000, 500)), (2, "z", "t1", 64.1, box169(1000, 480, 1150)), (2.55, "m", "t1", 63.62, (1000, 520)),
   (3, "c", "t1", 64.1, R(400, 850, 1385, 170)), (4, "z", "t1", 64.1, box169(960, 930, 1000), {"capY": 190}), (5, "z", "t1", 64.1, box169(1320, 200, 760)),
   (6, "c", "t1", 64.1, R(1250, 60, 140, 130)), (7, "m", "t1", 65.66, (1300, 500))]),
 "23": ("TRAILER 2 · 0:37  /  TRAILER 1 · 0:51", [
   (0, "m", "t2", 34.7, (1040, 500)), (2, "z", "t2", 37.4, box169(1040, 580, 900, "t2")), (2.6, "m", "t2", 36.4, (1040, 560)), (3, "c", "t2", 37.4, R(770, 500, 190, 165)),
   (4, "c", "t2", 37.4, R(950, 500, 185, 165)), (5, "c", "t2", 37.4, R(1125, 500, 195, 165)), (5.6, "z", "t2", 37.4, box169(1220, 580, 500, "t2")),
   (6, "m", "t1", 51.2, (1100, 450)), (7, "c", "t1", 51.7, R(1030, 300, 260, 130))]),
 "22": ("TRAILER 2 · 1:16", [
   (0, "m", "t2", 74.9, (1000, 420)), (1, "m", "t2", 75.95, (1250, 400)), (2, "z", "t2", 76.3, box169(1250, 400, 1150, "t2")),
   (3, "c", "t2", 76.3, R(905, 245, 160, 80)), (4, "c", "t2", 76.3, R(1390, 400, 280, 80)),
   (5, "z", "t2", 76.3, box169(1530, 420, 520, "t2")), (6, "c", "t2", 76.3, R(1430, 320, 190, 80))]),
 "21": ("TRAILER 2 · 1:15", [
   (0, "m", "t2", 74.9, (1000, 420)), (1, "z", "t2", 76.3, box169(600, 450, 1200, "t2")), (2, "p", "t2", 76.3, box169(330, 380, 760, "t2")),
   (3, "z", "t2", 75.3, box169(1000, 330, 800, "t2")), (4, "z", "t2", 75.3, box169(1000, 300, 560, "t2")), (5, "m", "t2", 74.9, (1000, 420)), (6, "z", "t2", 76.3, box169(600, 450, 1200, "t2"))]),
 "20": ("TRAILER 1 · 1:09", [
   (0, "m", "t1", 68.7, (960, 420)), (1, "z", "t1", 70.0, box169(960, 330, 1400)), (1.55, "p", "t1", 70.0, box169(960, 250, 900)), (2, "c", "t1", 70.0, R(850, 0, 470, 215)),
   (3, "c", "t1", 70.0, R(25, 75, 520, 330)), (4, "z", "t1", 70.0, box169(290, 240, 620))]),
 "19": ("TRAILER 2 · 0:53", [
   (0, "m", "t2", 50.0, (960, 450)), (1, "m", "t2", 52.0, (1300, 540)), (2, "c", "t2", 53.0, R(1575, 565, 345, 405)),
   (3, "z", "t2", 53.0, box169(1745, 760, 520, "t2")), (4, "p", "t2", 53.0, box169(1745, 880, 520, "t2")),
   (5, "p", "t2", 53.0, box169(1745, 930, 440, "t2")), (6, "c", "t2", 53.0, R(335, 105, 90, 220)), (6.6, "m", "t2", 55.0, (1400, 560))]),
 "18": ("TRAILER 2 · 1:02", [
   (0, "m", "t2", 60.7, (1000, 540)), (2, "c", "t2", 62.0, R(990, 640, 700, 250)), (3, "z", "t2", 62.3, box169(1350, 760, 620, "t2")),
   (5, "m", "t2", 61.0, (1000, 540)), (6, "m", "t2", 63.2, (700, 540))]),
 "17": ("TRAILER 1 · 0:08  /  TRAILER 2 · 1:03", [
   (0, "m", "t1", 6.6, (1100, 500)), (1, "z", "t1", 8.7, box169(700, 450, 1300)), (3, "z", "t1", 8.7, box169(1500, 600, 900)),
   (4, "m", "t2", 63.2, (700, 540)), (5, "m", "t2", 64.3, (700, 540)), (6, "m", "t2", 66.3, (1200, 540))]),
 "16": ("TRAILER 2 · 2:30", [
   (0, "z", "t2", 150.05, box169(960, 540, 1500, "t2")), (1, "m", "t2", 148.3, (1100, 500)), (2, "m", "t2", 149.3, (1300, 420)), (2.6, "z", "t2", 150.05, box169(1500, 330, 900, "t2")),
   (3, "c", "t2", 150.05, R(1420, 170, 380, 190)), (4, "z", "t2", 150.05, box169(1610, 300, 500, "t2")),
   (5, "m", "t2", 150.9, (1000, 540))]),
 "15": ("TRAILER 1 · 0:51", [
   (0, "m", "t1", 51.17, (700, 450)), (1, "z", "t1", 51.7, box169(640, 380, 950)), (2, "c", "t1", 51.7, R(420, 225, 140, 115)), (3, "z", "t1", 51.7, box169(490, 290, 420)),
   (4, "z", "t1", 51.7, box169(960, 560, 1250))]),
 "14": ("TRAILER 1 · 0:51", [
   (0, "z", "t1", 51.7, box169(960, 560, 1500)), (1, "m", "t1", [51.17, 49.95], (960, 600)), (2, "c", "t1", 51.7, R(455, 925, 600, 55)),
   (3, "c", "t1", 51.7, R(455, 930, 990, 100)), (3.55, "m", "t1", 51.17, (960, 600))]),
 "13": ("TRAILER 1 · 0:41", [
   (0, "m", "t1", 41.37, (960, 560)), (1, "m", "t1", [46.6, 55.05], (960, 540)), (2, "c", "t1", 41.9, R(460, 930, 420, 55)),
   (3, "c", "t1", 41.9, R(455, 925, 850, 110)), (3.5, "m", "t1", 41.37, (960, 560))]),
 "12": ("TRAILER 1 · 0:44", [
   (0, "m", "t1", [43.95, 49.95, 55.05], (960, 560)), (2, "c", "t1", 44.6, R(455, 880, 850, 150)), (3, "z", "t1", 44.6, box169(900, 960, 820)),
   (4, "m", "t1", [42.45, 41.37, 46.6, 49.95], (960, 540))]),
 "11": ("TRAILER 1 · 1:07", [
   (0, "m", "t1", 67.7, (960, 500)), (1, "z", "t1", 68.1, box169(960, 480, 1300)), (2, "c", "t1", 68.1, R(90, 945, 520, 90)), (2.55, "c", "t1", 68.1, R(1430, 750, 400, 290)),
   (3, "m", "t1", [41.37, 43.95, 46.6, 49.95, 55.05, 57.4], (960, 540))]),
 "10": ("EXTENDED LOOK · 18:24", [
   (0, "m", "el", 1104.1, (960, 600)), (2, "c", "el", 1106.0, R(1455, 85, 125, 45)), (3, "z", "el", 1106.0, R(1120, 60, 800, 450)),
   (4, "p", "el", 1106.0, R(1120, 470, 800, 450)), (6, "m", "el", 1105.4, (920, 700)), (6.6, "z", "el", 1107.8, box169(760, 560, 1300))]),
 "09": ("TRAILER 2 · 2:10", [
   (0, "m", "t2", 129.4, (1080, 420)), (1, "c", "t2", 130.5, R(760, 230, 650, 370)), (2, "c", "t2", 130.5, R(1030, 425, 120, 60)),
   (3, "m", "t2", 130.9, (1080, 420)), (4, "z", "t2", 131.8, box169(1085, 400, 760, "t2")), (5, "m", "t2", [133.0, 129.4], (1080, 420))]),
 "08": ("EXTENDED LOOK · 6:23", [
   (0, "m", "el", 382.7, (1060, 500)), (2, "z", "el", 383.5, box169(1040, 560, 1000)), (3, "p", "el", 383.5, box169(1075, 710, 420)),
   (4, "p", "el", 383.5, box169(1230, 560, 420)), (5, "p", "el", 383.5, box169(915, 785, 420)),
   (6, "p", "el", 383.5, box169(850, 515, 400)), (7, "p", "el", 383.5, box169(1040, 560, 1100))]),
 "07": ("EXTENDED LOOK · 6:26", [
   (0, "m", "el", 384.6, (960, 600)), (2, "c", "el", 386.8, R(900, 760, 150, 125)), (3, "z", "el", 386.8, box169(1000, 720, 760)),
   (4, "m", "el", 387.0, (960, 540))]),
 "06": ("EXTENDED LOOK · 6:06", [
   (0, "m", "el", 365.1, (1300, 400)), (1, "z", "el", 366.0, box169(1400, 250, 1150)), (2, "c", "el", 366.0, R(1290, 25, 180, 95)),
   (3, "c", "el", 366.0, R(1330, 80, 560, 300)), (4, "z", "el", 366.0, box169(1640, 250, 600)), (5, "c", "el", 366.0, R(625, 738, 260, 90)), (5.5, "m", "el", 366.2, (700, 700))]),
 "05": ("EXTENDED LOOK · 10:40", [
   (0, "m", "el", 639.4, (1200, 420)), (1, "z", "el", 640.5, box169(1200, 430, 900)), (1.6, "m", "el", 642.3, (960, 540)), (2, "m", "el", 646.0, (960, 540)),
   (3, "z", "el", 640.5, box169(1200, 430, 620)), (5, "m", "el", 651.0, (960, 540))]),
 "04": ("EXTENDED LOOK · 13:12", [
   (0, "m", "el", 790.0, (500, 560)), (1, "z", "el", 792.0, R(0, 380, 700, 394)), (1.6, "m", "el", 792.0, (400, 560)), (2, "m", "el", 810.7, (1000, 540)),
   (2.45, "m", "el", 828.3, (760, 540)), (2.75, "m", "el", 838.2, (900, 540)), (3, "m", "el", 908.6, (1000, 540))]),
 "03": ("TRAILER 1 · 1:09  /  EXTENDED LOOK · 11:28", [
   (0, "m", "t1", 68.7, (960, 420)), (1, "z", "t1", 69.9, box169(900, 420, 1200)), (2, "m", "el", 686.2, (1060, 540)),
   (3, "m", "el", [729.2, 730.6], (860, 450)), (3.6, "m", "t1", 68.7, (800, 450)), (4, "m", "el", 706.0, (960, 540))]),
 "02": ("TRAILER 1 · 0:57", [
   (0, "m", "t1", 55.05, (960, 500)), (1, "m", "t1", 57.4, (960, 500)), (2, "z", "t1", 58.5, box169(940, 540, 1100)), (2.5, "m", "t1", 57.4, (960, 500)), (3, "z", "t1", 58.5, box169(940, 650, 800)),
   (4, "c", "t1", 58.5, R(695, 885, 530, 145))]),
 "01": ("EXTENDED LOOK · 9:14", [
   (0, "m", "el", 551.5, (1150, 620)), (1, "m", "el", 554.4, (1150, 620)), (2, "c", "el", 554.6, R(1690, 940, 220, 120)), (3, "z", "el", 554.6, box169(1760, 990, 480)),
   (4, "m", "el", 556.8, (1160, 600)), (5, "z", "el", 559.5, box169(1160, 470, 520)), (6, "z", "t1", 58.5, box169(940, 450, 800)),
   (7, "z", "el", 559.5, box169(1160, 700, 820)), (8, "m", "t1", 57.4, (960, 500)), (9, "m", "el", 557.6, (1160, 600))]),
 "99": ("", [
   (0, "m", "t1", 35.8, (960, 540)), (1, "m", "t1", 18.5, (960, 540)), (2, "m", "el", 1218.0, (900, 540)),
   (3, "z", "el", 1594.0, R(440, 250, 1040, 585)), (4, "m", "t2", 8.2, (960, 540)), (5, "m", "el", 557.0, (1160, 600))]),
}
HIGHLIGHT = {w.lower() for w in """Weazel Sinfrontera Hammer Lady eCola Phil's Effluvia Blanco's Leonida Hamlet
    Camilo trunk Dad Bod Squad Custard Cannon Rollerz vice fourteen ninety-nine U-turn wanted strong smiling hydrate
    bilingual freedom reign jumpsuit orange same glasses nightgown hammers excepciones snacking""".split()}

def run(*a): return subprocess.run(a, capture_output=True, text=True).stdout
def dur(p): return float(re.search(r"estimated duration: ([\d.]+)", run("afinfo", p)).group(1))
def pauses(p, gap): return [tuple(map(float, s.split("-"))) for s in run(f"{TOOLS}/pauses", p, str(gap)).split()]
def syl(word):
    w = re.sub(r"[^a-z0-9]", "", word.lower())
    if not w: return 0.5
    if w.isdigit(): return len(w)
    c = len(re.findall(r"[aeiouy]+", w))
    if w.endswith("e") and c > 1 and not w.endswith("le"): c -= 1
    return max(1, c)
PUNCT = re.compile(r"[.,?!…:;]$")
ABBR = re.compile(r"^[A-Z]\.$")                   # "W." is not a sentence end
def is_end(w): return bool(re.search(r"[.?!…]$", w)) and not ABBR.match(w)

def align_words(words, segs):
    """Map words onto speech segments. Returns [(start, end)] per word (seconds into the chunk)."""
    sy = [syl(w) for w in words]
    n, m = len(words), len(segs)
    rate = sum(b - a for a, b in segs) / sum(sy)
    INF = 1e18
    base = 0.0
    dp = [[INF] * (n + 1) for _ in range(m + 1)]; bk = [[None] * (n + 1) for _ in range(m + 1)]
    dp[0][0] = 0
    for j in range(1, m + 1):
        for i in range(1, n + 1):
            for j0 in range(max(0, j - 10), j):
                for i0 in range(max(0, i - 16), i):
                    if dp[j0][i0] >= INF / 2: continue
                    d = segs[j - 1][1] - segs[j0][0]; e = rate * sum(sy[i0:i])
                    c = ((d - e) / (0.35 + e)) ** 2 * 4
                    c += 0.9 * sum(1 for k in range(i0, i - 1) if is_end(words[k]))    # a sentence end is always audible
                    if i < n and j == m: continue
                    if i < n:
                        gap = segs[j][0] - segs[j - 1][1]
                        c += -min(gap, 0.5) if PUNCT.search(words[i - 1]) else 0.4 + 2 * gap
                    c += 0.08 * (j - j0 - 1)
                    if dp[j0][i0] + c < dp[j][i]: dp[j][i] = dp[j0][i0] + c; bk[j][i] = (j0, i0)
    times = [None] * n; j, i = m, n
    while j > 0:
        j0, i0 = bk[j][i]; a, b = segs[j0][0], segs[j - 1][1]; tot = sum(sy[i0:i]); acc = a
        for k in range(i0, i):
            wlen = (b - a) * sy[k] / tot; times[k] = (acc, acc + wlen); acc += wlen
        j, i = j0, i0
    return times

def sentence_spans(words):
    spans, cur = [], 0
    for i, w in enumerate(words):
        if is_end(w) or i == len(words) - 1: spans.append((cur, i)); cur = i + 1
    return spans

def mark(w):
    return f"*{w}*" if re.sub(r"[^\w'-]", "", w).lower() in HIGHLIGHT else w

def scene_of(src, t):
    c = CUTS[src]; k = bisect.bisect_right(c, t)
    return (c[k - 1] if k > 0 else 0.0), (c[k] if k < len(c) else SRCLEN[src])

segs = json.load(open(f"{OUT}/segments.json"))
shots, caps, cards, vos, badges, chapters, warns = [], [], [], [], [], [], []
t = 0.0
for sg in segs:
    sid = sg["id"]; path = f"{OUT}/voiceovers/seg{sid}.mp3"; d = dur(path)
    lead, tail = (0.15, 0.4) if sid == "00" else ((LEAD, 2.8) if sid == "99" else (LEAD, TAIL))
    vo_at = t + lead; L = lead + d + tail
    vos.append({"file": path, "at": round(vo_at, 3)})
    words = sg["text"].split()
    wt = [(vo_at + a, vo_at + b) for a, b in align_words(words, pauses(path, 0.06))]
    sents = sentence_spans(words)
    s_start = [wt[a][0] for a, b in sents]; s_end = [wt[b][1] for a, b in sents]
    if sid not in ("00", "99"):
        cards.append({"t": [round(t, 3), round(t + L, 3)], "num": f"#{int(sid):02d}", "title": sg["title"], "tag": PLAN[sid][0]})
    chapters.append((t, "Intro" if sid == "00" else ("Outro" if sid == "99" else f"#{int(sid)} {sg['title']}")))
    # --- captions: phrase by phrase at measured times
    chunk, out_chunks = [], []
    for i, w in enumerate(words):
        chunk.append(i)
        txt = " ".join(words[k] for k in chunk)
        last = i == len(words) - 1
        brk = last or is_end(w) or (PUNCT.search(w) and len(txt) > 14) or len(txt + " " + words[i + 1]) > 34
        if brk: out_chunks.append(chunk); chunk = []
    for ci, ch in enumerate(out_chunks):
        a = wt[ch[0]][0] - 0.05
        b = wt[ch[-1]][1] + 0.3
        if ci + 1 < len(out_chunks):
            nxt = wt[out_chunks[ci + 1][0]][0] - 0.05
            b = min(b, nxt) if nxt - wt[ch[-1]][1] < 0.6 else b
        caps.append({"t": [round(a, 3), round(b, 3)], "chunks": [" ".join(mark(words[k]) for k in ch)]})
    for i, w in enumerate(words):
        if w == "GTA" and i + 1 < len(words) and words[i + 1].startswith("6"): badges.append(round(wt[i][0], 3))
    # --- shots
    beats = PLAN[sid][1]
    starts = []
    for bi, b in enumerate(beats):
        if bi == 0: starts.append(t); continue
        a = b[0]; si = int(a); fr = a - si
        starts.append(s_start[si] + fr * (s_end[si] - s_start[si]) - 0.12)
    starts.append(t + L)
    for bi in range(1, len(beats)):
        if starts[bi] - starts[bi - 1] < 0.8 or starts[bi + 1] - starts[bi] < 0.8:
            warns.append(f"{sid} beat {bi} short {starts[bi]-starts[bi-1]:.2f}/{starts[bi+1]-starts[bi]:.2f}")
    prev_rect = None
    for bi, beat in enumerate(beats):
        anc, kind, src, st, prm = beat[:5]; opts = beat[5] if len(beat) > 5 else {}
        o0, o1 = starts[bi], starts[bi + 1]; od = o1 - o0; full = FULL[src]
        n_before = len(shots)
        if kind == "m" and isinstance(st, list) and len(st) > 1:
            # chain of live clips, each played at real speed to the end of its scene
            cur = o0
            to = box169(prm[0], prm[1], full["w"] * 0.9, src)
            for ci, ct in enumerate(st):
                s0, s1 = scene_of(src, ct); ct = max(ct, s0 + 0.2); lim = s1 - 0.22
                avail, rem = lim - ct, o1 - cur
                if rem <= 0.3: break
                lastclip = ci == len(st) - 1
                if avail >= rem:
                    added = [(ct, ct + rem, cur, o1)]
                elif lastclip and avail >= 0.8 * rem:
                    added = [(ct, lim, cur, o1)]
                elif not lastclip:
                    added = [(ct, lim, cur, cur + avail)]
                else:
                    play = avail / 0.85
                    warns.append(f"{sid} beat {bi} chain ends with {rem - play:.2f}s hold")
                    added = [(ct, lim, cur, cur + play), (lim - 0.1, lim - 0.04, cur + play, o1)]
                for k, (a0, a1, b0, b1) in enumerate(added):
                    sh = {"s": src, "src": [round(a0, 3), round(a1, 3)], "out": [round(b0, 3), round(b1, 3)], "from": full, "to": to}
                    if k == 1: sh["join"] = True; sh["from"] = to
                    if src == "t1" and (40.5 <= ct <= 60 or 63.5 <= ct <= 67.7): sh["capY"] = 800
                    shots.append(sh)
                cur = added[-1][3]
                if cur >= o1 - 0.05: break
            shots[-1]["out"][1] = round(o1, 3); prev_rect = None
            if opts.get("cut") and len(shots) > n_before: shots[n_before]["join"] = True
            continue
        if isinstance(st, list): st = st[0]
        st0 = st[0] if isinstance(st, list) else st
        low_social = src == "t1" and (40.5 <= st0 <= 60 or 63.5 <= st0 <= 67.7)
        if kind == "m":
            s0, s1 = scene_of(src, st)
            st = max(st, s0 + 0.2); limit = s1 - 0.22
            to = box169(prm[0], prm[1], full["w"] * 0.86, src)
            avail = limit - st
            added = []
            if avail >= od:
                added.append({"s": src, "src": [round(st, 3), round(st + od, 3)], "out": [round(o0, 3), round(o1, 3)], "from": full, "to": to})
            elif avail >= 0.8 * od:
                added.append({"s": src, "src": [round(st, 3), round(limit, 3)], "out": [round(o0, 3), round(o1, 3)], "from": full, "to": to})
            else:
                play = avail / 0.85; hold = od - play
                if hold > 1.3: warns.append(f"{sid} beat {bi} holds {hold:.2f}s ({src} {st} scene {s0}-{s1})")
                mid = {k: round(full[k] + (to[k] - full[k]) * play / od) for k in full}
                added.append({"s": src, "src": [round(st, 3), round(limit, 3)], "out": [round(o0, 3), round(o0 + play, 3)], "from": full, "to": mid})
                added.append({"s": src, "src": [round(limit - 0.1, 3), round(limit - 0.04, 3)], "out": [round(o0 + play, 3), round(o1, 3)],
                              "from": mid, "to": to, "join": True})
            for sh in added:
                if low_social: sh["capY"] = 800
            shots += added; prev_rect = None
        elif kind == "c":
            sh = {"s": src, "src": [st, round(st + 0.1, 3)], "out": [round(o0, 3), round(o1, 3)], "mode": "callout", "region": prm}
            cy = prm["y"] + prm["h"] / 2
            s_ = min(3.2, min(1000 / prm["w"], 520 / prm["h"]))
            if cy > 700: sh["capY"] = 620 if prm["w"] * s_ > 880 else 770
            shots.append(sh); prev_rect = None
        else:
            join = kind == "p" and prev_rect is not None
            sh = {"s": src, "src": [st, round(st + 0.1, 3)], "out": [round(o0, 3), round(o1, 3)], "from": prev_rect if join else full, "to": prm}
            if join: sh["join"] = True
            if low_social or prm["y"] + prm["h"] > 1000: sh["capY"] = 800
            shots.append(sh); prev_rect = prm
        if opts.get("cut") and len(shots) > n_before: shots[n_before]["join"] = True
        if "capY" in opts:
            for sh in shots[n_before:]: sh["capY"] = opts["capY"]
    t += L

edit = {"out": f"{OUT}/GTA 6 Frame by Frame - 25 Details Rockstar Is Hiding.mp4", "sources": SRC, "vo": vos,
        "shots": shots, "captions": caps, "cards": cards, "badges": badges, "timedCaptions": True,
        "xfade": 0.3, "musicVol": 0.09, "duckHigh": 0.2}
json.dump(edit, open(f"{OUT}/edit-list.json", "w"), indent=1)
with open(f"{OUT}/chapters.txt", "w") as f:
    for c0, name in chapters: f.write(f"{int(c0 // 60)}:{int(c0 % 60):02d} {name}\n")
print(f"total {t:.1f}s = {int(t // 60)}:{t % 60:04.1f}  shots {len(shots)}  captions {len(caps)}  badges {badges}")
for w in warns: print("WARN", w)
