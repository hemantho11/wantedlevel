from PIL import Image, ImageDraw, ImageFont, ImageEnhance
import os, math
SP = "/private/tmp/claude-501/-Users-hemanthkumaro11-Library-Application-Support-Claude-scratch-workspaces-56f512cf-0173-4070-b6b2-6da2d2fb1acb-d95140d4-76ac-4f98-9416-14bc979cac1a-scratch-2026-09-27-fe9617/0b3daee0-c9c3-4827-a40f-e255ee4849da/scratchpad/th2"
OUT = os.path.expanduser("~/Downloads/GTA6 Long-form - Realism/thumbnails")
FONT = "/System/Library/Fonts/Supplemental/Arial Black.ttf"
LOGO = Image.open("/Users/hemanthkumaro11/Youtube/shorts-pipeline/assets/gta6_logo.png").convert("RGBA")
W, H = 1280, 720
YEL, WHITE, RED, GREEN = (255, 222, 30), (255, 255, 255), (235, 30, 45), (115, 237, 31)
def frame(n, box=None):
    im = Image.open(f"{SP}/f_{n}.jpg").convert("RGB")
    if box: im = im.crop(box)
    return ImageEnhance.Contrast(im).enhance(1.08)
def fit(im, w, h):
    r = max(w / im.width, h / im.height); im = im.resize((int(im.width * r + 1), int(im.height * r + 1)), Image.LANCZOS)
    x, y = (im.width - w) // 2, (im.height - h) // 2; return im.crop((x, y, x + w, y + h))
def text(d, xy, s, size, fill, anchor="la", stroke=10):
    f = ImageFont.truetype(FONT, size)
    d.text((xy[0] + 6, xy[1] + 8), s, font=f, fill=(0, 0, 0), anchor=anchor, stroke_width=stroke, stroke_fill=(0, 0, 0))
    d.text(xy, s, font=f, fill=fill, anchor=anchor, stroke_width=stroke, stroke_fill=(0, 0, 0))
def shade(im, bottom=0, left=0):
    g = Image.new("L", (W, H), 0); gd = ImageDraw.Draw(g)
    for y in range(H):
        if bottom: gd.line([(0, y), (W, y)], fill=int(bottom * max(0, (y - H * 0.45) / (H * 0.55))))
    if left:
        for x in range(W // 2): gd.line([(x, 0), (x, H)], fill=max(0, int(left * (1 - x / (W / 2)))))
    return Image.composite(Image.new("RGB", (W, H)), im, g)
def logo(im, w=210, pos=(1045, 20)):
    l = LOGO.resize((w, int(LOGO.height * w / LOGO.width)), Image.LANCZOS); im.paste(l, pos, l)
def arrow(d, a, b, width=16, col=RED):
    d.line([a, b], fill=(0, 0, 0), width=width + 10); d.line([a, b], fill=col, width=width)
    ang = math.atan2(b[1] - a[1], b[0] - a[0]); L = 52
    d.polygon([b, (b[0] - L * math.cos(ang - 0.5), b[1] - L * math.sin(ang - 0.5)), (b[0] - L * math.cos(ang + 0.5), b[1] - L * math.sin(ang + 0.5))], fill=col, outline=(0, 0, 0))
def circle(d, box):
    d.ellipse(box, outline=(0, 0, 0), width=22); d.ellipse(box, outline=RED, width=12)

# A — Lucia's drink close-up: "THEY WENT TOO FAR"
def A():
    im = fit(frame("1230.2", (0, 60, 1500, 904)), W, H).transpose(Image.FLIP_LEFT_RIGHT); im = shade(im, left=230)
    d = ImageDraw.Draw(im); circle(d, (620, 300, 980, 620))
    text(d, (40, 200), "ROCKSTAR", 96, WHITE); text(d, (40, 320), "WENT TOO", 96, YEL); text(d, (40, 440), "FAR", 150, RED)
    logo(im); im.save(f"{OUT}/Thumbnail A - They went too far.jpg", quality=92)
# B — propeller water spray: "LOOK CLOSER"
def B():
    im = fit(frame("1567.9", (100, 100, 1500, 1000)), W, H); im = shade(im, bottom=230)
    d = ImageDraw.Draw(im); arrow(d, (1080, 180), (820, 330))
    text(d, (W // 2, 560), "WAIT... LOOK", 92, WHITE, "mm"); text(d, (W // 2, 660), "AT THE WATER", 100, YEL, "mm")
    logo(im, 200, (40, 20)); im.save(f"{OUT}/Thumbnail B - Look at the water.jpg", quality=92)
# C — split: drink | flipped truck: "GTA 6 REALISM IS INSANE"
def C():
    im = Image.new("RGB", (W, H)); im.paste(fit(frame("1230.2", (80, 100, 1080, 1080)), 660, H), (0, 0)); im.paste(fit(frame("849.9", (300, 0, 1500, 1080)), 660, H), (620, 0))
    d = ImageDraw.Draw(im); d.polygon([(640, 0), (672, 0), (632, H), (600, H)], fill=YEL)
    im = shade(im, bottom=235); d = ImageDraw.Draw(im)
    text(d, (W // 2, 560), "GTA 6 REALISM", 90, WHITE, "mm"); text(d, (W // 2, 662), "IS INSANE", 110, YEL, "mm")
    im.save(f"{OUT}/Thumbnail C - Realism is insane.jpg", quality=92)
# D — jewelry store customer grabs Lucia's gun: "NPCs FIGHT BACK"
def D():
    im = fit(frame("1080.6", (0, 0, 1700, 1080)), W, H); im = shade(im, bottom=235)
    d = ImageDraw.Draw(im); circle(d, (290, 60, 900, 520))
    text(d, (W // 2, 570), "NPCs NOW", 92, WHITE, "mm"); text(d, (W // 2, 668), "FIGHT BACK?!", 104, YEL, "mm")
    logo(im, 200, (1060, 20)); im.save(f"{OUT}/Thumbnail D - NPCs fight back.jpg", quality=92)
for fn in (A, B, C, D): fn()
