from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import os
SP = "/private/tmp/claude-501/-Users-hemanthkumaro11-Library-Application-Support-Claude-scratch-workspaces-56f512cf-0173-4070-b6b2-6da2d2fb1acb-d95140d4-76ac-4f98-9416-14bc979cac1a-scratch-2026-09-27-fe9617/0b3daee0-c9c3-4827-a40f-e255ee4849da/scratchpad/th"
OUT = os.path.expanduser("~/Downloads/GTA6 Long-form - Story Explained/thumbnails")
FONT = "/System/Library/Fonts/Supplemental/Arial Black.ttf"
LOGO = Image.open("/Users/hemanthkumaro11/Youtube/shorts-pipeline/assets/gta6_logo.png").convert("RGBA")
W, H = 1280, 720
YEL, WHITE, RED, GREEN = (255, 222, 30), (255, 255, 255), (235, 30, 45), (115, 237, 31)

def frame(name, box=None, t2=False):
    im = Image.open(f"{SP}/{name}").convert("RGB")
    if t2: im = im.crop((0, 108, 1920, 972)).resize((1920, 1080))     # remove letterbox
    if box: im = im.crop(box)
    return ImageEnhance.Contrast(im).enhance(1.08)
def fit(im, w, h):
    r = max(w / im.width, h / im.height); im = im.resize((int(im.width * r + 1), int(im.height * r + 1)), Image.LANCZOS)
    x, y = (im.width - w) // 2, (im.height - h) // 2
    return im.crop((x, y, x + w, y + h))
def text(d, xy, s, size, fill, anchor="la", stroke=10):
    f = ImageFont.truetype(FONT, size)
    d.text((xy[0] + 6, xy[1] + 8), s, font=f, fill=(0, 0, 0), anchor=anchor, stroke_width=stroke, stroke_fill=(0, 0, 0))
    d.text(xy, s, font=f, fill=fill, anchor=anchor, stroke_width=stroke, stroke_fill=(0, 0, 0))
def shade(im, top=0, bottom=0, left=0):
    g = Image.new("L", (W, H), 0); gd = ImageDraw.Draw(g)
    for y in range(H):
        a = 0
        if bottom: a = max(a, int(bottom * max(0, (y - H * 0.45) / (H * 0.55))))
        if top: a = max(a, int(top * max(0, 1 - y / (H * 0.45))))
        gd.line([(0, y), (W, y)], fill=a)
    if left:
        for x in range(W // 2): gd.line([(x, 0), (x, H)], fill=max(0, int(left * (1 - x / (W / 2)))))
    return Image.composite(Image.new("RGB", (W, H)), im, g)
def logo(im, w=230, pos=(1030, 18)):
    l = LOGO.resize((w, int(LOGO.height * w / LOGO.width)), Image.LANCZOS); im.paste(l, pos, l)
def arrow(d, a, b, width=16, col=RED):
    import math
    d.line([a, b], fill=(0, 0, 0), width=width + 10); d.line([a, b], fill=col, width=width)
    ang = math.atan2(b[1] - a[1], b[0] - a[0]); L = 52
    pts = [b, (b[0] - L * math.cos(ang - 0.5), b[1] - L * math.sin(ang - 0.5)), (b[0] - L * math.cos(ang + 0.5), b[1] - L * math.sin(ang + 0.5))]
    d.polygon(pts, fill=col, outline=(0, 0, 0))

# A — prison jumpsuit vs skull mask: "HOW?"
def A():
    im = Image.new("RGB", (W, H))
    l = fit(frame("f_10.2.jpg", (180, 0, 1380, 1080)), 660, H)
    r = fit(frame("f_75.3.jpg", (250, 0, 1450, 1080), t2=True), 660, H)
    im.paste(l, (0, 0)); im.paste(r, (620, 0))
    d = ImageDraw.Draw(im)
    d.polygon([(640, 0), (672, 0), (632, H), (600, H)], fill=YEL)
    im = shade(im, bottom=235)
    d = ImageDraw.Draw(im)
    text(d, (W // 2, 560), "HOW DID SHE", 88, WHITE, "mm")
    text(d, (W // 2, 660), "GET HERE?", 104, YEL, "mm")
    text(d, (40, 30), "PRISON", 58, WHITE)
    text(d, (1240, 30), "???", 70, RED, "ra")
    arrow(d, (420, 330), (860, 330))
    im.save(f"{OUT}/Thumbnail A - How did she get here.jpg", quality=92)

# B — Lucia's text: "WHAT HAPPENED ON FLOOR 26?"
def B():
    im = fit(frame("f_1435.jpg", (0, 380, 1244, 1080)), W, H)
    im = shade(im, top=140, bottom=200)
    d = ImageDraw.Draw(im)
    # red circle around the message
    d.ellipse((10, 170, 700, 520), outline=(0, 0, 0), width=22); d.ellipse((10, 170, 700, 520), outline=RED, width=12)
    text(d, (W - 40, 540), "WHAT HAPPENED", 76, WHITE, "ra")
    text(d, (W - 40, 612), "ON FLOOR 26?", 100, YEL, "ra")
    logo(im, 210, (1045, 20))
    im.save(f"{OUT}/Thumbnail B - What happened on floor 26.jpg", quality=92)

# C — the store robbery: "THE STORY ROCKSTAR HID"
def C():
    im = fit(frame("f_78.0.jpg", (650, 60, 1900, 1080)), W, H)
    im = shade(im, left=230, bottom=120)
    d = ImageDraw.Draw(im)
    text(d, (50, 150), "THE STORY", 104, WHITE)
    text(d, (50, 280), "ROCKSTAR", 104, YEL)
    text(d, (50, 410), "HID", 150, RED)
    text(d, (50, 610), "IN 3 TRAILERS", 52, WHITE, stroke=8)
    logo(im, 220, (1040, 20))
    im.save(f"{OUT}/Thumbnail C - The story Rockstar hid.jpg", quality=92)

# D — timeline strip prison -> store -> bank -> ?: "THE FULL STORY"
def D():
    im = Image.new("RGB", (W, H), (12, 12, 14))
    srcs = [("f_10.2.jpg", (250, 0, 1450, 1080), False), ("f_78.0.jpg", (700, 0, 1900, 1080), False),
            ("f_75.3.jpg", (250, 0, 1450, 1080), True), ("f_1474.jpg", (500, 0, 1700, 1080), False)]
    pw = W // 4
    for i, (f, b, t2) in enumerate(srcs):
        p = fit(frame(f, b, t2), pw - 8, 470)
        im.paste(p, (i * pw + 4, 250))
    d = ImageDraw.Draw(im)
    d.line([(pw // 2 + 40, 250), (3 * pw + pw // 2 - 40, 250)], fill=YEL, width=6)
    for i, lab in enumerate(["1", "2", "3", "?"]):
        cx = i * pw + pw // 2
        d.ellipse((cx - 38, 212, cx + 38, 288), fill=YEL if lab != "?" else RED, outline=(0, 0, 0), width=6)
        f = ImageFont.truetype(FONT, 50); d.text((cx, 250), lab, font=f, fill=(0, 0, 0) if lab != "?" else WHITE, anchor="mm")
    
    text(d, (W // 2 - 360, 88), "GTA 6", 100, YEL, "mm")
    text(d, (W // 2 + 200, 88), "FULL STORY", 100, WHITE, "mm")
    text(d, (W // 2, 180), "EXPLAINED", 52, GREEN, "mm", stroke=8)
    im.save(f"{OUT}/Thumbnail D - Full story timeline.jpg", quality=92)

for fn in (A, B, C, D): fn()
print("ok")
