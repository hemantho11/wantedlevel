# Long-form video pipeline — full spec (used by `/longform`)

Channel: **Wanted Level** (faceless GTA 6 analysis). Output: one premium 16:9 video (5–10 min) + 4 thumbnails + chapters + upload notes.
Reference result the user loved: `examples/story-explained/` → "GTA 6 Story Explained" (Sept 28 2026). Match that quality and style.

## Sources (already on disk — never download)
| key | file (in `~/Downloads`) | length | cut list |
|---|---|---|---|
| `t1` | `Grand Theft Auto VI Trailer 1 - (1080p).mp4` | 1:30 | `longform/cuts_t1.txt` |
| `t2` | `Grand Theft Auto VI Trailer 2.mp4` (letterboxed 1920×864 inside 1080) | 2:47 | `longform/cuts_t2.txt` |
| `el` | `GTAVI_An_Extended_Look.mp4` (Rockstar's official 4K file, 3840×2160, 14 GB — keep it in `~/Downloads`, NOT in Documents: Documents syncs to iCloud and the file gets evicted) | 26:48 | `longform/cuts_el.txt` |
If a new source is added: run `tools/cuts <video> > longform/cuts_<key>.txt` and add it to `SRC`/`SRCLEN`/`FULL` in `gen_frame_by_frame.py`.

## Style rules (the user's explicit preferences — do not change)
- **No full subtitles.** Only keyword callouts (2–4 words, ALL CAPS, 3–5 per chapter). YouTube auto-captions do the rest.
- **No colour grade.** Original footage colours (`"grade": false`). The user rejected graded output.
- **Voice: Leo** — `voice_id TLC61WvtioR7PrhxZ1RH`, `model_id eleven_v3`, `generations_count 1`. Titan was judged boring; do not use it for long-form.
- Script uses ElevenLabs v3 audio tags for delivery: `[curious] [excited] [whispers] [mischievously] [sighs] [sarcastic]` — one every 1–3 sentences; tags are stripped automatically for timing.
- Premium edit (built into `editor_long` v3): cold open at the climax with letterbox bars + riser; chapter title cards (flash, whoosh, bass impact, blurred/dimmed background, bars, growing green rule); 0.35 s dissolves; keyword ticks; music ducks under speech and swells in gaps; channel logo top-left.
- **v4 editing rules (user, Sept 29 — apply to every video):** `STYLE = "v4"` in `plan.py`. (1) Cold open = fast-cut hook: 4–5 one-second clips on the first sentence, then `q` montages and `s` split-screens that tease what the video contains. (2) Smooth transitions: dissolves between beats, hard cuts only inside montages. (3) **Never zoom or slow moving footage.** Live clips play at real speed, full frame; a zoom is always freeze-then-zoom (`z`, `p`, `s`, `c`). (4) No letterbox in the cold open. Mix: `VO_VOL = 0.76; HOOK_VOL = 0.17; RISER_VOL = 0.2` lands at about −16.5 dBFS.
- **Energetic opening (user, Sept 29):** never start the video on a whisper. `c0` opens with `[excited]` and stays high energy until the promise of the video is stated; the biggest reveal (e.g. number one in a ranking) also opens with `[excited]`. Use `[whispers]` only for short asides mid-chapter.
- **Chapter titles (user, Sept 29):** no black or dimmed full-screen title cards. Always set `TEXT_STYLE = "rank"; CARD = 1.9; CH_HOLD = 4.4; CH_FLASH = False` in `plan.py`: footage keeps playing at full brightness and the title is a lower third over it. Use `CH_PREFIX = "#"` only for ranked lists; the small line above the title comes from `"kicker"` in `chapters.json` (default "NEW MECHANIC", so set it per video).
- **Keywords (user, Sept 29):** text only, no background box (the default in the "rank" style; `KW_PLATE = True` brings the yellow plate back). No keyword while the game shows readable text that the narration quotes (text messages, chat). A key may carry a hold time: `["word", "TEXT", 1.5]`.
- **Whispers (user, Sept 29):** after generating, compare each `[whispers]` line with the rest of its take; re-record it without the tag if it is more than ~3 dB quieter, unless the scene needs a whisper.
- **Marks (experiment, Sept 29):** `MARKS = {("c2", 2): (u, v, radius, arrow_angle)}` in `plan.py` puts a red circle (+ arrow) on a `z` / `p` beat with a quiet pop (`POP_VOL = 0.28`). Read u, v off a rendered frame of the zoomed shot, as fractions of the screen, using the grid labels inside that frame. Ask the user how they liked it before using it in every video.
- **Sources (Sept 29):** now in `~/GTA6 Videos _Claude/4k trailers/` (all three in 4K, frame-aligned with the HD copies in `HD trailers/`); music in `BGM/`. The table above still lists the old locations.
- **Sound effects (user, Sept 29):** transition sounds on chapter cards only, and quiet. Always set `SFX_MODE = "chapters"; CH_WHOOSH = 0.22; CH_IMPACT = 0.26` in `plan.py`. No ticks or whooshes on cuts, keywords, freezes or montages — the user found them annoying.
- **QA as a GTA fan:** verify every narrated fact against the footage (e.g. Trailer 1 opens on Lucia in prison, not the beach); check every photo/zoom rect stays inside 1920×1080 (out-of-bounds shows a black bar); avoid repeating a clip within ~30 s; the Extended Look skydive/top-down shots (el 1138–1144) contain Rockstar glitch transitions — see the `CUTS["el"]` additions in the Real Life vs Game `plan.py`.
- Source files are in `~/GTA6 Videos _Claude/` (override `SRC` in `plan.py`); project folders go there too. Real-life photos: ask the user before downloading, use free-licence images only, and show the credit on screen.
- Accuracy: claim only what is visible in the footage or on Rockstar's official site; label theories as theories.

## Phase 1 — topic + script
1. Pick the topic (user's, or the best unused one from the idea list; check `~/Youtube/` + `~/Downloads/GTA6 Long-form - */` so you don't repeat a video).
2. Scout: `tools/fine <video> <out> <start> <end> <step>` sheets (1.5–2 s steps for trailers, 4 s for the Extended Look ranges you need). **Trailer 1's social-media montage cuts every ~1 s — always check `cuts_*.txt` before choosing a timestamp.**
3. Project folder: `~/Downloads/GTA6 Long-form - <Short Title>/` with `voiceovers/`.
4. Write `chapters.json` (format = `examples/story-explained/chapters.json`): `c0` = cold open (hook from the most dramatic moment, then "so how did we get here"), `c1…cN` chapters (`"chapter": "01"`, `"title"`), last = recap + comment question + "subscribe to Wanted Level". 80–100 spoken words per chapter, ≤ 600 characters. `"keys": [[trigger word exactly as written in the text incl. punctuation, "CALLOUT TEXT"], …]` in spoken order.
5. `project.json`: `{"title": "<final video file name>"}`.

## Phase 1b — voiceover
- `estimate_only` once (≈ 1 credit/char, ~500 per chapter). Under 8,000 total → proceed without asking.
- Generate **max 5 at a time** (plan concurrency limit is 5 — more fail with "Too many concurrent requests"), poll `creative_get_flow_run_status`, `curl` each `media[].url` immediately to `voiceovers/<id>.mp3` (links expire in 2 h).
- Verify: `tools/rms` −15…−19 dBFS, `tools/pauses <mp3> 0.25` has gaps. Regenerate a failed take once.

## Phase 2 — shot plan + render
1. Write `plan.py` in the project folder (format = `examples/story-explained/plan.py`): `PLAN = {"c0": [(anchor_word_or_None, kind, src, time_or_[chain], param), …], …}`
   - kinds: `m` live footage with slow push-in toward focus `(x, y)`; `c` freeze + animated callout of region `R(x,y,w,h)`; `z` freeze + zoom into rect `box169(cx, cy, width, src)`; `p` pan from previous `z` rect.
   - First beat of each chapter has anchor `None`; every other beat starts on its anchor word (first occurrence after the previous anchor).
   - Use `[t1, t2, …]` chains when one clip is shorter than its sentence — live footage is never slowed below 0.8× and never crosses a source cut.
   - Change picture every 1.5–4 s. Show exactly what the narration names at that word.
2. `python3 longform/gen_longform.py "<project folder>"` → `edit-list.json` + `chapters.txt`. Fix every `WARN` about holds > 1.5 s (add chain clips) or missing anchors.
3. `longform/editor_long "<project>/edit-list.json" --validate` must print `valid: true`, then render: `longform/editor_long "<project>/edit-list.json"` (~1 min per 5 min of video).

## Phase 3 — QA as a viewer (mandatory, fix and re-render until clean)
- `tools/fine "<video.mp4>" <scratch>/q 0 <duration> 1.5` and read **every** sheet. Check: picture matches the words, no wrong-scene flashes (e.g. Rockstar title cards, unrelated clips), no dark/unreadable text shots, keywords never overlap chapter cards or on-screen text, freezes ≤ ~2 s without motion.
- `tools/rms` about −16…−18 dBFS, peak < −0.3; `tools/pauses <mp4> 1.0` shows no dead air; `swift tools/probe.swift` → 1920×1080.

## Phase 4 — thumbnails
- Copy `longform/thumbs_template.py` into the project as `thumbs.py`, grab candidate frames with `tools/grab`, build **4 variants** (1280×720, Arial Black, white/yellow/red text with thick black stroke, red arrow/circle, GTA VI logo): (A) contrast split + question, (B) mystery detail circled + question, (C) "the X Rockstar hid", (D) numbered timeline/explainer. Curious + clickbait, but never claim something the video doesn't show — phrase uncertain things as questions.
- Tile them into one preview, check for overlaps/cut-off text, fix, and send them with `SendUserFile`.

## Final report (one message)
File, length, size, loudness; chapters (paste-ready); title + 2 alternates; the 4 thumbnails with a recommended pick; ElevenLabs credits used; any judgement calls (claims sourced from Rockstar's site, holds you couldn't remove). Delete `*.f*.jpg` check frames and `*.sb-*` temp files from the project folder.

## Remaking a reference video (user supplies the mp4 in ~/Downloads)
1. `tools/cuts <ref.mp4>` (pace) + `tools/fine <ref.mp4> … 6` sheets (structure, on-screen text) + transcript.
2. `tools/match <ref.mp4> 1.0 <el> <t1> <t2>` → for each reference second, the matching source + time (distance < 0.35 = reliable). Group into runs to map every detail the reference shows onto our footage.
3. Verify each detail yourself on `tools/fine` sheets — only narrate what you can see. Rewrite everything in our own words/structure (chapters by theme, Leo narration); never copy the reference's text.
Example: `examples/realism-remake/` (remake of "Rockstar went this far for realism in GTA 6").
