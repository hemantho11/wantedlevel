#!/usr/bin/env python3
"""Generic long-form edit-list builder (v3 premium style).  usage: gen_longform.py <project folder>
Project folder: chapters.json (script + keywords), plan.py (PLAN shots), project.json {"title"}, voiceovers/<id>.mp3

No full subtitles: only keyword callouts (YouTube auto-captions cover the rest).
Chapter title cards with flash + whoosh + impact, cold-open letterbox, colour grade, SFX.
Shots are anchored to the exact spoken word they illustrate (word times measured from the voiceover pauses).
Helpers (aligner, cut-aware clip logic) are shared with gen_frame_by_frame.py.
"""
import json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
src = open(f"{HERE}/gen_frame_by_frame.py").read().split("segs = json.load")[0]
exec(src)                                   # R, box169, FULL, CUTS, scene_of, align_words, pauses, dur, is_end, SRC ...

import sys
OUT = os.path.abspath(os.path.expanduser(sys.argv[1])) if len(sys.argv) > 1 else f"{HOME}/Downloads/GTA6 Long-form - Story Explained"
# soft fades to Rockstar title text that the hard-cut detector can't see
CUTS["t2"] = sorted(CUTS["t2"] + [69.3]); CUTS["t1"] = sorted(CUTS["t1"] + [14.6, 3.2])
SFXD = f"{HOME}/Youtube/shorts-pipeline/assets/sfx"
CARD, TAIL = 2.4, 0.45
GUYS = R(1060, 300, 720, 300); LUCIA_TXT = R(40, 580, 600, 270); FLOOR26 = R(1160, 260, 180, 280)

# (anchor word or None, kind, src, time(s) or [chain], param)
# v4 style switches (set STYLE = "v4" in plan.py): live footage plays untouched at real speed (no push-in, no slow-mo);
# every zoom happens on a frozen frame (live lead-in -> shutter snap -> zoom -> gentle drift); kinds q / s / ph are available
SFX_MODE = "all"; CH_WHOOSH = 0.55; CH_IMPACT = 0.6      # SFX_MODE "chapters" = sounds on chapter cards only
VO_FILE = None                                           # optional: function cid -> voiceover path (default voiceovers/<id>.mp3)
KW_PLATE = False; POP_VOL = 0.3                          # KW_PLATE True = keywords on the yellow plate; POP_VOL = pop sound under a circle / arrow mark
CH_HOLD = None; CH_FLASH = True                           # CH_HOLD = seconds a chapter title stays up (default CARD + 0.35); CH_FLASH False = no white flash
TAGS = {}                                                # v9: source key -> corner label shown on its normal shots (e.g. {"g1": "GTA 5"})
TEXT_STYLE = None; CH_PREFIX = ""                        # TEXT_STYLE "rank" = condensed yellow/black look; CH_PREFIX goes before chapter numbers in chapters.txt
VO_VOL = 1.0; HOOK_VOL = 0.28; RISER_VOL = 0.35; STYLE = "v3"; LEAD_MAX = 1.1; ZOOM_T = 0.9; LETTERBOX_C0 = True; LAST_TAIL = 3.2
PLAN_FILE = os.path.join(OUT, "plan.py")
exec(open(PLAN_FILE).read())                # defines PLAN (and may override CUTS / constants)

def norm(w): return re.sub(r"[^\w'-]", "", w).lower()
chapters = json.load(open(f"{OUT}/chapters.json"))
shots, vos, kws, chs, sfx, flashes, warns, cmarks, snaps = [], [], [], [], [], [], [], [], []
V4 = STYLE == "v4"
def shrink(r, f):
    return R(r["x"] + r["w"] * (1 - f) / 2, r["y"] + r["h"] * (1 - f) / 2, r["w"] * f, r["h"] * f)
def lead_in(sk, st, o0, o1, full):
    """live footage that runs into the freeze frame at `st`; returns the time the freeze starts"""
    if not V4 or o1 - o0 < 2.0: return o0
    s0, s1 = scene_of(sk, st)
    ld = min(LEAD_MAX, (o1 - o0) * 0.4, st - (s0 + 0.1))
    if ld < 0.4: return o0
    shots.append({"s": sk, "src": [round(st - ld, 3), round(st, 3)], "out": [round(o0, 3), round(o0 + ld, 3)], "from": full, "to": full})
    snaps.append(round(o0 + ld, 3)); sfx.append({"file": f"{SFXD}/tick.wav", "at": round(o0 + ld - 0.02, 3), "vol": 0.45})
    return o0 + ld
t = 0.0
for ci, ch in enumerate(chapters):
    cid = ch["id"]; path = VO_FILE(cid) if VO_FILE else f"{OUT}/voiceovers/{cid}.mp3"; d = dur(path)
    spoken = re.sub(r"\[[^\]]*\]\s*", "", ch["text"]).strip()
    words = spoken.split()
    cont = cid != "c0" and ch.get("chapter") is None      # continuation chunk: no chapter card
    lead = 0.35 if (cid == "c0" or cont) else CARD
    tail = LAST_TAIL if ci == len(chapters) - 1 else TAIL
    vo_at = t + lead; L = lead + d + tail
    vos.append({"file": path, "at": round(vo_at, 3)})
    wt = [(vo_at + a, vo_at + b) for a, b in align_words(words, pauses(path, 0.06))]
    if not cont: cmarks.append((t, "Intro" if cid == "c0" else (f"{CH_PREFIX}{ch['chapter']} {ch['title']}" if ch["chapter"] else ch["title"])))
    if cont: pass
    elif cid != "c0":
        chs.append({"t": [round(t + (0.25 if CH_HOLD else 0), 3), round(t + (CH_HOLD or CARD + 0.35), 3)], "num": ch["chapter"], "title": ch["title"]})
        if ch.get("kicker"): chs[-1]["kicker"] = ch["kicker"]
        if CH_FLASH: flashes.append(round(t, 3))
        sfx += [{"file": f"{SFXD}/whoosh.wav", "at": round(t - 0.45, 3), "vol": CH_WHOOSH, "ch": 1}, {"file": f"{SFXD}/impact.wav", "at": round(t + 0.05, 3), "vol": CH_IMPACT, "ch": 1}]
    else:
        sfx.append({"file": f"{SFXD}/riser.wav", "at": 0.0, "vol": RISER_VOL})
    # keywords: at the trigger word, held until 2.4 s or the next keyword
    trig = []
    pos = 0
    for word, text, *hold in ch["keys"]:                  # optional third item = seconds on screen (default 2.4)
        k = next((i for i in range(pos, len(words)) if words[i] == word), None)
        if k is None: warns.append(f"{cid} keyword trigger '{word}' not found"); continue
        trig.append((wt[k][0], text, hold[0] if hold else 2.4)); pos = k + 1
    for i, (a, text, hold) in enumerate(trig):
        b = min(a + hold, (trig[i + 1][0] - 0.15) if i + 1 < len(trig) else a + hold, t + L - 0.2)
        kws.append({"t": [round(a - 0.05, 3), round(b, 3)], "text": text})
        sfx.append({"file": f"{SFXD}/tick.wav", "at": round(a - 0.05, 3), "vol": 0.3})
    # beat start times from anchor words (searched in order)
    beats = PLAN[cid]; starts = [t]; pos = 0
    for b in beats[1:]:
        k = next((i for i in range(pos, len(words)) if norm(words[i]) == norm(b[0])), None)
        if k is None: warns.append(f"{cid} anchor '{b[0]}' not found"); starts.append(starts[-1] + 1.5); continue
        starts.append(wt[k][0] - 0.12); pos = k + 1
    starts.append(t + L)
    for bi in range(len(beats)):
        if starts[bi + 1] - starts[bi] < 0.7: warns.append(f"{cid} beat {bi} only {starts[bi+1]-starts[bi]:.2f}s")
    prev_rect = None
    for bi, beat in enumerate(beats):
        anc, kind, sk, st, prm = beat[:5]; opt = beat[5] if len(beat) > 5 else {}     # opt: {"mark": (u, v, r) in the target rect, "arrow": degrees}
        o0, o1 = starts[bi], starts[bi + 1]; full = FULL[sk]
        if os.environ.get("BEATS"): print("BEAT", cid, bi, kind, round(o0, 2), round(o1, 2))
        if kind == "q":                                   # fast-cut montage: st = [(src, time), ...], hard cuts, real speed
            clips = st; n = max(1, min(len(clips), int((o1 - o0) / 0.42))); step = (o1 - o0) / n
            for k in range(n):
                qs, qt = clips[k]; s0, s1 = scene_of(qs, qt); qt = max(qt, s0 + 0.06); ln = min(step, s1 - 0.08 - qt)
                if ln < step - 0.02: qt = max(s0 + 0.06, s1 - 0.08 - step); ln = min(step, s1 - 0.08 - qt)
                if ln < step - 0.02: warns.append(f"{cid} beat {bi} montage clip {qs} {clips[k][1]} shorter than {step:.2f}s")
                a, b = o0 + k * step, o0 + (k + 1) * step
                sh = {"s": qs, "src": [round(qt, 3), round(qt + ln, 3)], "out": [round(a, 3), round(b, 3)], "from": FULL[qs], "to": FULL[qs]}
                if k or prm: sh["join"] = True
                shots.append(sh)
                if k: sfx.append({"file": f"{SFXD}/whoosh.wav" if k % 2 == 0 else f"{SFXD}/tick.wav", "at": round(a - (0.12 if k % 2 == 0 else 0.02), 3), "vol": 0.22 if k % 2 == 0 else 0.3})
            prev_rect = None; continue
        if kind in ("s", "ph"):
            if kind == "s":
                f0 = lead_in(sk, st, o0, o1, full)
                sh = {"s": sk, "src": [st, round(st + 0.1, 3)], "out": [round(f0, 3), round(o1, 3)], "mode": "split", "from": full,
                      "region": prm["region"], "img": prm["img"], "dir": prm.get("dir", "h")}
                if f0 > o0: sh["join"] = True
                sfx.append({"file": f"{SFXD}/whoosh.wav", "at": round(f0 + 0.18, 3), "vol": 0.4})
            else:
                a = prm.get("from", R(0, 0, 1920, 1080)); b = prm.get("to", shrink(a, 0.93))
                sh = {"s": sk, "src": [st, round(st + 0.1, 3)], "out": [round(o0, 3), round(o1, 3)], "mode": "photo", "from": a, "to": b, "img": prm["img"]}
            for key in ("imgRegion", "credit", "label", "imgLabel"):
                if key in prm: sh[key] = prm[key]
            shots.append(sh); prev_rect = None; continue
        if kind == "m":
            chain = st if isinstance(st, list) else [st]
            to = full if V4 else box169(prm[0], prm[1], full["w"] * 0.88, sk); cur = o0
            hold_to = box169(prm[0], prm[1], full["w"] * 0.86, sk)
            sk0 = sk
            for ki, ct in enumerate(chain):
                sk = sk0
                if isinstance(ct, tuple): sk, ct = ct      # v4: a chain may hop between sources
                full = FULL[sk]
                if V4: to = full; hold_to = box169(prm[0], prm[1], full["w"] * 0.86, sk)
                s0, s1 = scene_of(sk, ct); ct = max(ct, s0 + 0.2); lim = s1 - 0.22
                avail, rem = lim - ct, o1 - cur
                if rem <= 0.3: break
                if avail < 0.3:
                    warns.append(f"{cid} beat {bi} clip {ct} skipped (scene ends)")
                    if ki < len(chain) - 1: continue
                    ct = s0 + 0.2; avail = lim - ct
                last = ki == len(chain) - 1
                if avail >= rem: segs = [(ct, ct + rem, cur, o1)]
                elif last and avail >= 0.8 * rem and not V4: segs = [(ct, lim, cur, o1)]
                elif not last: segs = [(ct, lim, cur, cur + avail)]
                else:
                    play = max(0.3, avail / (1.0 if V4 else 0.85))
                    if rem - play > 1.2: warns.append(f"{cid} beat {bi} ({sk} {ct}) holds {rem - play:.2f}s")
                    segs = [(ct, lim, cur, cur + play), (lim - 0.1, lim - 0.04, cur + play, o1)]
                for j, (a0, a1, b0, b1) in enumerate(segs):
                    sh = {"s": sk, "src": [round(a0, 3), round(a1, 3)], "out": [round(b0, 3), round(b1, 3)], "from": to if j else full, "to": to}
                    if j: sh["join"] = True
                    if j and V4: sh["from"] = full; sh["to"] = hold_to; snaps.append(round(b0, 3))
                    shots.append(sh)
                cur = segs[-1][3]
                if cur >= o1 - 0.05: break
            shots[-1]["out"][1] = round(o1, 3); prev_rect = None
        elif kind == "c":
            shots.append({"s": sk, "src": [st, round(st + 0.1, 3)], "out": [round(o0, 3), round(o1, 3)], "mode": "callout", "region": prm}); prev_rect = None
        else:
            f0 = lead_in(sk, st, o0, o1, full) if kind == "z" else o0
            sh = {"s": sk, "src": [st, round(st + 0.1, 3)], "out": [round(f0, 3), round(o1, 3)],
                  "from": prev_rect if (kind == "p" and prev_rect) else full, "to": prm}
            if (kind == "p" and prev_rect) or f0 > o0: sh["join"] = True
            if V4 and o1 - f0 > ZOOM_T + 0.5:              # decisive zoom, then a gentle drift so the still never looks dead
                sh["out"][1] = round(f0 + ZOOM_T, 3)
                shots.append(sh)
                sh = {"s": sk, "src": [st, round(st + 0.1, 3)], "out": [round(f0 + ZOOM_T, 3), round(o1, 3)], "from": prm, "to": shrink(prm, 0.95), "join": True}
            if opt.get("mark"):
                u, v, rf = opt["mark"]; split = sh.get("join") and sh["from"] == prm
                # the mark pops in while the zoom is still landing and rides the frame (it follows the crop), so it stays up as long as possible
                first = shots[-1] if split else sh
                at = 0.4 if split else max(0.3, min(0.5, (sh["out"][1] - sh["out"][0]) * 0.35))
                mk = {"x": round(prm["x"] + u * prm["w"], 1), "y": round(prm["y"] + v * prm["h"], 1), "r": round(rf * prm["w"], 1)}
                if opt.get("arrow") is not None: mk["arrow"] = opt["arrow"]
                first["mark"] = dict(mk, at=round(at, 3))
                if split: sh["mark"] = dict(mk, at=-1.0)             # already on screen: no second pop
                sfx.append({"file": f"{SFXD}/pop.wav", "at": round(first["out"][0] + at - 0.02, 3), "vol": POP_VOL, "ch": 1})
            shots.append(sh); prev_rect = prm
    if cid == "c0": letter = [[0.0, round(t + L - 0.4, 3)]] if LETTERBOX_C0 else []
    t += L

for sh in shots:
    if sh["s"] in TAGS and sh.get("mode") not in ("split", "photo"): sh["tag"] = TAGS[sh["s"]]
if SFX_MODE == "chapters": sfx = [x for x in sfx if x.get("ch")]
for x in sfx: x.pop("ch", None)
edit = {"out": f"{OUT}/" + json.load(open(f"{OUT}/project.json"))["title"] + ".mp4", "sources": SRC, "vo": vos,
        "shots": shots, "captions": [], "cards": [], "badges": [], "timedCaptions": True, "xfade": 0.35,
        "musicVol": 0.085, "duckHigh": 0.2, "keywords": kws, "chapters": chs, "sfx": sfx, "grade": False,
        "letterbox": letter, "flashes": flashes, "snaps": snaps, "voVol": VO_VOL, "hookVol": HOOK_VOL}
if CH_HOLD:                                               # a lower-third title leaves as the first keyword of its chapter arrives
    for c in chs:
        k0 = [k["t"][0] for k in kws if c["t"][0] <= k["t"][0] < c["t"][1]]
        if k0: c["t"][1] = round(max(c["t"][0] + 2.6, min(k0) + 0.3), 3)
if TEXT_STYLE: edit["textStyle"] = TEXT_STYLE
if KW_PLATE: edit["kwPlate"] = True
json.dump(edit, open(f"{OUT}/edit-list.json", "w"), indent=1)
with open(f"{OUT}/chapters.txt", "w") as f:
    for c0, name in cmarks: f.write(f"{int(c0 // 60)}:{int(c0 % 60):02d} {name}\n")
print(f"total {t:.1f}s = {int(t // 60)}:{t % 60:04.1f}  shots {len(shots)}  keywords {len(kws)}  sfx {len(sfx)}")
for w in warns: print("WARN", w)
