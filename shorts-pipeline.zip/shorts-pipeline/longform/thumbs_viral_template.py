# "99% missed" style thumbnail: full-frame driving shot + magnified circle + arrow + tilted headline
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import os, math
SP = "/private/tmp/claude-501/-Users-hemanthkumaro11-GTA6-Videos--Claude/75f56bcd-1d80-404f-b5cb-d35c54224fca/scratchpad/k"
OUT = os.path.expanduser("~/GTA6 Videos _Claude/GTA6 Long-form - Hidden Details/thumbnails")
FONT = "/System/Library/Fonts/Supplemental/Impact.ttf"
W, H = 1280, 720
WHITE, ORANGE, RED = (255, 255, 255), (255, 158, 12), (238, 28, 36)

def grade(im, sat=1.35, con=1.12, bri=1.08):
    im = ImageEnhance.Color(im).enhance(sat); im = ImageEnhance.Contrast(im).enhance(con)
    return ImageEnhance.Brightness(im).enhance(bri)
def base(name, box=None, **g):
    im = Image.open(f"{SP}/{name}").convert("RGB"); k = im.width / 1920
    if box: im = im.crop(tuple(int(v * k) for v in box))
    return grade(im.resize((W, H), Image.LANCZOS), **g)
def lens(name, cx, cy, size, d, **g):
    """square crop of `size` px (1920 coords) around (cx, cy), returned as a d x d circle"""
    im = Image.open(f"{SP}/{name}").convert("RGB"); k = im.width / 1920
    im = im.crop((int((cx - size / 2) * k), int((cy - size / 2) * k), int((cx + size / 2) * k), int((cy + size / 2) * k)))
    im = im.resize((d * 2, d * 2), Image.LANCZOS).filter(ImageFilter.UnsharpMask(4, 160, 2))
    im = grade(im, **g).resize((d, d), Image.LANCZOS)
    m = Image.new("L", (d * 4, d * 4), 0); ImageDraw.Draw(m).ellipse((0, 0, d * 4 - 1, d * 4 - 1), fill=255)
    return im, m.resize((d, d), Image.LANCZOS)
def circle(im, c, r, w=13):
    S = 4; o = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0)); d = ImageDraw.Draw(o)
    d.ellipse(((c[0] - r - 5) * S, (c[1] - r - 5) * S, (c[0] + r + 5) * S, (c[1] + r + 5) * S), outline=(255, 255, 255, 255), width=(w + 10) * S)
    d.ellipse(((c[0] - r) * S, (c[1] - r) * S, (c[0] + r) * S, (c[1] + r) * S), outline=RED + (255,), width=w * S)
    o = o.resize((W, H), Image.LANCZOS); im.paste(o, (0, 0), o)
def arrow(im, a, b, width=20, head=62):
    S = 4; o = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0)); d = ImageDraw.Draw(o)
    ang = math.atan2(b[1] - a[1], b[0] - a[0])
    e = (b[0] - head * 0.75 * math.cos(ang), b[1] - head * 0.75 * math.sin(ang))
    pts = [b, (b[0] - head * math.cos(ang - 0.55), b[1] - head * math.sin(ang - 0.55)), (b[0] - head * math.cos(ang + 0.55), b[1] - head * math.sin(ang + 0.55))]
    for col, grow in (((255, 255, 255, 255), 7), (RED + (255,), 0)):
        d.line([(a[0] * S, a[1] * S), (e[0] * S, e[1] * S)], fill=col, width=(width + grow * 2) * S)
        if grow:
            cx = sum(p[0] for p in pts) / 3; cy = sum(p[1] for p in pts) / 3
            big = [((p[0] - cx) * 1.32 + cx, (p[1] - cy) * 1.32 + cy) for p in pts]
            d.polygon([(x * S, y * S) for x, y in big], fill=col)
        else: d.polygon([(x * S, y * S) for x, y in pts], fill=col)
    o = o.resize((W, H), Image.LANCZOS); im.paste(o, (0, 0), o)
def headline(im, lines, right, top, angle=-4):
    """lines = [[(text, colour), ...], ...] right-aligned, heavy black stroke + drop shadow, tilted"""
    pad = 60; L = Image.new("RGBA", (W + pad * 2, H + pad * 2), (0, 0, 0, 0)); d = ImageDraw.Draw(L); y = top + pad
    for size, parts in lines:
        f = ImageFont.truetype(FONT, size); gap = size * 0.2
        tw = sum(d.textlength(t, font=f) for t, _ in parts) + gap * (len(parts) - 1); x = right + pad - tw
        for t, col in parts:
            d.text((x + 7, y + 9), t, font=f, fill=(0, 0, 0, 255), stroke_width=13, stroke_fill=(0, 0, 0, 255))
            d.text((x, y), t, font=f, fill=col + (255,), stroke_width=13, stroke_fill=(0, 0, 0, 255))
            x += d.textlength(t, font=f) + gap
        y += size * 1.06
    sh = L.split()[3].filter(ImageFilter.GaussianBlur(14)).point(lambda v: int(v * 0.75))
    shadow = Image.new("RGBA", L.size, (0, 0, 0, 0)); shadow.putalpha(sh)
    L = Image.alpha_composite(shadow, L).rotate(-angle, resample=Image.BICUBIC, center=(right + pad, top + pad))
    im.paste(L, (-pad, -pad), L)
def make(name, b, lens_args, c, r, tip, lines, right=1250, top=60, **g):
    im = base(*b, **g)
    l, m = lens(*lens_args, r * 2, **g); im.paste(l, (c[0] - r, c[1] - r), m)
    circle(im, c, r)
    ang = math.atan2(tip[1] - c[1], tip[0] - c[0])
    arrow(im, (c[0] + (r + 4) * math.cos(ang), c[1] + (r + 4) * math.sin(ang)), tip)
    headline(im, lines, right, top)
    im.save(f"{OUT}/{name}.jpg", quality=93)

# E — faithful recreation: Vice City FM bus-stop ad (frame el 528.2, ad magnified from the sharper 527.8)
HEAD = [(108, [("99%", WHITE), ("OF PEOPLE", ORANGE)]), (132, [("MISSED", ORANGE)])]
make("Thumbnail E - 99 percent missed (bus stop)", ("f_528.2.jpg",), ("f_527.8.jpg", 392, 470, 130), (400, 168), 120, (190, 296), HEAD, top=70)
# F — same layout, but the detail is one the video actually covers: the road sign
make("Thumbnail F - 99 percent missed (road sign)", ("f_763.7.jpg",), ("f_763.9.jpg", 690, 392, 215), (175, 185), 140, (436, 268), HEAD, top=70,
     sat=1.3, con=1.1, bri=1.05)
prev = Image.new("RGB", (W, H * 2))
for i, n in enumerate(sorted(x for x in os.listdir(OUT) if x[10] in "EF")): prev.paste(Image.open(f"{OUT}/{n}"), (0, i * H))
prev.save(os.path.dirname(SP) + "/viral_preview.jpg", quality=90); print("ok")
