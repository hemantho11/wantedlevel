# Gaming Shorts pipeline — paste this prompt to Claude

> Copy everything below the line into a new Claude Code session. Fill in the two `<< >>` fields.
> The pipeline tools are already built at `~/Youtube/shorts-pipeline/` — do NOT rebuild anything.

---

I run the YouTube channel "Wanted Level" and cut vertical Shorts from game footage with my own voiceover. A working pipeline already exists at `/Users/hemanthkumaro11/Youtube/shorts-pipeline/` — read its `README.md` first and use those tools as-is. Do not write a new editor, do not use ffmpeg (not installed), do not change fonts, colours, sizes or audio levels.

**Source video:** `<< path to the source mp4 >>`
**Output folder:** `<< e.g. ~/Downloads/<Game> Shorts >>`

## Phase 1 — analyse and script (I stop here and record voiceovers)

1. Make timestamped contact sheets of the whole source with `tools/sheets` (every 8 s), read them, and pick the 10 most viral moments. Rank them; explain why each one works in one line.
2. Write `scripts.md` in the output folder: 10 scripts, 25–40 s each, one script per moment. Each script line = one shot, with a `VO:` line (what I say) and a `Visual:` line (source timestamp). Rules:
   - Hook in the first sentence, comment-bait question at the end.
   - Every script should say "GTA 6" (or the game's name) at least once — it triggers the logo animation.
   - Only claim things visible in the footage; flag any guess.
3. Continue straight into Phase 1b. Do not wait for me. If the footage has fewer than 10 strong moments, make the ones that are genuinely good (minimum 6) instead of padding, and say so in the report.

## Phase 1b — voiceovers (ElevenLabs connector, no manual step)

Generate every voiceover here with the ElevenLabs connector (`creative_generate_speech`). Fixed settings — never change them:
- **voice_id `dtSEyYGNJqjrtBArPCVZ`** — "Titan - Deep, Bold, and Powerful" (confirm with `creative_list_voices` search "Titan" if the id ever fails)
- **model_id `eleven_v3`**
- **generations_count 1** per Short (not the default 4)
- Stability "natural" is my ElevenLabs preset; the connector has no stability field, so leave it at the default.

Process per Short:
1. `prompt` = the VO text only (no "VO:" labels, no timestamps). Keep the punctuation — periods and "…" are what make the pauses the editor needs. Emphasis words may be CAPITALISED sparingly; no `[audio tags]`.
2. Run `estimate_only: true` once for the first Short (≈ 370 credits / $0.07 per Short is normal). Under 800 credits per Short: proceed without asking. Above: still proceed, but put the total at the top of the final report.
3. Generate all 10, one take each. If a take fails or fails verification (step 5), regenerate that Short once; if it fails twice, use the best available take and flag it in the report. Never regenerate a take that passed.
4. Poll `creative_get_flow_run_status` with the returned `flow_id` + `session_ids` until `all_completed`; the result's `media[].url` is a signed link that expires in ~2 hours, so download at once with `curl -sL -o` into `<output folder>/voiceovers/shortNN.mp3`.
5. Verify each file: `tools/pauses <mp3> 0.25` shows at least one gap, `tools/rms` reads −13 to −20 dBFS, `afinfo` duration is 12–40 s. Anything outside → regenerate that Short once (rule 3).
6. Then go straight into Phase 2.

## Phase 2 — cut (runs immediately after Phase 1b)

Use the exact style from the last batch — every value below is already the default in `tools/editor`; just don't override it.

**Audio**
- Strip ALL source game audio. Only my voiceover + music.
- `~/Youtube/Hook.mp3` from 0:00, fading out over its last second; `~/Youtube/BG Music (Loop).mp3` fades in underneath, loops to the end, fades out over the last 1.2 s.
- Volumes: voice 100 %, hook 28 %, loop 9 %. Never louder — final mix should measure about −16 to −17 dBFS with `tools/rms`.

**Captions** (my reference style: one word at a time)
- One word per caption, tiny words (≤3 letters) ride with the next word — but never across a sentence or a script line.
- Arial Black ~104 px, white, thick black outline, drop shadow, mid-screen. Key words wrapped in `*asterisks*` in the edit list turn bright green.
- Word timing must come from the voiceover's loudness envelope (the editor does this) — never split by character count.
- No quote marks on screen.

**Overlays**
- Channel logo `assets/channel_logo.png` top-left, 210 px, 65 % opacity, on every frame.
- `assets/gta6_logo.png` slides up whenever "GTA 6" is spoken, holds ~1 s, drops away, replaces the caption for that word. Must NOT fire on "GTA 5" or a bare "GTA".

**Picture**
- 1080×1920, 30 fps, H.264 12 Mbps, AAC 192 kbps.
- Prefer full-height 9:16 crops of the 16:9 source (`from`/`to` rects animate a slow push or pan). Use `"mode": "fit"` (letterbox on blurred background) only when the whole frame matters (HUD, wide aerials, text cards).
- Use `"mode": "callout"` with a `region` for tiny UI prompts — magnified inset with a highlight box.
- Slow-mo on the one big action beat per Short (map a shorter `src` range onto a longer `out` range).
- Freeze-frame on text messages / readable UI; put captions at the top (`"captionTop": true`) so they don't cover it.
- `"captionY"` per shot when the caption would land on readable in-game text.
- The video must outlast the voiceover by ~0.3 s (editor extends the last shot automatically).

**Process — do these steps, in this order, every time**
1. Detect each voiceover's sentence pauses with `tools/pauses <mp3> 0.25` and use those as the caption `t` ranges — shots switch when a sentence starts.
2. For every shot, verify the exact source timestamp with `tools/fine` (1 s steps) before writing it into the edit list; never trust the 8 s sheet alone.
3. Write `edit-lists/shortNN.json` (format = `example-edit-lists/`), render with `tools/editor <source> <edit.json>`.
4. Dump check frames with `--frames t1 t2 …`, look at them. Specifically check: first frame is a clean hook image (feed thumbnail), captions don't cover chat/text/faces, callouts point at the right thing, logo fires only on "GTA 6".
5. Make a contact sheet of every finished Short with `tools/fine <short.mp4> … 0 <dur> 0.85`, read all ten as a viewer, fix anything sloppy, re-render.
6. Verify: `tools/rms` on every output (no clipping, −15.5…−17.6 dBFS), `tools/pauses <mp4> 1.5` finds no dead audio gaps, `tools/probe` shows 1080×1920.
7. Render the no-subtitle versions too: `tools/editor <source> <edit.json> --nocaps` → `no-subtitles/`.
8. Delete stray `*.sb-*` temp files and `*.jpg` check frames from the output folder; copy the edit lists into `edit-lists/`.
9. Give me a per-Short table: file, length, size, loudness, and your honest "post / post with note" verdict as an audience member, plus a suggested posting order.

Never stop for confirmation. Run Phase 1 → 1b → 2 end to end, make every judgement call yourself, and report once at the end — including anything you decided on my behalf (regenerated takes, skipped moments, cost above normal).

> Shortcut: in Claude Code, `/shorts <path to mp4>` runs this whole document with the output folder derived from the file name.
