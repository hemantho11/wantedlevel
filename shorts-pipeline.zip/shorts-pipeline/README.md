# shorts-pipeline

Self-contained toolchain for cutting vertical Shorts from game footage with a voiceover, on macOS with no ffmpeg (Swift + AVFoundation only). Built Sept 2026 for the GTA 6 Extended Look batch.

## Layout
- **Run a batch:** type `/shorts <path to mp4>` in Claude Code (skill at `~/.claude/skills/shorts/SKILL.md`). Fully autonomous — no questions, one report at the end.
- `PROMPT.md` — the full spec the skill follows; also usable by pasting into a session.
- `tools/` — compiled binaries + sources. Re-compile any tool with `swiftc -O name.swift -o name` (warnings are fine).
- `assets/` — `channel_logo.png` (Wanted Level, transparent), `gta6_logo.png` (background keyed out).
- `example-edit-lists/` — the 10 finished edit lists from the GTA 6 batch + the scripts that produced them. Copy one as a template.

Music lives outside this folder and is referenced by absolute path in `editor.swift`:
`~/Youtube/Hook.mp3` and `~/Youtube/BG Music (Loop).mp3`.

## Voiceovers (ElevenLabs connector)
Voice **Titan - Deep, Bold, and Powerful** = `voice_id dtSEyYGNJqjrtBArPCVZ`, model `eleven_v3`, one take per Short (~370 credits ≈ $0.07). The connector's `creative_generate_speech` returns a flow + session id; `creative_get_flow_run_status` gives a signed `media[].url` (expires ~2 h) — `curl` it to `voiceovers/shortNN.mp3`. A verified sample is in `elevenlabs-test/short01-titan-v3.mp3` (22 s, −15.8 dBFS, sentence gaps 0.3–0.7 s — the editor aligns captions to it fine). The connector exposes no stability control; the user's ElevenLabs preset is "natural".

## Tools
| tool | usage | what it does |
|---|---|---|
| `editor` | `editor <source.mp4> <edit.json>` | Renders one Short from an edit list. `--frames t1 t2…` dumps check frames instead of rendering. `--nocaps` renders without word captions into `no-subtitles/`. |
| `sheets` | `sheets <video> <outDir> <stepSec>` | Contact sheets (4×5, timestamped) of a whole video — first-pass scouting. |
| `fine` | `fine <video> <outPrefix> <start> <end> <step>` | Fine contact sheets (6×5) of a range — pin exact cut points, or review a finished Short at 0.85 s. |
| `grab` | `grab <video> <outDir> t1 t2…` | Full-res single frames. |
| `cropsheet` | `cropsheet <video> <out.jpg> x y w h start end step` | Sub-second sheet of a cropped region — locate UI prompts. |
| `pauses` | `pauses <audio> [minGapSec]` | Speech segments split at silences ≥ gap. Use 0.25 on voiceovers for sentence ranges; 1.5 on finished mp4s to catch dead air. |
| `rms` | `rms <audio/video>` | 90th-percentile loudness + peak (dBFS). |
| `probe` | `swift probe.swift <video>` | Tracks, size, duration. |
| `keybg` | `keybg <in.jpg> <out.png>` | Removes a checkerboard/neutral background from a logo (flood-fill from edges). |

## Edit list format (`edit-lists/shortNN.json`)
```json
{
  "vo":  "/abs/path/voiceovers/short01.mp3",
  "out": "/abs/path/Short01 - Title.mp4",
  "hookVol": 0.28, "musicVol": 0.09,             // optional, these are the defaults
  "shots": [
    {"src": [729.5, 731.58], "out": [0, 4.16],
     "from": {"x": 500, "y": 0, "w": 607, "h": 1080}, "to": {"x": 560, "y": 80, "w": 540, "h": 960}},
    {"src": [1104.0, 1108.3], "out": [4.16, 7.66], "mode": "fit"},
    {"src": [588.5, 591.92], "out": [8.70, 12.12], "mode": "callout", "region": {"x": 1690, "y": 1000, "w": 225, "h": 72}},
    {"src": [1434.0, 1434.1], "out": [7.90, 12.86], "from": {"x": 0, "y": 590, "w": 640, "h": 300}, "captionTop": true},
    {"src": [1104.0, 1106.38], "out": [0, 2.38], "from": {...}, "captionY": 300}
  ],
  "captions": [
    {"t": [0.24, 3.66], "chunks": ["Remember *THIS* scene", "from the very first GTA 6 trailer?"]}
  ]
}
```
- `src` = source seconds, `out` = timeline seconds. Different lengths → speed change (slow-mo / freeze).
- Crop rects are top-left px in the 1920×1080 source. `from`→`to` animates with ease-in-out.
- `mode`: default crop | `fit` (letterbox on blurred bg) | `callout` (magnified inset of `region`).
- `captionTop` / `captionY` move the caption for that shot.
- `captions[].t` = sentence range from `pauses`; `chunks` = script lines; `*word*` = green highlight. Words are shown one at a time, timed to the voice envelope.

## Style constants baked into `editor.swift`
Caption font Arial Black 104 px, stroke 14, green `#73ED1F`; channel logo 210 px @ 65 % top-left (40,40); GTA logo 640 px wide, slides up 0.28 s, holds to 1.15 s, drops 0.25 s; hook fades out over its last 1 s, loop fades in over 1 s and out over the last 1.2 s; H.264 12 Mbps 1080×1920 30 fps, AAC 192 kbps.

## Long-form (16:9) — `longform/`
- `longform/editor_long <edit.json> [--nocaps] [--frames t…]` — 1920×1080 renderer. Multiple sources per edit (`"sources": {"t1": path, …}`, each shot has `"s"`), multiple voiceover chunks placed at absolute times (`"vo": [{"file", "at"}]`), subtitle-style captions (one line at a time, bottom; per-shot `"capY"` lifts them), numbered detail cards (`"cards": [{"t", "num", "title", "tag"}]` — big pop for 1.5 s then a corner tag), `"badges"` = times for the GTA 6 logo. Same music bed, logo and loudness as the Shorts. Shot modes: crop (`from`/`to`, 16:9 rects) or `callout` (`region`). A freeze needs `src` ≥ 0.1 s.
- `longform/gen_frame_by_frame.py` + `anchors.json` — builds the edit list for the "25 details" video from `segments.json` + downloaded voiceovers: per detail a card, shots split by weight and anchored to sentence starts (DP maps sentences onto `tools/pauses` segments). Copy it as the template for the next long-form video.
- Trailer 1's social-media montage cuts every ~1 s — scout it with `tools/fine … 0.25` before picking timestamps.
- **v2 (Sept 28):** `editor_long` now does 0.3 s dissolves between shots (A/B tracks; `"join": true` = hard cut), animated callouts (fade-in + slow push), and music ducking (loop rises to `duckHigh` in voiceover gaps). `"timedCaptions": true` shows each caption exactly at `captions[].t`. `gen_frame_by_frame.py` times every word from the voiceover's pauses, anchors each shot to the sentence it illustrates, plays live footage at ≥0.8× speed and never across a source cut (`tools/cuts <video>` → `longform/cuts_*.txt`). `--validate` checks the composition. v1 files kept as `*.bak`.
- **v3 (Sept 28, story video):** `editor_long` adds `keywords` (keyword callouts instead of subtitles), `chapters` (title cards with blur/bars), `sfx` (`assets/sfx/` whoosh, impact, tick, riser), `grade` (colour + shadow lift + vignette), `letterbox` ranges, `flashes`. `gen_story.py` is the template: script in `chapters.json` with ElevenLabs v3 audio tags, shots anchored to spoken words. Narrator voice: **Leo** (`TLC61WvtioR7PrhxZ1RH`), eleven_v3. `tools/prosody` scores voice expressiveness.

## One-command long-form: `/longform <topic>`
Skill at `~/.claude/skills/longform/SKILL.md` → spec `longform/PROMPT_LONGFORM.md` → generic builder `longform/gen_longform.py <project folder>` (reads `chapters.json`, `plan.py`, `project.json`, `voiceovers/`) → `longform/editor_long` → thumbnails from `longform/thumbs_template.py`. Reference project: `longform/examples/story-explained/`. User rules: Leo voice (eleven_v3 + emotion tags), keyword callouts only (no subtitles), **no colour grade**, premium cards/SFX/dissolves, 4 curiosity thumbnails.
- **4K source (Sept 28):** Extended Look now comes from `~/Downloads/GTAVI_An_Extended_Look.mp4` (official 4K, frame-aligned with the old 1080p copies, so all timestamps and `cuts_el.txt` still apply). `editor_long` crops and callout insets from the native 4K frame and outputs 1920×1080 at 20 Mbps. Each render leaves a `*.mp4.sb-*` temp copy beside the output — delete it after rendering (disk is nearly full). Plan rects stay in 1920×1080 coordinates.
- **v4 (Sept 29, "GTA 6 vs Real Life"):** set `STYLE = "v4"` in `plan.py`. Live footage plays untouched at real speed (no push-in, no slow-mo); every zoom is freeze-then-zoom (live lead-in → shutter snap → 0.9 s zoom → gentle drift). New plan kinds: `q` fast-cut montage `[(src, t), …]` (hard cuts ≈0.45 s, for the hook), `s` split screen (frozen game frame | real photo, with labels + credit), `ph` full-screen photo with slow pan. `m` chains may hop sources with `(src, t)` tuples. `plan.py` can override `SRC`, `VO_VOL`, `HOOK_VOL`, `RISER_VOL`, `LETTERBOX_C0`. Editor adds shot modes `split` / `photo` (`img`, `imgRegion`, `dir`, `imgLabel`, `credit`), `snaps`, `voVol`. Photos must be 16:9 (2560×1440 in `photos/fit/`). Sources now live in `~/GTA6 Videos _Claude/`. v3 backups: `editor_long_v3_4k.swift.bak`, `gen_longform_v3.py.bak`. Reference project: `~/GTA6 Videos _Claude/GTA6 Long-form - Real Life vs Game/`.
- **Sept 29, "Hidden Details" remake:** `editor_long` edit lists accept `"bitrate"` (bits/s, default 20 Mbps) and `"fastStart": false` (skips the network-optimise pass, so no `*.sb-*` temp copy — use it when the disk is nearly full; a 9 min render at 20 Mbps + temp copy needs ~2.5 GB and failed at 2 GB free). `tools/match` was a copy of the Swift source, not a binary — compile `match.swift` before use. Extended Look 1061–1070 is a fast montage of unrelated clips with soft cuts; the strip-mall scene starts at 1070.13. Backup: `editor_long_v4.swift.bak`. Reference project: `~/GTA6 Videos _Claude/GTA6 Long-form - Hidden Details/`.
- **v6 (Sept 29, "Mechanics Ranked"):** optional second text look. `TEXT_STYLE = "rank"` in `plan.py` (edit-list key `"textStyle": "rank"`) gives DIN Condensed yellow keyword plates that wipe in, and chapter cards with a giant yellow rank number ("#15 | KNOCK FIRST", kicker "NEW MECHANIC"; a chapter with `"chapter": ""` gets a centred title, and `"kicker"` in `chapters.json` overrides the small line). Without it everything renders in the classic white/green look. Also new in `gen_longform.py`: `CH_PREFIX` (text before chapter numbers in `chapters.txt`, e.g. "#"), `VO_FILE = lambda cid: path` (use processed voiceovers, e.g. loudness-matched WAVs), and a chunk with `"chapter": null` that is not `c0` continues the previous chapter with no card. ElevenLabs takes vary from -12 to -17 dBFS, so level them to about -15.5 before mixing; with that, `VO_VOL = 0.88` lands near -16.8 dBFS. `box169` only clamps to the frame edge, so a rect for a corner HUD must be centred no further than half its width from the edge. Button prompts sit bottom right (`box169(1780, 1000, 480)`), wanted stars and icons top right (`box169(1745, 60, 420)`). Music now also lives in `~/GTA6 Videos _Claude/` (copies of `Hook.mp3`, `BG Music (Loop).mp3`); the editor still reads `~/Youtube/`. Backups: `editor_long_v5.swift.bak`, `gen_longform_v5.py.bak`. Reference project: `~/GTA6 Videos _Claude/GTA6 Long-form - Mechanics Ranked/`.
- **v7 (Sept 29, same video):** in the "rank" text style the chapter title is now a lower third over live footage (no dim, blur, bars or black card): slanted yellow number plate, title, gold rule, gradient under the text only. `plan.py`: `CARD = 1.9` (footage lead before the narration), `CH_HOLD = 4.4` (seconds the title stays; it leaves early when the chapter's first keyword arrives), `CH_FLASH = False`. The classic style still uses the old centred card. Backups: `editor_long_v6.swift.bak`, `gen_longform_v6.py.bak`.
- **v8 (Sept 29, same video, third review):** "rank" keywords are text only (`kwPlate: true` / `KW_PLATE = True` restores the plate). New shot field `mark {x, y, r, arrow, at}` (1920x1080 source coords) draws a red circle + arrow that follows the crop; `gen_longform.py` takes a sixth beat item `{"mark": (u, v, r), "arrow": deg}` and adds `assets/sfx/pop.wav`. Keys accept a hold time. Sources moved to `~/GTA6 Videos _Claude/4k trailers/`. Backups: `editor_long_v7.swift.bak`, `gen_longform_v7.py.bak`.
- **v9 (Sept 29, "Driving vs GTA 5"):** comparison footage from another game. `plan.py` adds extra sources (`SRC[k]`, `CUTS[k] = []`, `SRCLEN[k]`, `FULL[k]`) and `TAGS = {"g1": "GTA 5"}`; every normal shot from a tagged source gets a small corner label (shot field `"tag"`, top right). Split screens take a grabbed frame of the other game as `img` with `imgLabel: "GTA 5"`. A custom `FULL[k]` crops a source (used to hide in-game subtitles). `gen_longform.py` does not write `fastStart`; set `"fastStart": false` in `edit-list.json` after generating when the disk is nearly full. HUD icons can blink or change within a freeze's 0.1 s window, so check the exact frame. Backups: `editor_long_v8.swift.bak`, `editor_long_v8.bin.bak`, `gen_longform_v8.py.bak`. Reference project: `~/GTA6 Videos _Claude/GTA6 Long-form - Driving vs GTA 5/`.
- **v11 (Sept 30, Six Stars Hindi channel):** `edit-list.json` may set `"logoPath"` (PNG with alpha), `"logoSize"` (px wide, default 150) and `"logoAlpha"` (default 0.65) to use another channel's logo; without them the Wanted Level logo is used as before. Backups: `editor_long_v10.swift.bak`, `editor_long_v10.bin.bak`.
