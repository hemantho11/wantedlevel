import AVFoundation
import Accelerate
// usage: match <reference.mp4> <refStep s> <source1.mp4> [source2 ...]
// For every reference sample prints: refTime  bestSourceIndex  sourceTime  distance
// Signature: 32x18 luma of the frame band y 22%..95% (skips top subtitle area), mean/std normalised.
let GW = 32, GH = 18
func sigs(_ path: String, every: Double) -> ([Double], [[Float]]) {
    let a = AVURLAsset(url: URL(fileURLWithPath: path))
    let s = DispatchSemaphore(value: 0); var tr: AVAssetTrack!
    Task { tr = try! await a.loadTracks(withMediaType: .video).first!; s.signal() }; s.wait()
    let r = try! AVAssetReader(asset: a)
    let o = AVAssetReaderTrackOutput(track: tr, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange])
    o.alwaysCopiesSampleData = false; r.add(o); r.startReading()
    var ts: [Double] = [], out: [[Float]] = []; var next = 0.0
    while let sb = o.copyNextSampleBuffer() {
        let t = CMSampleBufferGetPresentationTimeStamp(sb).seconds
        if t + 0.001 < next { continue }
        next = t + every
        guard let pb = CMSampleBufferGetImageBuffer(sb) else { continue }
        CVPixelBufferLockBaseAddress(pb, .readOnly)
        let base = CVPixelBufferGetBaseAddressOfPlane(pb, 0)!.assumingMemoryBound(to: UInt8.self)
        let w = CVPixelBufferGetWidthOfPlane(pb, 0), h = CVPixelBufferGetHeightOfPlane(pb, 0), bpr = CVPixelBufferGetBytesPerRowOfPlane(pb, 0)
        let y0 = Int(Double(h) * 0.22), y1 = Int(Double(h) * 0.95)
        var g = [Float](repeating: 0, count: GW * GH)
        for gy in 0..<GH { for gx in 0..<GW {
            var sum = 0, n = 0
            let ya = y0 + gy * (y1 - y0) / GH, yb = y0 + (gy + 1) * (y1 - y0) / GH, xa = gx * w / GW, xb = (gx + 1) * w / GW
            var yy = ya; while yy < yb { var xx = xa; while xx < xb { sum += Int(base[yy * bpr + xx]); n += 1; xx += 6 }; yy += 6 }
            g[gy * GW + gx] = Float(sum) / Float(max(n, 1))
        } }
        CVPixelBufferUnlockBaseAddress(pb, .readOnly)
        var mean: Float = 0, sd: Float = 0
        vDSP_normalize(g, 1, &g, 1, &mean, &sd, vDSP_Length(g.count))
        if !(sd > 3) { g = [Float](repeating: 0, count: g.count) }   // flat/black frame
        ts.append(t); out.append(g)
    }
    return (ts, out)
}
let args = CommandLine.arguments
let (rt, rs) = sigs(args[1], every: Double(args[2])!)
var srcs: [([Double], [[Float]])] = []
for p in args[3...] { srcs.append(sigs(p, every: 0.2)) }
let D = Float(GW * GH)
for (i, r) in rs.enumerated() {
    var best: Float = .greatestFiniteMagnitude, bs = -1, bt = 0.0
    if r.allSatisfy({ $0 == 0 }) { print(String(format: "%.2f -1 0 9", rt[i])); continue }
    for (k, (st, ss)) in srcs.enumerated() {
        for (j, s) in ss.enumerated() {
            var d: Float = 0; vDSP_distancesq(r, 1, s, 1, &d, vDSP_Length(r.count))
            if d < best { best = d; bs = k; bt = st[j] }
        }
    }
    print(String(format: "%.2f %d %.2f %.3f", rt[i], bs, bt, best / D))
}
