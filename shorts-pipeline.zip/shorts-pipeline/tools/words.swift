import Foundation
import Speech
// usage: words <audio>  -> prints "start end word" per recognised word (on-device recognition)
setvbuf(stdout, nil, _IONBF, 0)
let url = URL(fileURLWithPath: CommandLine.arguments[1])
let sem = DispatchSemaphore(value: 0)
var status = SFSpeechRecognizer.authorizationStatus()
if status == .notDetermined {
    SFSpeechRecognizer.requestAuthorization { s in status = s; sem.signal() }
    _ = sem.wait(timeout: .now() + 20)
}
guard status == .authorized else { print("NOT_AUTHORIZED \(status.rawValue)"); exit(2) }
let rec = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))!
let req = SFSpeechURLRecognitionRequest(url: url)
req.requiresOnDeviceRecognition = rec.supportsOnDeviceRecognition
req.shouldReportPartialResults = false
req.addsPunctuation = false
let done = DispatchSemaphore(value: 0)
rec.recognitionTask(with: req) { result, error in
    if let r = result, r.isFinal {
        for s in r.bestTranscription.segments { print(String(format: "%.3f %.3f %@", s.timestamp, s.timestamp + s.duration, s.substring)) }
        done.signal()
    } else if let e = error { print("ERROR \(e.localizedDescription)"); done.signal() }
}
_ = done.wait(timeout: .now() + 120)
