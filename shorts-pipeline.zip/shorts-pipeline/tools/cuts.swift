import AVFoundation
import CoreVideo
// usage: cuts <video> [threshold]
// prints hard-cut times (seconds), one per line: frame-to-frame luma difference on a 48x27 grid,
// flagged when it spikes well above the local median (handles fast motion without false cuts)
let url = URL(fileURLWithPath: CommandLine.arguments[1])
let k = Double(CommandLine.arguments.count > 2 ? CommandLine.arguments[2] : "4.0")!
let asset = AVURLAsset(url: url)
let sem = DispatchSemaphore(value: 0)
var track: AVAssetTrack!
Task { track = try! await asset.loadTracks(withMediaType: .video).first!; sem.signal() }; sem.wait()
let reader = try AVAssetReader(asset: asset)
let out = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange])
out.alwaysCopiesSampleData = false
reader.add(out); reader.startReading()
let GW = 48, GH = 27
var prev: [Double]? = nil
var times: [Double] = [], diffs: [Double] = []
while let sb = out.copyNextSampleBuffer() {
    guard let pb = CMSampleBufferGetImageBuffer(sb) else { continue }
    let t = CMSampleBufferGetPresentationTimeStamp(sb).seconds
    CVPixelBufferLockBaseAddress(pb, .readOnly)
    let base = CVPixelBufferGetBaseAddressOfPlane(pb, 0)!.assumingMemoryBound(to: UInt8.self)
    let w = CVPixelBufferGetWidthOfPlane(pb, 0), h = CVPixelBufferGetHeightOfPlane(pb, 0), bpr = CVPixelBufferGetBytesPerRowOfPlane(pb, 0)
    var g = [Double](repeating: 0, count: GW * GH)
    for gy in 0..<GH { for gx in 0..<GW {
        var s = 0; let x0 = gx * w / GW, y0 = gy * h / GH
        for dy in stride(from: 0, to: h / GH, by: 4) { for dx in stride(from: 0, to: w / GW, by: 4) { s += Int(base[(y0 + dy) * bpr + x0 + dx]) } }
        g[gy * GW + gx] = Double(s)
    } }
    CVPixelBufferUnlockBaseAddress(pb, .readOnly)
    let m = g.reduce(0, +) / Double(g.count); g = g.map { $0 / max(m, 1) }        // brightness-normalised
    if let p = prev { times.append(t); diffs.append(zip(g, p).map { abs($0 - $1) }.reduce(0, +) / Double(g.count)) }
    prev = g
}
for i in 0..<diffs.count {
    let lo = max(0, i - 15), hi = min(diffs.count, i + 16)
    var win = Array(diffs[lo..<hi]); win.remove(at: i - lo); win.sort()
    let med = win[win.count / 2]
    if diffs[i] > 0.12 && diffs[i] > k * max(med, 0.02) { print(String(format: "%.3f", times[i])) }
}
