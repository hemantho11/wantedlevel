import AVFoundation
import CoreText
import ImageIO
import UniformTypeIdentifiers
let src = URL(fileURLWithPath: CommandLine.arguments[1])
let outDir = CommandLine.arguments[2]
let step = Double(CommandLine.arguments[3])!
let asset = AVURLAsset(url: src)
let gen = AVAssetImageGenerator(asset: asset)
gen.maximumSize = CGSize(width: 480, height: 270)
gen.requestedTimeToleranceBefore = CMTime(seconds: 1, preferredTimescale: 600)
gen.requestedTimeToleranceAfter = CMTime(seconds: 1, preferredTimescale: 600)
let dur = asset.duration.seconds
let cols = 4, rows = 5, w = 480, h = 270
var times: [Double] = []; var t = 2.0; while t < dur { times.append(t); t += step }
let perSheet = cols*rows
for sheet in 0..<Int(ceil(Double(times.count)/Double(perSheet))) {
  let ctx = CGContext(data: nil, width: cols*w, height: rows*h, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
  ctx.setFillColor(CGColor(red:0,green:0,blue:0,alpha:1)); ctx.fill(CGRect(x:0,y:0,width:cols*w,height:rows*h))
  for i in 0..<perSheet {
    let idx = sheet*perSheet+i; if idx >= times.count { break }
    let tm = times[idx]
    guard let img = try? gen.copyCGImage(at: CMTime(seconds: tm, preferredTimescale: 600), actualTime: nil) else { continue }
    let x = (i % cols)*w, y = (rows-1-(i / cols))*h
    ctx.draw(img, in: CGRect(x: x, y: y, width: w, height: h))
    let label = String(format: "%02d:%02d", Int(tm)/60, Int(tm)%60)
    ctx.setFillColor(CGColor(red:0,green:0,blue:0,alpha:0.75)); ctx.fill(CGRect(x: x, y: y+h-34, width: 90, height: 34))
    let font = CTFontCreateWithName("Helvetica-Bold" as CFString, 24, nil)
    let attr = NSAttributedString(string: label, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font, NSAttributedString.Key(kCTForegroundColorAttributeName as String): CGColor(red:1,green:1,blue:0,alpha:1)])
    let line = CTLineCreateWithAttributedString(attr)
    ctx.textPosition = CGPoint(x: x+8, y: y+h-26); CTLineDraw(line, ctx)
  }
  let url = URL(fileURLWithPath: String(format: "%@/sheet_%02d.jpg", outDir, sheet))
  let d = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil)!
  CGImageDestinationAddImage(d, ctx.makeImage()!, [kCGImageDestinationLossyCompressionQuality: 0.7] as CFDictionary)
  CGImageDestinationFinalize(d)
}
print("frames", times.count)
