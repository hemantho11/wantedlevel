import AVFoundation
import CoreText
import ImageIO
import UniformTypeIdentifiers
// usage: fine <video> <outPrefix> <start> <end> <step>
let a = CommandLine.arguments
let asset = AVURLAsset(url: URL(fileURLWithPath: a[1]))
let prefix = a[2]; let st = Double(a[3])!, en = Double(a[4])!, step = Double(a[5])!
let gen = AVAssetImageGenerator(asset: asset)
gen.maximumSize = CGSize(width: 320, height: 180)
gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero
let cols = 6, rows = 5, w = 320, h = 180
var times: [Double] = []; var t = st; while t <= en { times.append(t); t += step }
let per = cols*rows
for sheet in 0..<Int(ceil(Double(times.count)/Double(per))) {
  let ctx = CGContext(data: nil, width: cols*w, height: rows*h, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
  ctx.setFillColor(CGColor(red:0,green:0,blue:0,alpha:1)); ctx.fill(CGRect(x:0,y:0,width:cols*w,height:rows*h))
  for i in 0..<per {
    let idx = sheet*per+i; if idx >= times.count { break }
    let tm = times[idx]
    guard let img = try? gen.copyCGImage(at: CMTime(seconds: tm, preferredTimescale: 600), actualTime: nil) else { continue }
    let x = (i % cols)*w, y = (rows-1-(i / cols))*h
    ctx.draw(img, in: CGRect(x: x, y: y, width: w, height: h))
    let label = String(format: "%d:%02d", Int(tm)/60, Int(tm)%60)
    ctx.setFillColor(CGColor(red:0,green:0,blue:0,alpha:0.75)); ctx.fill(CGRect(x: x, y: y+h-24, width: 58, height: 24))
    let font = CTFontCreateWithName("Helvetica-Bold" as CFString, 18, nil)
    let attr = NSAttributedString(string: label, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font, NSAttributedString.Key(kCTForegroundColorAttributeName as String): CGColor(red:1,green:1,blue:0,alpha:1)])
    ctx.textPosition = CGPoint(x: x+5, y: y+h-18); CTLineDraw(CTLineCreateWithAttributedString(attr), ctx)
  }
  let url = URL(fileURLWithPath: String(format: "%@_%d.jpg", prefix, sheet))
  let d = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil)!
  CGImageDestinationAddImage(d, ctx.makeImage()!, [kCGImageDestinationLossyCompressionQuality: 0.75] as CFDictionary)
  CGImageDestinationFinalize(d)
}
