import CoreGraphics
import ImageIO
import UniformTypeIdentifiers
// keybg <in.jpg> <out.png>: flood-fills the neutral checkerboard background from the image border and makes it transparent
let a = CommandLine.arguments
let src = CGImageSourceCreateWithURL(URL(fileURLWithPath: a[1]) as CFURL, nil)!
let img = CGImageSourceCreateImageAtIndex(src, 0, nil)!
let w = img.width, h = img.height
let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
ctx.draw(img, in: CGRect(x: 0, y: 0, width: w, height: h))
let p = ctx.data!.assumingMemoryBound(to: UInt8.self)
func isBG(_ i: Int) -> Bool {
  let r = Int(p[i*4]), g = Int(p[i*4+1]), b = Int(p[i*4+2])
  let mx = max(r, g, b), mn = min(r, g, b)
  return mx - mn < 22 && mn > 150          // neutral grey/white checker squares
}
var mask = [Bool](repeating: false, count: w * h)
var stack: [Int] = []
for x in 0..<w { stack.append(x); stack.append((h-1)*w + x) }
for y in 0..<h { stack.append(y*w); stack.append(y*w + w-1) }
while let i = stack.popLast() {
  if mask[i] || !isBG(i) { continue }
  mask[i] = true
  let x = i % w, y = i / w
  if x > 0 { stack.append(i-1) }; if x < w-1 { stack.append(i+1) }
  if y > 0 { stack.append(i-w) }; if y < h-1 { stack.append(i+w) }
}
// soften the edge: pixels next to the keyed area get partial alpha
for i in 0..<(w*h) {
  if mask[i] { p[i*4] = 0; p[i*4+1] = 0; p[i*4+2] = 0; p[i*4+3] = 0; continue }
  let x = i % w, y = i / w
  var n = 0
  for dy in -1...1 { for dx in -1...1 { let xx = x+dx, yy = y+dy; if xx >= 0, yy >= 0, xx < w, yy < h, mask[yy*w+xx] { n += 1 } } }
  if n > 0 { let al = UInt8(255 - min(200, n * 45)); for c in 0..<3 { p[i*4+c] = UInt8(Int(p[i*4+c]) * Int(al) / 255) }; p[i*4+3] = al }
}
let out = ctx.makeImage()!
let d = CGImageDestinationCreateWithURL(URL(fileURLWithPath: a[2]) as CFURL, UTType.png.identifier as CFString, 1, nil)!
CGImageDestinationAddImage(d, out, nil); CGImageDestinationFinalize(d)
print("keyed", mask.filter { $0 }.count, "of", w*h, "pixels; size", w, h)
