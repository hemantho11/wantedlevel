import AVFoundation
// prints overall RMS (dBFS) and peak for a file, mono-mixed
let f = try AVAudioFile(forReading: URL(fileURLWithPath: CommandLine.arguments[1]))
let buf = AVAudioPCMBuffer(pcmFormat: f.processingFormat, frameCapacity: AVAudioFrameCount(f.length))!
try f.read(into: buf)
let n = Int(buf.frameLength), ch = Int(f.processingFormat.channelCount)
var sum: Double = 0, peak: Float = 0, loud: [Float] = []
let win = Int(f.processingFormat.sampleRate * 0.4)
var i = 0
while i < n {
  var s: Float = 0; let e = min(n, i + win)
  for j in i..<e { var v: Float = 0; for c in 0..<ch { v += buf.floatChannelData![c][j] }; v /= Float(ch); s += v*v; peak = max(peak, abs(v)) }
  loud.append(sqrt(s / Float(e - i))); i += win
}
let sorted = loud.sorted()
let p90 = sorted[Int(Double(sorted.count) * 0.9)]
print(String(format: "rms90 %.1f dBFS  peak %.1f dBFS", 20*log10(p90), 20*log10(peak)))
