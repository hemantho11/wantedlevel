import AVFoundation
import CoreImage
import CoreImage.CIFilterBuiltins
import CoreText
import ImageIO
import UniformTypeIdentifiers

// usage: editor <source.mp4> <edit.json> [--frames t1 t2 ...]
// Renders a 1080x1920 Short from an edit list: shots (crop / fit / callout, animated zoom, slow-mo),
// game audio ducked under the voiceover, burned-in captions.

struct R: Codable { var x: Double; var y: Double; var w: Double; var h: Double }
struct Shot: Codable {
    var src: [Double]; var out: [Double]
    var mode: String?          // crop (default) | fit | callout
    var from: R?; var to: R?   // crop rect animation (top-left coords in 1920x1080)
    var region: R?             // callout inset region
    var captionTop: Bool?
    var captionY: Double?      // caption centre (top-left px) override for this shot
}
struct Cap: Codable { var t: [Double]; var chunks: [String] }
struct Edit: Codable {
    var vo: String; var out: String; var shots: [Shot]; var captions: [Cap]
    var gameVol: Double?            // unused now: game audio is dropped, kept for old edit lists
    var hook: String?; var music: String?
    var hookVol: Double?; var musicVol: Double?
}
let LOGO_PATH = "/Users/hemanthkumaro11/Youtube/shorts-pipeline/assets/channel_logo.png"
let GTA_LOGO_PATH = "/Users/hemanthkumaro11/Youtube/shorts-pipeline/assets/gta6_logo.png"
let HOOK_DEFAULT = "/Users/hemanthkumaro11/Youtube/Hook.mp3"
let MUSIC_DEFAULT = "/Users/hemanthkumaro11/Youtube/BG Music (Loop).mp3"

let W: CGFloat = 1080, H: CGFloat = 1920, SW: CGFloat = 1920, SH: CGFloat = 1080
let FULL = R(x: 0, y: 0, w: 1920, h: 1080)

func ciRect(_ r: R) -> CGRect { CGRect(x: r.x, y: SH - r.y - r.h, width: r.w, height: r.h) }
func lerp(_ a: CGRect, _ b: CGRect, _ p: CGFloat) -> CGRect {
    CGRect(x: a.minX + (b.minX - a.minX) * p, y: a.minY + (b.minY - a.minY) * p,
           width: a.width + (b.width - a.width) * p, height: a.height + (b.height - a.height) * p)
}
func ease(_ p: CGFloat) -> CGFloat { p < 0.5 ? 2 * p * p : 1 - pow(-2 * p + 2, 2) / 2 }
func wait<T>(_ op: @escaping () async throws -> T) -> T {
    var r: T!; let s = DispatchSemaphore(value: 0)
    Task { r = try! await op(); s.signal() }; s.wait(); return r
}

// MARK: captions
struct CapItem { var start: Double; var end: Double; var img: CIImage }
var CAPS: [CapItem] = []

func renderCaption(_ text: String) -> CIImage {
    let font = CTFontCreateWithName("Arial-Black" as CFString, 104, nil)
    let yellow = CGColor(red: 0.45, green: 0.93, blue: 0.12, alpha: 1)   // reference style: bright green highlight
    let white = CGColor(red: 1, green: 1, blue: 1, alpha: 1)
    let black = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
    // words wrapped in *...* are highlighted yellow
    struct Word { var s: String; var hi: Bool }
    let words = text.split(separator: " ").map { w -> Word in
        // any asterisk in the word marks it highlighted (handles *WORD*, *WORD*. and "*WORD*")
        let hi = w.contains("*")
        let s = w.filter { !"*\"“”".contains($0) }    // markers and quote marks never show on screen
        return Word(s: s.uppercased(), hi: hi)
    }
    func attr(_ ws: [Word], stroke: Bool) -> NSAttributedString {
        let m = NSMutableAttributedString()
        for (i, w) in ws.enumerated() {
            var a: [NSAttributedString.Key: Any] = [.init(kCTFontAttributeName as String): font]
            if stroke {
                a[.init(kCTStrokeWidthAttributeName as String)] = 14.0
                a[.init(kCTStrokeColorAttributeName as String)] = black
                a[.init(kCTForegroundColorAttributeName as String)] = black
            } else {
                a[.init(kCTForegroundColorAttributeName as String)] = w.hi ? yellow : white
            }
            m.append(NSAttributedString(string: (i > 0 ? " " : "") + w.s, attributes: a))
        }
        return m
    }
    // one word per line (reference style stacks words); a line wider than the frame gets a smaller font via scaling below
    var lines: [[Word]] = words.map { [$0] }
    if lines.isEmpty { lines = [[]] }
    let lineH: CGFloat = 118
    let imgH = Int(lineH * CGFloat(lines.count) + 70)
    let ctx = CGContext(data: nil, width: Int(W), height: imgH, bitsPerComponent: 8, bytesPerRow: 0,
                        space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
    ctx.setAllowsAntialiasing(true); ctx.setShouldSmoothFonts(true)
    for pass in 0..<2 {
        for (i, ws) in lines.enumerated() {
            let line = CTLineCreateWithAttributedString(attr(ws, stroke: pass == 0))
            let width = CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))
            let fit = min(1, 980 / max(width, 1))          // squeeze long words to the frame
            let y = CGFloat(imgH) - 35 - lineH * CGFloat(i) - 88
            ctx.saveGState()
            if pass == 1 { ctx.setShadow(offset: CGSize(width: 0, height: -6), blur: 14, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.85)) }
            ctx.setLineJoin(.round)
            ctx.translateBy(x: (W - width * fit) / 2, y: y); ctx.scaleBy(x: fit, y: 1)
            ctx.textPosition = .zero
            CTLineDraw(line, ctx)
            ctx.restoreGState()
        }
    }
    return CIImage(cgImage: ctx.makeImage()!)
}

// original "GTA 6" badge that slides up whenever the script says GTA 6
func renderBadge() -> CIImage {
    let w = 700, h = 230
    let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                        space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
    ctx.setAllowsAntialiasing(true)
    let font = CTFontCreateWithName("Arial-Black" as CFString, 150, nil)
    let pink = CGColor(red: 1, green: 0.25, blue: 0.62, alpha: 1), gold = CGColor(red: 1, green: 0.83, blue: 0.2, alpha: 1)
    let black = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
    func str(_ stroke: Bool) -> NSAttributedString {
        let m = NSMutableAttributedString()
        for (s, c) in [("GTA", gold), ("6", pink)] {
            var a: [NSAttributedString.Key: Any] = [.init(kCTFontAttributeName as String): font]
            if stroke { a[.init(kCTStrokeWidthAttributeName as String)] = 10.0; a[.init(kCTStrokeColorAttributeName as String)] = black; a[.init(kCTForegroundColorAttributeName as String)] = black }
            else { a[.init(kCTForegroundColorAttributeName as String)] = c }
            m.append(NSAttributedString(string: (m.length > 0 ? " " : "") + s, attributes: a))
        }
        return m
    }
    for pass in 0..<2 {
        let line = CTLineCreateWithAttributedString(str(pass == 0))
        let width = CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))
        ctx.saveGState()
        if pass == 1 { ctx.setShadow(offset: CGSize(width: 0, height: -8), blur: 18, color: CGColor(red: 0, green: 0, blue: 0, alpha: 0.9)) }
        ctx.setLineJoin(.round)
        ctx.textPosition = CGPoint(x: (CGFloat(w) - width) / 2, y: 50)
        CTLineDraw(line, ctx); ctx.restoreGState()
    }
    return CIImage(cgImage: ctx.makeImage()!)
}
// the user's own logo file (background keyed out) takes the badge slot when present; the drawn text badge is the fallback
let BADGE: CIImage = {
    if let src = CIImage(contentsOf: URL(fileURLWithPath: GTA_LOGO_PATH)) {
        let s = 640 / src.extent.width
        let img = src.transformed(by: CGAffineTransform(scaleX: s, y: s))
        // soft drop shadow so it reads on bright frames
        let shadow = CIFilter.colorMatrix(); shadow.inputImage = img
        shadow.rVector = .init(x: 0, y: 0, z: 0, w: 0); shadow.gVector = .init(x: 0, y: 0, z: 0, w: 0); shadow.bVector = .init(x: 0, y: 0, z: 0, w: 0)
        shadow.aVector = .init(x: 0, y: 0, z: 0, w: 0.75)
        let sh = shadow.outputImage!.clampedToExtent().applyingGaussianBlur(sigma: 10).cropped(to: img.extent.insetBy(dx: -40, dy: -40))
            .transformed(by: CGAffineTransform(translationX: 0, y: -8))
        return img.composited(over: sh)
    }
    return renderBadge()
}()
var BADGE_TIMES: [Double] = []
let LOGO: CIImage? = {
    guard let src = CIImage(contentsOf: URL(fileURLWithPath: LOGO_PATH)) else { return nil }
    let s = 210 / src.extent.width
    let img = src.transformed(by: CGAffineTransform(scaleX: s, y: s))
    let f = CIFilter.colorMatrix(); f.inputImage = img; f.aVector = CIVector(x: 0, y: 0, z: 0, w: 0.65)
    return f.outputImage!.transformed(by: CGAffineTransform(translationX: 40 - img.extent.minX, y: H - 40 - img.extent.height - img.extent.minY))
}()

// MARK: word alignment against the voiceover envelope
func envelope(_ url: URL) -> ([Float], Double) {
    let f = try! AVAudioFile(forReading: url)
    let buf = AVAudioPCMBuffer(pcmFormat: f.processingFormat, frameCapacity: AVAudioFrameCount(f.length))!
    try! f.read(into: buf)
    let n = Int(buf.frameLength), d = buf.floatChannelData![0], win = Int(f.processingFormat.sampleRate * 0.01)
    var env: [Float] = []; var i = 0
    while i < n { var s: Float = 0; let e = min(n, i + win); for j in i..<e { s += d[j] * d[j] }; env.append(sqrt(s / Float(e - i))); i += win }
    // light smoothing
    var sm = env
    for k in 2..<max(2, env.count - 2) { sm[k] = (env[k-2] + env[k-1] + env[k] + env[k+1] + env[k+2]) / 5 }
    return (sm, 0.01)
}
func syllables(_ w: String) -> Double {
    let s = w.lowercased().filter { $0.isLetter || $0.isNumber }
    if s.isEmpty { return 1 }
    if s.allSatisfy({ $0.isNumber }) { return Double(max(1, s.count)) }   // "2026" ~ 4 beats
    var c = 0; var prevV = false
    for ch in s { let v = "aeiouy".contains(ch); if v && !prevV { c += 1 }; prevV = v }
    if s.hasSuffix("e") && c > 1 { c -= 1 }
    return Double(max(1, c))
}
// split [t0,t1] into one span per word: expected positions from syllable share, snapped to the nearest envelope dip
func alignWords(_ words: [String], _ t0: Double, _ t1: Double, env: [Float], dt: Double) -> [(Double, Double)] {
    let n = words.count
    guard n > 1 else { return [(t0, t1)] }
    // trim leading / trailing silence inside the range
    let thr = (env.max() ?? 1) * 0.06
    var a = Int(t0 / dt), b = min(env.count - 1, Int(t1 / dt))
    while a < b && env[a] < thr { a += 1 }
    while b > a && env[b] < thr { b -= 1 }
    let start = Double(a) * dt, end = Double(b + 1) * dt
    let syl = words.map(syllables)
    let total = syl.reduce(0, +)
    var bounds: [Double] = [start]
    var acc = 0.0
    for i in 0..<(n - 1) {
        acc += syl[i]
        let expected = start + (end - start) * acc / total
        let slack = (end - start) / total * min(syl[i], syl[i + 1]) * 0.45
        var lo = Int((expected - slack) / dt), hi = Int((expected + slack) / dt)
        lo = max(lo, Int(bounds.last! / dt) + 3); hi = min(hi, b - 3)
        var best = Int(expected / dt), bestV = Float.greatestFiniteMagnitude
        if lo <= hi { for k in lo...hi { let v = env[k] * (1 + 0.6 * Float(abs(Double(k) * dt - expected) / max(slack, 0.01))); if v < bestV { bestV = v; best = k } } }
        // never let a word collapse below half its expected length (or 120 ms)
        let minLen = max(0.12, (end - start) / total * syl[i] * 0.5)
        var bnd = Double(best) * dt
        if bnd - bounds.last! < minLen { bnd = min(expected, bounds.last! + minLen) }
        bounds.append(bnd)
    }
    bounds.append(end)
    return (0..<n).map { (bounds[$0], bounds[$0 + 1]) }
}

// MARK: compositor
final class ShotInst: NSObject, AVVideoCompositionInstructionProtocol {
    let timeRange: CMTimeRange
    let enablePostProcessing = false
    let containsTweening = true
    let requiredSourceTrackIDs: [NSValue]?
    let passthroughTrackID: CMPersistentTrackID = kCMPersistentTrackID_Invalid
    let shot: Shot; let index: Int
    init(range: CMTimeRange, trackID: CMPersistentTrackID, shot: Shot, index: Int) {
        timeRange = range; requiredSourceTrackIDs = [NSNumber(value: trackID)]; self.shot = shot; self.index = index
    }
}

final class Comp: NSObject, AVVideoCompositing {
    let ctx = CIContext(options: [.cacheIntermediates: false])
    var overlays: [Int: CIImage] = [:]
    var sourcePixelBufferAttributes: [String: Any]? { [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA] }
    var requiredPixelBufferAttributesForRenderContext: [String: Any] { [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA] }
    func renderContextChanged(_ c: AVVideoCompositionRenderContext) {}
    func cancelAllPendingVideoCompositionRequests() {}

    func startRequest(_ req: AVAsynchronousVideoCompositionRequest) {
        guard let inst = req.videoCompositionInstruction as? ShotInst,
              let tid = inst.requiredSourceTrackIDs?.first as? NSNumber,
              let pb = req.sourceFrame(byTrackID: CMPersistentTrackID(tid.int32Value)),
              let outPB = req.renderContext.newPixelBuffer() else {
            req.finish(with: NSError(domain: "comp", code: 1)); return
        }
        let t = req.compositionTime.seconds
        let img = render(CIImage(cvPixelBuffer: pb), inst, t)
        ctx.render(img, to: outPB, bounds: CGRect(x: 0, y: 0, width: W, height: H), colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
        req.finish(withComposedVideoFrame: outPB)
    }

    func bg(_ src: CIImage) -> CIImage {
        let s = H / SH * 0.25
        var b = src.transformed(by: CGAffineTransform(scaleX: s, y: s))
        b = b.clampedToExtent().applyingGaussianBlur(sigma: 12).cropped(to: b.extent)
        b = b.transformed(by: CGAffineTransform(scaleX: 4, y: 4))
        let dx = (b.extent.width - W) / 2
        b = b.transformed(by: CGAffineTransform(translationX: -b.extent.minX - dx, y: -b.extent.minY))
        let f = CIFilter.colorControls(); f.inputImage = b; f.brightness = -0.22; f.saturation = 1.15
        return f.outputImage!.cropped(to: CGRect(x: 0, y: 0, width: W, height: H))
    }
    func place(_ src: CIImage, region: CGRect, width: CGFloat, centerY: CGFloat) -> (CIImage, CGRect) {
        let s = width / region.width
        let img = src.cropped(to: region).transformed(by: CGAffineTransform(scaleX: s, y: s))
        let dest = CGRect(x: (W - width) / 2, y: centerY - region.height * s / 2, width: width, height: region.height * s)
        return (img.transformed(by: CGAffineTransform(translationX: dest.minX - img.extent.minX, y: dest.minY - img.extent.minY)), dest)
    }
    func overlay(for inst: ShotInst, mainRect: CGRect, insetRect: CGRect, region: CGRect) -> CIImage {
        if let o = overlays[inst.index] { return o }
        let c = CGContext(data: nil, width: Int(W), height: Int(H), bitsPerComponent: 8, bytesPerRow: 0,
                          space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        c.setStrokeColor(CGColor(red: 1, green: 0.87, blue: 0.1, alpha: 1))
        c.setLineWidth(8); c.stroke(insetRect.insetBy(dx: -4, dy: -4))
        let s = mainRect.width / SW
        let hi = CGRect(x: mainRect.minX + region.minX * s, y: mainRect.minY + region.minY * s, width: region.width * s, height: region.height * s)
        c.setLineWidth(5); c.stroke(hi.insetBy(dx: -6, dy: -6))
        // connector line from highlight to inset
        c.setLineWidth(4); c.setLineDash(phase: 0, lengths: [14, 10])
        c.move(to: CGPoint(x: hi.midX, y: hi.minY - 6)); c.addLine(to: CGPoint(x: insetRect.midX, y: insetRect.maxY + 4)); c.strokePath()
        let o = CIImage(cgImage: c.makeImage()!); overlays[inst.index] = o; return o
    }

    func render(_ src: CIImage, _ inst: ShotInst, _ t: Double) -> CIImage {
        let shot = inst.shot
        let p = ease(CGFloat(max(0, min(1, (t - inst.timeRange.start.seconds) / max(0.001, inst.timeRange.duration.seconds)))))
        var out: CIImage
        var capCenterTL: CGFloat = 900           // reference style: word sits around mid-screen
        switch shot.mode ?? "crop" {
        case "fit":
            let (img, _) = place(src, region: ciRect(FULL), width: W, centerY: H / 2)
            out = img.composited(over: bg(src)); capCenterTL = 1380
        case "callout":
            let reg = ciRect(shot.region ?? FULL)
            let mainTop: CGFloat = 400
            let (main, mainRect) = place(src, region: ciRect(FULL), width: W, centerY: H - mainTop - SH * (W / SW) / 2)
            let insetW: CGFloat = 900
            let insetH = reg.height * insetW / reg.width
            let insetTopTL: CGFloat = mainTop + SH * (W / SW) + 56
            let (inset, insetRect) = place(src, region: reg, width: insetW, centerY: H - insetTopTL - insetH / 2)
            out = inset.composited(over: main.composited(over: bg(src)))
            out = overlay(for: inst, mainRect: mainRect, insetRect: insetRect, region: reg).composited(over: out)
            capCenterTL = 230
        default:
            let a = ciRect(shot.from ?? shot.to ?? FULL), b = ciRect(shot.to ?? shot.from ?? FULL)
            let r = lerp(a, b, p)
            let s = min(W / r.width, H / r.height)
            let (img, dest) = place(src, region: r, width: r.width * s, centerY: H / 2)
            out = (dest.width >= W - 2 && dest.height >= H - 2) ? img : img.composited(over: bg(src))
            if shot.captionTop == true { capCenterTL = 380 }
        }
        out = out.cropped(to: CGRect(x: 0, y: 0, width: W, height: H))
        if let cy = shot.captionY { capCenterTL = CGFloat(cy) }
        if let cap = CAPS.first(where: { t >= $0.start && t < $0.end }) {
            let pop = 0.86 + 0.14 * ease(CGFloat(min(1, (t - cap.start) / 0.1)))
            let e = cap.img.extent
            var c = cap.img.transformed(by: CGAffineTransform(translationX: -e.midX, y: -e.midY))
            c = c.transformed(by: CGAffineTransform(scaleX: pop, y: pop))
            c = c.transformed(by: CGAffineTransform(translationX: W / 2, y: H - capCenterTL))
            out = c.composited(over: out)
        }
        // GTA 6 badge: slides up from below its resting spot, holds, then drops away
        if let bt = BADGE_TIMES.first(where: { t >= $0 && t < $0 + 1.4 }) {
            let u = t - bt
            let inP = ease(CGFloat(min(1, u / 0.28))), outP = u > 1.15 ? ease(CGFloat((u - 1.15) / 0.25)) : 0
            let restTL: CGFloat = 560
            let y = H - restTL + (1 - inP) * -140 + outP * 60
            let alpha = Float(inP) * Float(1 - outP)
            let f = CIFilter.colorMatrix(); f.inputImage = BADGE; f.aVector = CIVector(x: 0, y: 0, z: 0, w: CGFloat(alpha))
            let e = BADGE.extent
            let b = f.outputImage!.transformed(by: CGAffineTransform(translationX: W / 2 - e.midX, y: y - e.midY))
            out = b.composited(over: out)
        }
        if let logo = LOGO { out = logo.composited(over: out) }
        return out
    }
}

// MARK: build
let args = CommandLine.arguments
let srcURL = URL(fileURLWithPath: args[1])
let edit = try JSONDecoder().decode(Edit.self, from: Data(contentsOf: URL(fileURLWithPath: args[2])))
let editDir = URL(fileURLWithPath: args[2]).deletingLastPathComponent()
let voURL = URL(fileURLWithPath: edit.vo, relativeTo: editDir)
// --nocaps: same edit, no word captions, written to a "no-subtitles" folder beside the originals
let NOCAPS = CommandLine.arguments.contains("--nocaps")
var outURL = URL(fileURLWithPath: edit.out, relativeTo: editDir)
if NOCAPS {
    let dir = outURL.deletingLastPathComponent().appendingPathComponent("no-subtitles")
    try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    outURL = dir.appendingPathComponent(outURL.lastPathComponent)
}

let hookURL = URL(fileURLWithPath: edit.hook ?? HOOK_DEFAULT)
let musicURL = URL(fileURLWithPath: edit.music ?? MUSIC_DEFAULT)
let srcAsset = AVURLAsset(url: srcURL), voAsset = AVURLAsset(url: voURL)
let hookAsset = AVURLAsset(url: hookURL), musicAsset = AVURLAsset(url: musicURL)
let (srcV, voA, voDur) = wait { () -> (AVAssetTrack, AVAssetTrack, Double) in
    (try await srcAsset.loadTracks(withMediaType: .video).first!,
     try await voAsset.loadTracks(withMediaType: .audio).first!, try await voAsset.load(.duration).seconds)
}
let (hookA, hookDur, musicA, musicDur) = wait { () -> (AVAssetTrack, Double, AVAssetTrack, Double) in
    (try await hookAsset.loadTracks(withMediaType: .audio).first!, try await hookAsset.load(.duration).seconds,
     try await musicAsset.loadTracks(withMediaType: .audio).first!, try await musicAsset.load(.duration).seconds)
}
var shots = edit.shots
// make sure the video outlasts the voiceover
if let last = shots.last, last.out[1] < voDur + 0.3 {
    let d = voDur + 0.3 - last.out[1]; let speed = (last.src[1] - last.src[0]) / (last.out[1] - last.out[0])
    shots[shots.count - 1].out[1] += d; shots[shots.count - 1].src[1] += d * speed
}

let comp = AVMutableComposition()
let vTrack = comp.addMutableTrack(withMediaType: .video, preferredTrackID: 1)!
let voTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 3)!
let hookTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 4)!
let musicTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: 5)!
var cursor = CMTime.zero
var insts: [ShotInst] = []
func T(_ s: Double) -> CMTime { CMTime(seconds: s, preferredTimescale: 600) }
for (i, sh) in shots.enumerated() {
    let srcRange = CMTimeRange(start: T(sh.src[0]), end: T(sh.src[1]))
    let outDur = T(sh.out[1] - sh.out[0])
    try vTrack.insertTimeRange(srcRange, of: srcV, at: cursor)
    if srcRange.duration != outDur {
        vTrack.scaleTimeRange(CMTimeRange(start: cursor, duration: srcRange.duration), toDuration: outDur)
    }
    insts.append(ShotInst(range: CMTimeRange(start: cursor, duration: outDur), trackID: vTrack.trackID, shot: sh, index: i))
    cursor = cursor + outDur
}
try voTrack.insertTimeRange(CMTimeRange(start: .zero, duration: T(voDur)), of: voA, at: .zero)

// music bed: hook at the start, loop takes over as the hook fades, loop repeats if the video outlasts it
let total = cursor.seconds
let hookLen = min(hookDur, total)
try hookTrack.insertTimeRange(CMTimeRange(start: .zero, duration: T(hookLen)), of: hookA, at: .zero)
let musicStart = max(0, hookLen - 1.0)
var mCursor = musicStart
while mCursor < total {
    let len = min(musicDur, total - mCursor)
    try musicTrack.insertTimeRange(CMTimeRange(start: .zero, duration: T(len)), of: musicA, at: T(mCursor))
    mCursor += len
}

// captions: one word at a time, each word aligned to the voiceover; short words ride with the next word
let (ENV, ENV_DT) = envelope(voURL)
for c in edit.captions {
    var words: [String] = [], lastInChunk: [Bool] = []
    for ch in c.chunks {
        let ws = ch.split(separator: " ").map(String.init).filter { !$0.isEmpty }
        for (k, w) in ws.enumerated() { words.append(w); lastInChunk.append(k == ws.count - 1) }
    }
    let spans = alignWords(words, c.t[0], c.t[1], env: ENV, dt: ENV_DT)
    var i = 0
    while i < words.count {
        var group = [words[i]]; var end = spans[i].1; let start = spans[i].0
        let bare = words[i].filter { $0.isLetter || $0.isNumber }
        // "GTA 6" stays together and triggers the badge; tiny words stack with what follows
        var badge = false
        let nxt = i + 1 < words.count ? words[i + 1].filter { $0.isLetter || $0.isNumber }.lowercased() : ""
        // a short word never rides into the next sentence / script line
        let endsClause = lastInChunk[i] || (words[i].replacingOccurrences(of: "*", with: "").last.map { ".?!,:;".contains($0) } ?? false)
        if bare.lowercased() == "gta", ["5", "6", "v", "vi", "six", "five"].contains(nxt) {
            // keep "GTA 6" / "GTA 5" together; only the real GTA 6 gets the logo
            group.append(words[i + 1]); end = spans[i + 1].1; i += 1
            if ["6", "vi", "six"].contains(nxt) { BADGE_TIMES.append(start); badge = true }
        }
        else if bare.count <= 3, !endsClause, i + 1 < words.count, words[i + 1].filter({ $0.isLetter }).count > 3 { group.append(words[i + 1]); end = spans[i + 1].1; i += 1 }
        // the badge stands in for the caption while "GTA 6" is spoken
        if !badge && !NOCAPS { CAPS.append(CapItem(start: start, end: end, img: renderCaption(group.joined(separator: " ")))) }
        if args.contains("--frames") { print(String(format: "cap %5.2f-%5.2f  %@", start, end, group.joined(separator: " "))) }
        i += 1
    }
}

let vc = AVMutableVideoComposition()
vc.customVideoCompositorClass = Comp.self
vc.frameDuration = CMTime(value: 1, timescale: 30)
vc.renderSize = CGSize(width: W, height: H)
vc.instructions = insts

let mix = AVMutableAudioMix()
let hookVol = Float(edit.hookVol ?? 0.28), musicVol = Float(edit.musicVol ?? 0.09)
let vp = AVMutableAudioMixInputParameters(track: voTrack); vp.setVolume(1.0, at: .zero)
let hp = AVMutableAudioMixInputParameters(track: hookTrack)
hp.setVolume(hookVol, at: .zero)
hp.setVolumeRamp(fromStartVolume: hookVol, toEndVolume: 0, timeRange: CMTimeRange(start: T(max(0, hookLen - 1.0)), end: T(hookLen)))
let mp = AVMutableAudioMixInputParameters(track: musicTrack)
mp.setVolume(0, at: .zero)
mp.setVolumeRamp(fromStartVolume: 0, toEndVolume: musicVol, timeRange: CMTimeRange(start: T(musicStart), end: T(musicStart + 1.0)))
mp.setVolumeRamp(fromStartVolume: musicVol, toEndVolume: 0, timeRange: CMTimeRange(start: T(max(musicStart + 1.0, total - 1.2)), end: T(total)))
mix.inputParameters = [vp, hp, mp]

// debug: dump rendered frames
if args.count > 3, args[3] == "--frames" {
    let gen = AVAssetImageGenerator(asset: comp); gen.videoComposition = vc
    gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero
    for ts in args[4...] {
        let img = try gen.copyCGImage(at: T(Double(ts)!), actualTime: nil)
        let u = outURL.deletingPathExtension().appendingPathExtension("f\(ts).jpg")
        let d = CGImageDestinationCreateWithURL(u as CFURL, UTType.jpeg.identifier as CFString, 1, nil)!
        CGImageDestinationAddImage(d, img, [kCGImageDestinationLossyCompressionQuality: 0.8] as CFDictionary); CGImageDestinationFinalize(d)
    }
    print("frames dumped"); exit(0)
}

// export
try? FileManager.default.removeItem(at: outURL)
let reader = try AVAssetReader(asset: comp)
let vOut = AVAssetReaderVideoCompositionOutput(videoTracks: comp.tracks(withMediaType: .video),
                                               videoSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
vOut.videoComposition = vc; vOut.alwaysCopiesSampleData = false; reader.add(vOut)
let aOut = AVAssetReaderAudioMixOutput(audioTracks: comp.tracks(withMediaType: .audio), audioSettings: [
    AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: 48000, AVNumberOfChannelsKey: 2,
    AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsNonInterleaved: false])
aOut.audioMix = mix; reader.add(aOut)

let writer = try AVAssetWriter(outputURL: outURL, fileType: .mp4)
writer.shouldOptimizeForNetworkUse = true
let vIn = AVAssetWriterInput(mediaType: .video, outputSettings: [
    AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: Int(W), AVVideoHeightKey: Int(H),
    AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: 12_000_000, AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
                                      AVVideoMaxKeyFrameIntervalKey: 60, AVVideoExpectedSourceFrameRateKey: 30]])
let aIn = AVAssetWriterInput(mediaType: .audio, outputSettings: [
    AVFormatIDKey: kAudioFormatMPEG4AAC, AVSampleRateKey: 48000, AVNumberOfChannelsKey: 2, AVEncoderBitRateKey: 192_000])
vIn.expectsMediaDataInRealTime = false; aIn.expectsMediaDataInRealTime = false
writer.add(vIn); writer.add(aIn)
reader.startReading(); writer.startWriting(); writer.startSession(atSourceTime: .zero)
let group = DispatchGroup()
func pump(_ input: AVAssetWriterInput, _ output: AVAssetReaderOutput, _ label: String) {
    group.enter()
    input.requestMediaDataWhenReady(on: DispatchQueue(label: label)) {
        while input.isReadyForMoreMediaData {
            guard let buf = output.copyNextSampleBuffer() else { input.markAsFinished(); group.leave(); return }
            input.append(buf)
        }
    }
}
pump(vIn, vOut, "v"); pump(aIn, aOut, "a"); group.wait()
let done = DispatchSemaphore(value: 0); writer.finishWriting { done.signal() }; done.wait()
print(outURL.lastPathComponent, "status", writer.status.rawValue, writer.error?.localizedDescription ?? "ok", "reader", reader.status.rawValue, reader.error?.localizedDescription ?? "")
