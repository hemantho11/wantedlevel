import AVFoundation
import Accelerate
// usage: prosody <audio>...  -> expressiveness metrics per file
// f0 via normalised autocorrelation (70-400 Hz) on 40 ms frames; stats over voiced frames
func analyse(_ path: String) {
    let f = try! AVAudioFile(forReading: URL(fileURLWithPath: path))
    let fmt = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: f.processingFormat.sampleRate, channels: 1, interleaved: false)!
    let buf = AVAudioPCMBuffer(pcmFormat: f.processingFormat, frameCapacity: AVAudioFrameCount(f.length))!
    try! f.read(into: buf)
    let sr = Float(fmt.sampleRate), n = Int(buf.frameLength), x = Array(UnsafeBufferPointer(start: buf.floatChannelData![0], count: n))
    let win = Int(sr * 0.04), hop = Int(sr * 0.01)
    let minLag = Int(sr / 400), maxLag = Int(sr / 70)
    var f0: [Float] = [], rmsDb: [Float] = [], voicedT: [Float] = []
    var allDb: [Float] = []
    var i = 0
    while i + win + maxLag < n {
        let fr = Array(x[i..<(i + win + maxLag)])
        var e: Float = 0; vDSP_svesq(fr, 1, &e, vDSP_Length(win)); let rms = sqrt(e / Float(win))
        let db = 20 * log10(max(rms, 1e-6)); allDb.append(db)
        if db > -40 {
            var best: Float = 0, bestLag = 0
            for lag in minLag...maxLag {
                var c: Float = 0; vDSP_dotpr(fr, 1, Array(fr[lag...]), 1, &c, vDSP_Length(win))
                var e2: Float = 0; vDSP_svesq(Array(fr[lag...]), 1, &e2, vDSP_Length(win))
                let r = c / sqrt(e * e2 + 1e-9)
                if r > best { best = r; bestLag = lag }
            }
            if best > 0.75 { f0.append(sr / Float(bestLag)); rmsDb.append(db); voicedT.append(Float(i) / sr) }
        }
        i += hop
    }
    func pct(_ a: [Float], _ p: Float) -> Float { let s = a.sorted(); return s[min(s.count - 1, Int(Float(s.count) * p))] }
    // median-filter the track (5 frames) to kill octave jumps
    var f0s = f0
    if f0.count > 5 { for k in 2..<(f0.count - 2) { f0s[k] = Array(f0[(k-2)...(k+2)]).sorted()[2] } }
    let med = pct(f0s, 0.5)
    let st: [Float] = f0s.map { 12 * log2($0 / med) }.filter { abs($0) < 12 }       // semitones re median, octave errors dropped
    let mean = st.reduce(0, +) / Float(st.count)
    let sd = sqrt(st.map { ($0 - mean) * ($0 - mean) }.reduce(0, +) / Float(st.count))
    let range = pct(st, 0.95) - pct(st, 0.05)
    let dyn = pct(rmsDb, 0.9) - pct(rmsDb, 0.1)
    let dur = Float(n) / sr
    let silent = Float(allDb.filter { $0 < -45 }.count) / Float(allDb.count)
    // syllable-ish rate: peaks in smoothed loudness of voiced speech
    var peaks = 0; let sm = allDb
    for k in 2..<(sm.count - 2) where sm[k] > -30 && sm[k] > sm[k-1] && sm[k] >= sm[k+1] && sm[k] > sm[k-2] + 3 { peaks += 1 }
    let floor = pct(allDb, 0.05)
    print(String(format: "floor %5.1f dB  ", floor), terminator: "")
    print(String(format: "%-14@ dur %5.1fs  f0 %4.0fHz  pitchSD %4.2f st  pitchRange90 %4.1f st  loudDyn %4.1f dB  pauses %3.0f%%  syl/s %.1f",
                 (URL(fileURLWithPath: path).lastPathComponent as NSString), dur, med, sd, range, dyn, silent * 100, Float(peaks) / (dur * (1 - silent))))
}
for p in CommandLine.arguments.dropFirst() { analyse(p) }
