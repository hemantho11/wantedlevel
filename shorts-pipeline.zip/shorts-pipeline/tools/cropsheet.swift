import AVFoundation
import CoreText
import ImageIO
import UniformTypeIdentifiers
// cropsheet <video> <out.jpg> <x> <y> <w> <h> <start> <end> <step>   (x,y top-left in 1920x1080)
let a = CommandLine.arguments
let asset = AVURLAsset(url: URL(fileURLWithPath: a[1]))
let cx = Int(a[3])!, cy = Int(a[4])!, cw = Int(a[5])!, ch = Int(a[6])!
let st = Double(a[7])!, en = Double(a[8])!, step = Double(a[9])!
let gen = AVAssetImageGenerator(asset: asset)
gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero
var times: [Double] = []; var t = st; while t <= en + 1e-6 { times.append(t); t += step }
let tw = 480, th = Int(Double(480) * Double(ch) / Double(cw))
let cols = 4, rows = Int(ceil(Double(times.count)/Double(cols)))
let ctx = CGContext(data: nil, width: cols*tw, height: rows*th, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
ctx.setFillColor(CGColor(red:0,green:0,blue:0,alpha:1)); ctx.fill(CGRect(x:0,y:0,width:cols*tw,height:rows*th))
for (i, tm) in times.enumerated() {
  guard let img = try? gen.copyCGImage(at: CMTime(seconds: tm, preferredTimescale: 600), actualTime: nil),
        let c = img.cropping(to: CGRect(x: cx, y: cy, width: cw, height: ch)) else { continue }
  let x = (i % cols)*tw, y = (rows-1-(i / cols))*th
  ctx.draw(c, in: CGRect(x: x, y: y, width: tw, height: th))
  let label = String(format: "%.2f", tm)
  ctx.setFillColor(CGColor(red:0,green:0,blue:0,alpha:0.75)); ctx.fill(CGRect(x: x, y: y+th-24, width: 80, height: 24))
  let font = CTFontCreateWithName("Helvetica-Bold" as CFString, 18, nil)
  let attr = NSAttributedString(string: label, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font, NSAttributedString.Key(kCTForegroundColorAttributeName as String): CGColor(red:1,green:1,blue:0,alpha:1)])
  ctx.textPosition = CGPoint(x: x+5, y: y+th-18); CTLineDraw(CTLineCreateWithAttributedString(attr), ctx)
}
let d = CGImageDestinationCreateWithURL(URL(fileURLWithPath: a[2]) as CFURL, UTType.jpeg.identifier as CFString, 1, nil)!
CGImageDestinationAddImage(d, ctx.makeImage()!, [kCGImageDestinationLossyCompressionQuality: 0.75] as CFDictionary)
CGImageDestinationFinalize(d)
