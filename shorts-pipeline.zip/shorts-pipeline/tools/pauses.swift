import AVFoundation
// prints speech segments (start-end) separated by silences >= minGap
let url = URL(fileURLWithPath: CommandLine.arguments[1])
let minGap = Double(CommandLine.arguments.count > 2 ? CommandLine.arguments[2] : "0.30")!
let f = try AVAudioFile(forReading: url)
let fmt = AVAudioFormat(standardFormatWithSampleRate: f.processingFormat.sampleRate, channels: 1)!
let buf = AVAudioPCMBuffer(pcmFormat: f.processingFormat, frameCapacity: AVAudioFrameCount(f.length))!
try f.read(into: buf)
let sr = f.processingFormat.sampleRate
let data = buf.floatChannelData![0]; let n = Int(buf.frameLength)
let win = Int(sr * 0.02)
var rms: [Float] = []
var i = 0
while i < n { var s: Float = 0; let e = min(n, i+win); for j in i..<e { s += data[j]*data[j] }; rms.append(sqrt(s/Float(e-i))); i += win }
let peak = rms.max()!
let thr = peak * 0.04
var segs: [(Double, Double)] = []; var start: Int? = nil; var silentRun = 0
let gapWins = Int(minGap / 0.02)
for (k, v) in rms.enumerated() {
  if v > thr { if start == nil { start = k }; silentRun = 0 }
  else if let s = start { silentRun += 1; if silentRun >= gapWins { segs.append((Double(s)*0.02, Double(k - silentRun + 1)*0.02)); start = nil; silentRun = 0 } }
}
if let s = start { segs.append((Double(s)*0.02, Double(rms.count)*0.02)) }
print(segs.map { String(format: "%.2f-%.2f", $0.0, $0.1) }.joined(separator: " "))
