import AVFoundation
let a = AVURLAsset(url: URL(fileURLWithPath: CommandLine.arguments[1]))
let s = DispatchSemaphore(value: 0)
Task {
  let d = try await a.load(.duration)
  for t in try await a.load(.tracks) {
    let f = try await t.load(.formatDescriptions).first!
    print(t.mediaType.rawValue, FourCharCode(CMFormatDescriptionGetMediaSubType(f)), try await t.load(.naturalSize))
  }
  print("duration", d.seconds); s.signal()
}
s.wait()
