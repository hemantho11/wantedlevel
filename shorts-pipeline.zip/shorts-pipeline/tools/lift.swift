import Vision
import CoreImage
import AppKit
// usage: lift <in.jpg> <out.png> [x y]   — cuts the foreground subject out (transparent PNG).
// With x y (pixels, top-left origin) only the subject instance under that point is kept.
let a = CommandLine.arguments
let url = URL(fileURLWithPath: a[1])
let ci = CIImage(contentsOf: url)!
let handler = VNImageRequestHandler(ciImage: ci)
let req = VNGenerateForegroundInstanceMaskRequest()
try handler.perform([req])
guard let obs = req.results?.first else { print("no subject"); exit(1) }
var inst = obs.allInstances
if a.count >= 5, let x = Double(a[3]), let y = Double(a[4]) {
    let pb = obs.instanceMask
    CVPixelBufferLockBaseAddress(pb, .readOnly)
    let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb), bpr = CVPixelBufferGetBytesPerRow(pb)
    let p = CVPixelBufferGetBaseAddress(pb)!.assumingMemoryBound(to: UInt8.self)
    let px = Int(x / Double(ci.extent.width) * Double(w)), py = Int(y / Double(ci.extent.height) * Double(h))
    let v = Int(p[min(h - 1, py) * bpr + min(w - 1, px)])
    CVPixelBufferUnlockBaseAddress(pb, .readOnly)
    if v > 0 { inst = IndexSet(integer: v) } else { print("no instance at point; keeping all", inst.count) }
}
let out = try obs.generateMaskedImage(ofInstances: inst, from: handler, croppedToInstancesExtent: true)
let img = CIImage(cvPixelBuffer: out)
let ctx = CIContext()
try ctx.writePNGRepresentation(of: img, to: URL(fileURLWithPath: a[2]), format: .RGBA8, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
print("instances", obs.allInstances.count, "kept", inst.count, "size", img.extent.size)
