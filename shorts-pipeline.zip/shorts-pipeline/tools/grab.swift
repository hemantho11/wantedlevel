import AVFoundation
import ImageIO
import UniformTypeIdentifiers
let a = CommandLine.arguments
let gen = AVAssetImageGenerator(asset: AVURLAsset(url: URL(fileURLWithPath: a[1])))
gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero
for t in a[3...] {
  let img = try gen.copyCGImage(at: CMTime(seconds: Double(t)!, preferredTimescale: 600), actualTime: nil)
  let d = CGImageDestinationCreateWithURL(URL(fileURLWithPath: "\(a[2])/f_\(t).jpg") as CFURL, UTType.jpeg.identifier as CFString, 1, nil)!
  CGImageDestinationAddImage(d, img, [kCGImageDestinationLossyCompressionQuality: 0.8] as CFDictionary); CGImageDestinationFinalize(d)
}
