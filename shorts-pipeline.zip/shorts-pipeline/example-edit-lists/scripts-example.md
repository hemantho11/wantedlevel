# GTA 6 Extended Look – Viral Shorts Scripts

Format: vertical 9:16, 25–40 sec each. Each numbered line = one shot.
Voiceover: copy ONLY the "VO" lines into your voice generator. Leave a short pause (~0.5s) between lines.
Save each as: voiceovers/short01.mp3, short02.mp3 ... (mp3, m4a or wav are all fine)

---

## SHORT 01 – "The Trailer 1 robbery is REAL gameplay"
Source: 11:25–12:15

1. VO: Remember THIS scene from the very first GTA 6 trailer?
   Visual: 12:08 Lucia in bandana, gun raised (freeze-frame hook)
2. VO: It's not a cutscene. It's a real mission — and you play it.
   Visual: 11:28 robber walks into the store, bandana on
3. VO: He goes straight for the counter…
   Visual: 11:50 behind the counter
4. VO: …but look at the mirror. The clerk has a shotgun, and he's aiming right at you.
   Visual: 12:00 shotgun in the round security mirror
5. VO: Then Lucia steps in. And this is the moment everyone's been waiting for.
   Visual: 12:08 Lucia draws her gun
6. VO: Would you rob the store with Lucia, or let the clerk win? Comment below.
   Visual: 11:44 Lucia walking the store aisle

---

## SHORT 02 – "GTA 6 has LIVESTREAMING?!"
Source: 18:20–18:32

1. VO: Wait… is that a live chat?
   Visual: 18:26 zoom on the LIVE chat panel
2. VO: GTA 6 lets you go live on in-game social media — while committing crimes.
   Visual: 18:26 full shot, car driving, chat scrolling
3. VO: People in the chat are reacting in real time.
   Visual: 18:26 zoom on chat messages
4. VO: And yes… that's a guy stuffed in the trunk.
   Visual: 18:26 zoom on the open trunk
5. VO: Vice City is basically Florida with a follower count. Would you stream this? Follow for more GTA 6 secrets.
   Visual: 18:18 guy taking a selfie on the street

---

## SHORT 03 – "GTA 6 police are INSANE"
Source: 13:58–14:40

1. VO: GTA 6 cops do not play around.
   Visual: 14:02 helicopter above, truck blocking the road
2. VO: Four stars, a helicopter overhead, and roadblocks already waiting.
   Visual: 14:02 wide shot, wanted stars visible
3. VO: But watch this cop car…
   Visual: 14:08 crew member aiming from the window
4. VO: …FLIPPED. Completely.
   Visual: 14:10 police car rolling (slow-motion)
5. VO: They chase you down alleys, they chase you through traffic.
   Visual: 14:18 – 14:34 alley shootout + chase
6. VO: GTA 5 cops could never. Which game has the better police? Comment.
   Visual: 14:42 Lucia driving in the bandana

---

## SHORT 04 – "You can hold hands in GTA 6"
Source: 09:36–10:20

1. VO: GTA 6 just added the most wholesome mechanic ever.
   Visual: 09:54 Jason and his date walking hand in hand
2. VO: Jason and his date take the elevator up to a rooftop bar in Vice City…
   Visual: 09:38 – 09:46 elevator scene
3. VO: …and look at the bottom corner. "Hold hands."
   Visual: 09:56 zoom on the HOLD HANDS prompt
4. VO: It's an actual button. You choose to hold hands.
   Visual: 10:02 walking through the rooftop crowd
5. VO: Five seconds later he's probably robbing a store. That's GTA. Tag the person you're holding hands with in Vice City.
   Visual: 10:10 arriving at the bar

---

## SHORT 05 – "The GTA 6 map from the sky"
Source: 16:30–16:40 + 18:46–19:00 + 26:05–26:15

1. VO: This is what Vice City looks like from ten thousand feet.
   Visual: 18:50 skydiving over the islands
2. VO: Islands, canals, beaches, skyscrapers — and you can go to all of it.
   Visual: 16:34 aerial of the beach, tennis court, highway
3. VO: No loading screen. Just jump.
   Visual: 18:54 – 18:58 diving down fast
4. VO: This is the biggest, most detailed map Rockstar has ever built.
   Visual: 26:10 sunset skyline
5. VO: November 19th, 2026. Where are you landing first?
   Visual: 18:50 skydive again (loop point)

---

## SHORT 06 – "Who is Hammer Lady??"
Source: 09:10–09:20

1. VO: Rockstar hid something weird in GTA 6.
   Visual: 09:14 Jason walking toward the motel
2. VO: Look at the bottom right corner.
   Visual: 09:14 zoom on the prompts
3. VO: "Question." And then… "Hammer Lady."
   Visual: 09:14 zoom tighter on "HAMMER LADY"
4. VO: Who is Hammer Lady? Why does she have a hammer? And why can you talk to her?
   Visual: 09:14 zoom on the woman by the car
5. VO: This is peak Florida. Drop your best Hammer Lady theory in the comments.
   Visual: 08:58 guy standing on the bridge railing

---

## SHORT 07 – "GTA 6 TV is unhinged"
Source: 07:26–07:58

1. VO: In GTA 6, even the TV is chaos.
   Visual: 07:30 TV in the apartment
2. VO: One channel has a cartoon… potato… sitting on a stool.
   Visual: 07:30 zoom on the TV
3. VO: Switch it over — a nature documentary. Looks peaceful, right?
   Visual: 07:38 – 07:46 forest, deer, squirrel
4. VO: Then THIS happens.
   Visual: 07:50 squirrel mid-jump
5. VO: A giant ham sandwich commercial. Rockstar's humor is back.
   Visual: 07:54 ham sandwich
6. VO: Would you actually sit and watch GTA 6 TV? Be honest.
   Visual: 07:30 potato on TV

---

## SHORT 08 – "The GTA 6 heist nobody saw coming"
Source: 23:10–25:40

1. VO: This was supposed to be a quiet night at a party.
   Visual: 23:06 nightclub crowd
2. VO: Then the elevator doors open.
   Visual: 23:14 masked gunmen in white suits
3. VO: Then Lucia sends a text: "He's in the saferoom. Ten-plus guys, automatic weapons, explosives. Sounds military."
   Visual: 23:54 zoom on Lucia's text message
4. VO: Floor twenty-six. No way out.
   Visual: 24:34 Floor 26 sign
5. VO: What happens next is the most intense gunfight in the whole video.
   Visual: 24:50 – 25:22 office shootout
6. VO: And it ends like this.
   Visual: 25:30 takedown, 25:38 gun on the floor
7. VO: Who do you think "Czr" is? Comment your theory.
   Visual: 25:46 night skyline

---

## SHORT 09 – "30 seconds of GTA 6 activities"
Source: 17:04–18:40

1. VO: Here's everything you can do in GTA 6 in thirty seconds.
   Visual: 18:50 skydive (flash hook)
2. VO: Ride with your crew.
   Visual: 17:06 bikes at the street corner
3. VO: Shoot hoops.
   Visual: 17:14 basketball
4. VO: Kayak through the canals.
   Visual: 17:30 kayak
5. VO: Hit the club.
   Visual: 17:38 club hug
6. VO: Street race.
   Visual: 17:46 race, lap 8 of 16
7. VO: Rob a jewelry store.
   Visual: 18:02 jewelry store
8. VO: Dirt bike racing.
   Visual: 18:34 dirt bike
9. VO: And go live while you do it. Which one are you doing first?
   Visual: 18:26 livestream

---

## SHORT 10 – "How to escape cops in GTA 6"
Source: 15:20–16:30

1. VO: Here's how you lose a five-star wanted level in GTA 6.
   Visual: 15:46 police helicopter over the street
2. VO: Step one: cut through the alleys where the cops can't follow.
   Visual: 15:22 – 15:30 alley chase
3. VO: Step two: get off the main road and out of the helicopter's view.
   Visual: 15:38 street chase
4. VO: Step three: hide in a parking garage…
   Visual: 15:54 car rolls into the garage
5. VO: …and swap into a getaway van.
   Visual: 16:02 – 16:10 switching cars
6. VO: Then drive away like nothing happened.
   Visual: 16:18 – 16:26 van cruising by the water
7. VO: Save this for November 19th. You're gonna need it.
   Visual: 16:34 aerial of Vice City
